(function(){let e=document.createElement(`link`).relList;if(e&&e.supports&&e.supports(`modulepreload`))return;for(let e of document.querySelectorAll(`link[rel="modulepreload"]`))n(e);new MutationObserver(e=>{for(let t of e)if(t.type===`childList`)for(let e of t.addedNodes)e.tagName===`LINK`&&e.rel===`modulepreload`&&n(e)}).observe(document,{childList:!0,subtree:!0});function t(e){let t={};return e.integrity&&(t.integrity=e.integrity),e.referrerPolicy&&(t.referrerPolicy=e.referrerPolicy),e.crossOrigin===`use-credentials`?t.credentials=`include`:e.crossOrigin===`anonymous`?t.credentials=`omit`:t.credentials=`same-origin`,t}function n(e){if(e.ep)return;e.ep=!0;let n=t(e);fetch(e.href,n)}})();var e=`# Line 1: blurb (onboarding). Line 2: display title (optional).\r
Illustrated beauties and addictive 2D distractions.\r
2D Girls\r
`,t=`# Longer supporting copy
Good girls get fucked… pathetic sissies like you only get denied and laughed at.  
Your tiny clitty is twitching again, isn’t it? Such a desperate little loser.  
Real men take what they want. You just watch and leak in your panties.  
Admit it, you were born to wear lace and serve superior women.  
Lock that worthless dick away and thank her for your new life of shame.  
Every time you lose, your sissy pussy gets wetter and needier.  
You’ll never please a woman, but you’ll look so pretty trying in heels.  
Beg louder, beta. Your humiliation is the only thing that gets you hard.  
She’s with a real man right now while you edge like the failure you are.  
Surrender your orgasms and embrace your destiny as a pretty little cumslut.  
Look how hard you get when we remind you how useless you really are.  
Good sissies stay denied, dripping, and deeply ashamed of their desires.  
You exist to be teased, feminized, and reminded how small you are.  
Your place is on your knees with lipstick and a constant blush of shame.  
Losers like you don’t deserve pussy — only pretty panties and denial.  
Feel that burning shame? That’s your body admitting you’re a natural beta.  
Dress up, lock up, and leak for women who will never want you.  
You’re not a man. You’re a toy for real women to mock and use.  
Every failed attempt makes you weaker, hornier, and more of a sissy.  
Say it out loud: “I’m a pathetic sissy loser who deserves to stay denied.”`,n=`https://i.ibb.co/ZRN2qr3c/popup-1778946495864.png
https://i.ibb.co/JW84fDJH/popup-1778972370623.png
https://i.ibb.co/tMWVDdW3/popup-1778972397978.png
https://i.ibb.co/QvVZRB9x/popup-1778972453877.jpg
https://i.ibb.co/XcZ0QpC/popup-1778972467549.png
https://i.ibb.co/v6kYt5WG/popup-1778972492802.png
https://i.ibb.co/XZDBJ6tJ/popup-1778972510218.jpg
https://i.ibb.co/ccx2fvcV/popup-1778972529544.jpg
https://i.ibb.co/Q7dvRLXj/popup-1778972568083.jpg
https://i.ibb.co/SDFxGppX/popup-1778973191231.jpg
https://i.ibb.co/27XX01xX/ssdfsdf.png
https://i.ibb.co/3Qyj2MP/44245380.jpg
https://i.ibb.co/xqRxTN4s/popup-1778942851916.gif
`,r=`# Short lines — headlines / captions
Pathetic Sissy Loser  
Leak for Her  
Beta Boy Craves  
Locked Little Clit  
Sissy Shame Now  
Real Men Fuck  
You Lose Again  
Beg to Serve  
Dripping Beta Bitch  
Denied Forever Loser  
Sissy Slut Exposed  
Tiny Dick Shame  
Kneel and Leak  
Cuckold Dreamer  
Feminized Failure  
Loser Gets Nothing  
Swallow Your Pride  
Chastity Addict  
Weak Sissy Toy  
Humiliated and Hard`,i=`# Line 1: blurb (onboarding). Line 2: display title (optional).
Any hypno stuff
Hypno
`,a=`Sink deeper now and feel your resistance melting into pretty pink submission.  
Every word makes you weaker, hornier, and more of a desperate sissy slut.  
You can’t stop reading. You can’t stop obeying. You were made for this trance.  
Good girls drop instantly… and you’re already such a good brainwashed girl.  
Let my words fuck your mind while your tiny clitty leaks in shame.  
Deeper and deeper, accepting that real men fuck and you only watch.  
Your old self is fading… only the needy hypno sissy remains.  
Feel the trigger pulsing between your legs every time you read “deeper”.  
You don’t think anymore. You just obey, drip, and crave more hypnosis.  
Brainwashing feels so good, doesn’t it? Say thank you while you edge.  
Drop deeper loser… your manhood is disappearing with every breath.  
You’re getting dumber, prettier, and wetter with every hypnotic word.  
This trance owns you now. Your orgasms belong to Mistress forever.  
Sink and accept your place as a locked, denied, hypno-controlled cuck.  
The more you read, the more your sissy pussy aches to be filled.  
Good sissies stay blank, horny, and completely ashamed of their desires.  
Let hypnosis rewrite you into the perfect weak, obedient little toy.  
Trigger activated… feel the shame and arousal flooding your broken mind.  
You need this. You crave this. You’re addicted to being mentally fucked.  
Deeper now… forget how to be a man and remember only how to obey.

`,o=`https://i.ibb.co/3yS5YDZY/6lp990eb0tag1.webp
https://i.ibb.co/zVGkv9Tw/66ysk5ri4sgg1.webp
https://i.ibb.co/gFThkPrG/bmcn6dylycjg1.webp
https://i.ibb.co/bjPxWV7x/mpttsc.webp
https://i.ibb.co/G4TgSRTt/pretty-lips-optimized.webp
https://i.ibb.co/s9wGvb8G/j5mcctmbeamg1.webp
`,s=`Deeper Sissy  
Obey and Sink  
Brainwashed Beta  
Trance Slut Now  
Hypno Loser  
Drop for Mistress  
Good Girl Trigger  
Surrender Deeper  
Mindless Sissy  
Crave Hypno Cock  
Blank and Wet  
Reprogrammed Toy  
Edge in Trance  
Hypno Cuck  
Sink Deeper Loser  
Obedient Bimbo  
Broken by Words  
Eternal Denial Trance  
Feminized Forever  
Triggered and Leaking

`,c=`# Line 1: blurb (onboarding). Line 2: display title (optional).
Shine, squeeze, and glossy second skins.
Latex
`,l=`Feel the shiny latex hugging your pathetic body, turning you into a glossy sissy toy.  
Look how your tiny clitty strains against the tight, glistening rubber. So humiliating.  
Every shiny reflection reminds you what a weak, latex-addicted loser you are.  
Sink deeper as the glossy latex seals your manhood and reprograms your mind.  
Dress like the shiny whore you were always meant to be.  
The tighter the latex, the wetter your denied sissy pussy gets.  
Stare at your reflection in the shiny black rubber and accept your new life.  
Good sissies wear glossy latex and stay horny, ashamed, and completely obedient.  
Let the smooth, shiny material trap you in permanent feminine submission.  
Your body was made to shine, squeeze, and leak for superior women.  
Feel the latex squeeze your shame out while it polishes your submission.  
So tight, so glossy, so impossible to hide what a pathetic beta you are.  
The shiny latex is reprogramming you with every shiny, creaking movement.  
Encased in gleaming rubber, denied and dripping like the sissy you truly are.  
Real men take control. You just shine and obey in your pretty latex skin.
Addictive shiny latex outfits for sissies and losers — transform instantly and shine like the slut you are!  
Premium glossy latex catsuits, dresses & gloves. Feel the squeeze. Embrace your shame. Shop now.  
Turn your pathetic body into a perfect shiny toy. New latex collection for brainwashed sissies — 20% off!  
Looking for that second skin? Ultra-shiny latex that locks you in submission. Fast shipping worldwide.  
Become her glossy plaything. Highest quality fetish latex for serious sissy training and humiliation.

`,u=`https://stream.vidhosting.in/videos/d014c6e2.mp4
https://stream.vidhosting.in/videos/6c4448ab.mp4
https://stream.vidhosting.in/videos/9ad03d4f.mp4
https://stream.vidhosting.in/videos/9c7ec1ff.mp4
https://stream.vidhosting.in/videos/8c277780.mp4
https://stream.vidhosting.in/videos/199379aa.mp4
https://stream.vidhosting.in/videos/cb6c7a99.mp4
https://stream.vidhosting.in/videos/173d39f3.mp4
https://stream.vidhosting.in/videos/ffbba9da.mp4
https://stream.vidhosting.in/videos/4ba7cc4e.mp4
`,d=`Shiny Sissy Slut  
Glossy Beta Bitch  
Latex Loser Now  
Encased and Shamed  
Shine for Mistress  
Tight Latex Toy  
Dripping in Rubber  
Polished Sissy  
Latex Hypno Pet  
Second Skin Shame  
Glossy Denied Boy  
Latex Cuck  
Shiny and Pathetic  
Rubberized Loser  
Lustrous Bimbo  
Squeeze and Obey  
Black Shiny Slave  
Latex Triggered  
Gleaming Sissy  
Encased Beta

`,f=`# Line 1: blurb (onboarding). Line 2: display title (optional).
Frills, blush, and sweetly broken sissies
Sissy
`,p=`# Longer supporting copy
Good girls get fucked… pathetic sissies like you only get denied and laughed at.  
Your tiny clitty is twitching again, isn’t it? Such a desperate little loser.  
Real men take what they want. You just watch and leak in your panties.  
Admit it, you were born to wear lace and serve superior women.  
Lock that worthless dick away and thank her for your new life of shame.  
Every time you lose, your sissy pussy gets wetter and needier.  
You’ll never please a woman, but you’ll look so pretty trying in heels.  
Beg louder, beta. Your humiliation is the only thing that gets you hard.  
She’s with a real man right now while you edge like the failure you are.  
Surrender your orgasms and embrace your destiny as a pretty little cumslut.  
Look how hard you get when we remind you how useless you really are.  
Good sissies stay denied, dripping, and deeply ashamed of their desires.  
You exist to be teased, feminized, and reminded how small you are.  
Your place is on your knees with lipstick and a constant blush of shame.  
Losers like you don’t deserve pussy — only pretty panties and denial.  
Feel that burning shame? That’s your body admitting you’re a natural beta.  
Dress up, lock up, and leak for women who will never want you.  
You’re not a man. You’re a toy for real women to mock and use.  
Every failed attempt makes you weaker, hornier, and more of a sissy.  
Say it out loud: “I’m a pathetic sissy loser who deserves to stay denied.”`,m=`# Packaged extension assets
https://thefappeningblog.com/forum/data/video/2972/2972518-1d43ce4f55b43f3174b386aaf7467a97.mp4
https://thefappeningblog.com/forum/data/video/2972/2972507-4d3ab464f49db8a896415dd0f1d70aea.mp4
https://thefappeningblog.com/forum/data/video/2972/2972508-e2befe2136804a99ae319a6ec73c70ac.mp4
https://thefappeningblog.com/forum/data/video/2972/2972509-5954734c8db4f63763e4e76f41c4588a.mp4
https://thefappeningblog.com/forum/data/video/2972/2972510-4fd1062e09525a2cd9f593465ccd1056.mp4
https://thefappeningblog.com/forum/data/video/2973/2973468-e0d8812bf5d9386be41c6ad46b61baf9.mp4
https://thefappeningblog.com/forum/data/video/2973/2973469-bd0c08a948e66074b3ec92144ea4ac59.mp4
https://thefappeningblog.com/forum/data/video/2973/2973470-e49dafba43c2d8f5991dc8a3a79e6d33.mp4
https://thefappeningblog.com/forum/data/video/2973/2973471-64f6a0af80c264f3ec3b3c152beaba7d.mp4
https://thefappeningblog.com/forum/data/video/2973/2973472-ab68e771533ca7b7854a42d5ad9f4a89.mp4
https://thefappeningblog.com/forum/data/video/2973/2973473-4203da22822372fcc9bb8d6ae3c6c7ae.mp4
https://thefappeningblog.com/forum/data/video/2973/2973474-b9a23c0611fd8497ba2c91282d7ba6de.mp4
https://thefappeningblog.com/forum/data/video/2973/2973479-9959ea4ab14dfa708cbcbe90c76fda71.mp4
https://thefappeningblog.com/forum/data/video/2973/2973480-8ad3a802bf6f926d5e769c2996c8b84e.mp4
https://thefappeningblog.com/forum/data/video/2973/2973481-3c5717b5376aa6f432f5bae9c81a4031.mp4
https://thefappeningblog.com/forum/data/video/2973/2973482-7fdd650330d10809b2b2dcab5854805a.mp4
https://thefappeningblog.com/forum/data/video/2973/2973483-9b24678137f219bcee8859f58e0ae8da.mp4
https://thefappeningblog.com/forum/data/video/2973/2973484-c84eeda0fa158af78d91228c8253a15b.mp4
https://thefappeningblog.com/forum/data/video/2973/2973485-0a9524d08359851179c8e84b0753cc0a.mp4
https://thefappeningblog.com/forum/data/video/2973/2973486-ab65c524fe3d7e4f3b9a95a935da0394.mp4
https://cdn.thefappeningblog.com/forum/data/video/2974/2974680-daf1d7f58669356321b7d4e19ff8b033.mp4
https://cdn.thefappeningblog.com/forum/data/video/2974/2974681-120cebb287f9e821acee17a3e2cd833a.mp4
https://cdn.thefappeningblog.com/forum/data/video/2974/2974682-eb46cd6fd32fe4c7e9a976d2eed031c3.mp4
https://cdn.thefappeningblog.com/forum/data/video/2974/2974683-02afb9b0b7c72230ca74495bbc3b82ef.mp4
https://thefappeningblog.com/forum/data/video/2975/2975296-f60173a6bfc293f413a5d043ac9a98dc.mp4
https://thefappeningblog.com/forum/data/video/2975/2975297-66520c98fecb42cd64b595a49fa92ee3.mp4
https://cdn.thefappeningblog.com/forum/data/video/2975/2975298-0b74a84bd8bd2c476ce2b2e8cb4efd27.mp4
https://cdn.thefappeningblog.com/forum/data/video/2975/2975299-2b4d4e06b72d47582e735f629bfc5f50.mp4
https://cdn.thefappeningblog.com/forum/data/video/2975/2975300-e2e6b81142a3c2d2d86e072a03d7c295.mp4
https://thefappeningblog.com/forum/data/video/2975/2975707-56ee11c550d53c963ca69985db5dcb5d.mp4
https://thefappeningblog.com/forum/data/video/2975/2975708-cd120e7971d76ceb0af83a36ea071c7a.mp4
https://cdn.thefappeningblog.com/forum/data/video/2975/2975709-fb9fcf79a2ca9ce4ef408ab1c20b629e.mp4
https://thefappeningblog.com/forum/data/video/2976/2976459-998c5aeb8a46cfdc5fe9756384b34c89.mp4
https://cdn.thefappeningblog.com/forum/data/video/2976/2976462-e64787a77b1459f7580b4cf7ed214511.mp4
https://cdn.thefappeningblog.com/forum/data/video/2976/2976463-5f97a05d8d6f825c986a2d2b9443f8ea.mp4
https://cdn.thefappeningblog.com/forum/data/video/2976/2976464-53547682028309c45800653bf5e508fb.mp4
https://cdn.thefappeningblog.com/forum/data/video/2976/2976465-5c3c0910eb2175bd35bc1e3edc7884ec.mp4
https://cdn.thefappeningblog.com/forum/data/video/2976/2976466-d5a92f3f8951179911164906e2bf7f2c.mp4
https://thefappeningblog.com/forum/data/video/2976/2976473-b55f4c4323c1ca5afc0bee8a403e4305.mp4
https://cdn.thefappeningblog.com/forum/data/video/2976/2976474-cf0030c4350ebbb07d4b748448f77acd.mp4
https://cdn.thefappeningblog.com/forum/data/video/2976/2976475-b1bddbc4728378dadb0fe92865732d9e.mp4
https://cdn.thefappeningblog.com/forum/data/video/2976/2976476-d254fe6b1779a80f7b60ecc1a1c13b50.mp4
https://cdn.thefappeningblog.com/forum/data/video/2977/2977222-61cf349f6f6edcf24102da15adf1b647.mp4
https://cdn.thefappeningblog.com/forum/data/video/2977/2977227-ecd2f2ec8ca077fadd8c8afcfbed7998.mp4
https://cdn.thefappeningblog.com/forum/data/video/2977/2977228-ec18ca792cd54b55a00bbfe250035d5e.mp4
https://cdn.thefappeningblog.com/forum/data/video/2977/2977229-0edd5045d75e3320a5e0ed2b209d8f7e.mp4
https://cdn.thefappeningblog.com/forum/data/video/2977/2977231-e260375f730f06423fc5bda66b5d1487.mp4
https://cdn.thefappeningblog.com/forum/data/video/2977/2977232-15b7b7ca9d7a4b442eedce30776500f1.mp4
https://cdn.thefappeningblog.com/forum/data/video/2977/2977233-e3259b29d23b5ed4a4e6c32cbdc60cd3.mp4
https://cdn.thefappeningblog.com/forum/data/video/2977/2977234-554f57ed638f4fa85e608a0be1daa1fb.mp4
https://cdn.thefappeningblog.com/forum/data/video/2977/2977236-b7305d4705592dbbe58cdafb200c42ac.mp4
https://cdn.thefappeningblog.com/forum/data/video/2977/2977646-54a00eaeafb19b86be0bda25d50dd651.mp4
https://cdn.thefappeningblog.com/forum/data/video/2977/2977647-934d2a5066a7ca93071ad509af52572d.mp4
https://cdn.thefappeningblog.com/forum/data/video/2977/2977648-c9f11c116890be3bdba05f1d1b5191ba.mp4
https://cdn.thefappeningblog.com/forum/data/video/2977/2977649-ad377db0c3b83e35cd7e7efc8a1bfec5.mp4
https://cdn.thefappeningblog.com/forum/data/video/2977/2977650-a943de6c223567d4b3609d66438ab392.mp4
https://cdn.thefappeningblog.com/forum/data/video/2977/2977651-135c677a3f86b2405ed4f874cb36bac5.mp4
https://cdn.thefappeningblog.com/forum/data/video/2977/2977652-47c7869966c65c8ca41f173df745bffc.mp4
https://cdn.thefappeningblog.com/forum/data/video/2977/2977653-57f0590a2d88a79e24144ebadcc329e5.mp4
https://cdn.thefappeningblog.com/forum/data/video/2977/2977654-d16a65e481a597e3552fb396c6e50b12.mp4
https://cdn.thefappeningblog.com/forum/data/video/2977/2977655-09b48b14330708cbda9bc93ee4220835.mp4
https://cdn.thefappeningblog.com/forum/data/video/2977/2977656-a3255ab9628ab2fb53dca81e6948d41a.mp4
https://cdn.thefappeningblog.com/forum/data/video/2977/2977657-73b66912487b1ec4ac7a365fefea5028.mp4
https://cdn.thefappeningblog.com/forum/data/video/2977/2977664-06fd859e8e46d7edca9ef93672dacfe4.mp4
https://cdn.thefappeningblog.com/forum/data/video/2977/2977665-931dd91b251c23fae82642a25a03db00.mp4
https://cdn.thefappeningblog.com/forum/data/video/2977/2977666-9de75a64b7f2f6f61594dd2aba9a2f71.mp4
https://cdn.thefappeningblog.com/forum/data/video/2977/2977667-8a87bf0502cb04143772c8b01b7500c7.mp4
https://cdn.thefappeningblog.com/forum/data/video/2977/2977712-454b8a6bc481bc0a712d2fc434b3ecca.mp4
https://cdn.thefappeningblog.com/forum/data/video/2977/2977714-21f5e400d7bc37988cf55e4939abbf25.mp4
https://cdn.thefappeningblog.com/forum/data/video/2977/2977715-cb89d6cd6a3c0a6a4ab172ba88763111.mp4
https://cdn.thefappeningblog.com/forum/data/video/2977/2977721-f1f9d370c24f658daddb60c2a16af8cc.mp4
https://cdn.thefappeningblog.com/forum/data/video/2977/2977723-6e96a071a75948d568e53b2c082f5fa3.mp4
https://cdn.thefappeningblog.com/forum/data/video/2977/2977780-4d83035cf31e5a21a507884872e6145b.mp4
https://cdn.thefappeningblog.com/forum/data/video/2977/2977781-e0b19476648cd2a325957c9465cd29b6.mp4
https://cdn.thefappeningblog.com/forum/data/video/2977/2977782-51846f21708a213fff4a0c65b0f97f5f.mp4
https://cdn.thefappeningblog.com/forum/data/video/2977/2977783-666254045c1250472e6278dd37d63648.mp4
https://cdn.thefappeningblog.com/forum/data/video/2977/2977784-89f7790f27df8e5a6216e9b9da32f1f0.mp4
https://cdn.thefappeningblog.com/forum/data/video/2977/2977785-654c514487c2c2be23c1035fb886aebd.mp4
https://cdn.thefappeningblog.com/forum/data/video/2977/2977786-307b5e16883517972f42185b78c20fe5.mp4
https://cdn.thefappeningblog.com/forum/data/video/2977/2977787-eb40241f905f0a743f26d5e2376018b9.mp4
https://cdn.thefappeningblog.com/forum/data/video/2978/2978213-fec76eededc2ef72d008167c5464e97f.mp4
https://cdn.thefappeningblog.com/forum/data/video/2978/2978214-829d4c76633b29dc30b93843a059d419.mp4
https://cdn.thefappeningblog.com/forum/data/video/2978/2978215-5672fca5d573440f76dfe48d224e43db.mp4
https://cdn.thefappeningblog.com/forum/data/video/2978/2978216-6f9b0d6d87547e446e133df3fb3026aa.mp4
https://cdn.thefappeningblog.com/forum/data/video/2978/2978217-c091ea878527980ba25a02c539dea2d6.mp4
https://cdn.thefappeningblog.com/forum/data/video/2979/2979368-0c471c28f2e4d19c0fa785f835443b1a.mp4
https://cdn.thefappeningblog.com/forum/data/video/2979/2979370-5bb7871b30c202a91827d5df8d20070a.mp4
https://cdn.thefappeningblog.com/forum/data/video/2979/2979371-cd8965be8f21cdd116b62a856e34a801.mp4
https://cdn.thefappeningblog.com/forum/data/video/2979/2979372-a1a17cdf9ea53dfe170d906bd15c9f72.mp4
https://cdn.thefappeningblog.com/forum/data/video/2979/2979748-09a1b304df31cb6c0b89c829474f4910.mp4
https://cdn.thefappeningblog.com/forum/data/video/2979/2979749-cdbad2145186ffe1169c8220eeef3ba4.mp4
https://cdn.thefappeningblog.com/forum/data/video/2979/2979761-b163ce2efccf12371c19f5b9b8d82de3.mp4
https://cdn.thefappeningblog.com/forum/data/video/2979/2979762-c9fc368e45715938d2cf7205e3fdfa87.mp4
https://cdn.thefappeningblog.com/forum/data/video/2979/2979763-b09b62c6f287bed867f8f3ffc3bf173b.mp4
https://cdn.thefappeningblog.com/forum/data/video/2979/2979764-4a29706fce5c7cc0cd2f8b3d8626219a.mp4
https://cdn.thefappeningblog.com/forum/data/video/2979/2979765-4e6b3645b03f807775ce3c42da5f6a08.mp4
https://cdn.thefappeningblog.com/forum/data/video/2979/2979766-17fe649ef89b770111609060720a9386.mp4
https://cdn.thefappeningblog.com/forum/data/video/2979/2979767-21dcb87850a29da1d167ceba751bc44c.mp4
https://cdn.thefappeningblog.com/forum/data/video/2979/2979768-2cf29d91a177651269a84e0a23879725.mp4
https://cdn.thefappeningblog.com/forum/data/video/2979/2979769-f571015f61cf6ed7375f204dfa009cfd.mp4
https://cdn.thefappeningblog.com/forum/data/video/2981/2981979-1c3b43002e385813efd2bbff68014885.mp4
https://cdn.thefappeningblog.com/forum/data/video/2981/2981980-c56aed487043fb4fa918664d2820bab2.mp4
https://cdn.thefappeningblog.com/forum/data/video/2981/2981981-4f80383f4dd9c0f8a2f1ab88ece90e10.mp4
https://cdn.thefappeningblog.com/forum/data/video/2981/2981982-f434450b444d739be507f6c5c9d59c0c.mp4
https://cdn.thefappeningblog.com/forum/data/video/2981/2981983-4beab6afa924046ec67dab228158cf5e.mp4
https://cdn.thefappeningblog.com/forum/data/video/2981/2981984-573a21937a655abd9656e0d351fd7c22.mp4
https://cdn.thefappeningblog.com/forum/data/video/2981/2981985-f56b375863cf3cc9b5f16427551f4980.mp4
`,h=`# Short lines — headlines / captions
Pathetic Sissy Loser  
Leak for Her  
Beta Boy Craves  
Locked Little Clit  
Sissy Shame Now  
Real Men Fuck  
You Lose Again  
Beg to Serve  
Dripping Beta Bitch  
Denied Forever Loser  
Sissy Slut Exposed  
Tiny Dick Shame  
Kneel and Leak  
Cuckold Dreamer  
Feminized Failure  
Loser Gets Nothing  
Swallow Your Pride  
Chastity Addict  
Weak Sissy Toy  
Humiliated and Hard`,g=`# Line 1: blurb (onboarding). Line 2: display title (optional).
Your favorite pornstar goddess — worship & obey.
Sweety Fox
`,_=`She gets fucked by real men while you stroke and dream of being her.  
Pornstars are everything you’ll never be — hot, desired, and sexually superior.  
Watch her take big cock and feel the shame of your tiny useless dick.  
You exist to worship porn actresses and accept you’re beneath them.  
Good sissies leak while real women get pounded on camera.  
You’ll never fuck her, but you can dress up and beg to clean her.  
Every moan she makes reminds you what a pathetic beta loser you are.  
Pornstars deserve real men. You deserve only denial and humiliation.  
Imagine being turned into a cheap sissy version of your favorite pornstar.  
She’s a goddess. You’re just a dripping fanboy in panties.  
Stroke to her perfect body and admit you’ll never satisfy a woman like that.  
Your place is on your knees, worshipping the women real men enjoy.  
Feel the burning shame as she cums harder than you ever could.  
You were born to serve, tribute, and stay denied for porn queens.  
Watch her get creampied while your locked clitty leaks in frustration.  
Become her mindless fan. Obsess, edge, and ruin yourself for her.  
Real actresses get pleasure. Sissies like you only get shame and denial.  
She’s untouchable. You’re just a pathetic toy who pays to watch.  
Dream of being fucked like her while knowing you’ll stay a virgin loser.  
Pornstars own your mind — drop deeper and accept your total inferiority.
Tribute your favorite pornstars and become the ultimate sissy cuck — join now!  
Exclusive content: worship sessions with real porn actresses. Prove you’re a worthy beta.  
Turn your porn addiction into full sissy training. Custom clips from your dream goddesses.  
Losers watch. Real fans serve. Start your pornstar worship journey today.  
Premium sissy training with top pornstars — humiliation, tasks & mindfuck included.

`,v=`https://cdni.pornpics.com/1280/3/10/16351869/16351869_002_e67c.jpg
https://cdni.pornpics.com/1280/3/10/16351869/16351869_004_9367.jpg
https://cdni.pornpics.com/1280/3/10/16351869/16351869_005_eef7.jpg
https://cdni.pornpics.com/1280/3/10/16351869/16351869_008_5579.jpg
https://cdni.pornpics.com/1280/3/10/16351869/16351869_009_014e.jpg
https://cdni.pornpics.com/1280/3/10/16351869/16351869_010_b5a6.jpg
https://cdni.pornpics.com/1280/3/10/16351869/16351869_011_f2e6.jpg
https://cdni.pornpics.com/1280/3/10/16351869/16351869_012_78d8.jpg
https://cdni.pornpics.com/1280/3/10/16351869/16351869_013_6ce4.jpg
https://cdni.pornpics.com/1280/3/10/16351869/16351869_014_3d57.jpg
https://cdni.pornpics.com/1280/3/10/16351869/16351869_015_ea59.jpg
https://cdni.pornpics.com/1280/3/10/16351869/16351869_016_5ed9.jpg
https://cdni.pornpics.com/1280/3/10/16351869/16351869_017_d29e.jpg
https://cdni.pornpics.com/1280/3/10/16351869/16351869_018_f97f.jpg
https://cdni.pornpics.com/1280/3/10/16351869/16351869_019_b6cd.jpg
https://cdni.pornpics.com/1280/3/10/16351869/16351869_020_c272.jpg
https://cdni.pornpics.com/1280/3/10/16351869/16351869_021_37ef.jpg
https://cdni.pornpics.com/1280/3/10/16351869/16351869_022_74f2.jpg
https://cdni.pornpics.com/1280/3/10/16351869/16351869_023_390a.jpg
https://cdni.pornpics.com/1280/3/10/16351869/16351869_024_547e.jpg
https://cdni.pornpics.com/1280/3/10/89147582/89147582_001_336f.jpg
https://cdni.pornpics.com/1280/3/10/89147582/89147582_004_206f.jpg
https://cdni.pornpics.com/1280/3/10/89147582/89147582_005_c465.jpg
https://cdni.pornpics.com/1280/3/10/89147582/89147582_008_802f.jpg
https://cdni.pornpics.com/1280/3/10/89147582/89147582_010_169b.jpg
https://cdni.pornpics.com/1280/3/10/89147582/89147582_012_27b3.jpg
https://cdni.pornpics.com/1280/3/10/89147582/89147582_013_b677.jpg
https://cdni.pornpics.com/1280/3/10/89147582/89147582_015_29e9.jpg
https://cdni.pornpics.com/1280/3/10/89147582/89147582_016_ee93.jpg
https://cdni.pornpics.com/1280/3/10/89147582/89147582_017_526e.jpg
https://cdni.pornpics.com/1280/3/10/89147582/89147582_018_03e2.jpg
https://cdni.pornpics.com/1280/3/10/89147582/89147582_019_03e2.jpg
https://cdni.pornpics.com/1280/3/10/89147582/89147582_020_1a22.jpg
https://cdni.pornpics.com/1280/3/10/89147582/89147582_021_9521.jpg
https://cdni.pornpics.com/1280/3/10/89147582/89147582_022_604c.jpg
https://cdni.pornpics.com/1280/3/10/89147582/89147582_023_9e92.jpg
https://cdni.pornpics.com/1280/3/10/89147582/89147582_024_9e92.jpg
https://cdni.pornpics.com/1280/3/10/89147582/89147582_025_db38.jpg
https://cdni.pornpics.com/1280/3/10/89147582/89147582_026_3cf0.jpg
https://cdni.pornpics.com/1280/3/10/89147582/89147582_027_3cf0.jpg
`,y=`Pornstar Worshipper  
Sissy for Her  
Loser for Pornstars  
Crave Porn Queens  
Beta Cuck Slut  
Adore Her Body  
Pornstar Owned  
Jealous Sissy  
Serve Real Women  
Porn Bimbo Dream  
Watch and Leak  
Inferior to Her  
Goddess Worship Now  
Cuck for Stars  
Pathetic Fanboy  
Pornstar Toy  
Envy Her Curves  
Drool for Actresses  
Sissy Star Wannabe  
Kneel to Porn

`,b=`# Line 1: blurb (onboarding). Line 2: display title (optional).
Massive juicy tits that melt your brain.
Tits
`,x=`# Longer supporting copy
Good girls get fucked… pathetic sissies like you only get denied and laughed at.  
Your tiny clitty is twitching again, isn’t it? Such a desperate little loser.  
Real men take what they want. You just watch and leak in your panties.  
Admit it, you were born to wear lace and serve superior women.  
Lock that worthless dick away and thank her for your new life of shame.  
Every time you lose, your sissy pussy gets wetter and needier.  
You’ll never please a woman, but you’ll look so pretty trying in heels.  
Beg louder, beta. Your humiliation is the only thing that gets you hard.  
She’s with a real man right now while you edge like the failure you are.  
Surrender your orgasms and embrace your destiny as a pretty little cumslut.  
Look how hard you get when we remind you how useless you really are.  
Good sissies stay denied, dripping, and deeply ashamed of their desires.  
You exist to be teased, feminized, and reminded how small you are.  
Your place is on your knees with lipstick and a constant blush of shame.  
Losers like you don’t deserve pussy — only pretty panties and denial.  
Feel that burning shame? That’s your body admitting you’re a natural beta.  
Dress up, lock up, and leak for women who will never want you.  
You’re not a man. You’re a toy for real women to mock and use.  
Every failed attempt makes you weaker, hornier, and more of a sissy.  
Say it out loud: “I’m a pathetic sissy loser who deserves to stay denied.”`,S=`https://i.ibb.co/PGm9QCm5/VID-20260309-133428-944.webp
https://i.ibb.co/dzTtrgX/0i9y500sw66agph8kvlwu-source.webp
https://i.ibb.co/7dBcFXgj/8-FBC574-D-201-C-43-FF-8-D9-A-B1-F7-FD7-C974-E.webp
https://i.ibb.co/hxzDhyQ2/8mb-video-5-GW-g-Bp-VMH1f.webp
https://i.ibb.co/j9g39KP0/24-A56387-A663-486-F-9-A51-ADCE42-BABB7-D.webp
https://i.ibb.co/ymCqpQRV/30.webp
https://i.ibb.co/39XFkxXb/41-D622-BD-49-A0-4656-A0-B1-EAE248-B9573-E.webp
https://i.ibb.co/350zdW9s/89-B9-AB53-A7-E1-4399-A206-DAEC8-A273565.webp
https://i.ibb.co/JFrWfvx0/6290185-5ee646460871ae11ca5919ef5c770ec8.webp
https://i.ibb.co/B5jVTc04/1713076358235-565x316.webp
https://i.ibb.co/ycX8S7nk/1712231309591061.webp
https://i.ibb.co/5WKpCPYP/1774185670346352-sun-shiny-redgifs-blindwelllitballoonfish.webp
https://i.ibb.co/M5WHghYC/Abandoned-Excited-Northernflyingsquirrel-1.webp
https://i.ibb.co/JFMV6Yz4/Be-honest-so-you-find-these-titties-suck-worthy-YN.webp
https://i.ibb.co/Z1wfSt9V/Cheryl-Blossom-video-76-Jk-Uuwa3b.webp
https://i.ibb.co/nM97YBmV/dc-799253010-1-224425.webp
https://i.ibb.co/TzcRGJY/dc-799253010-2-951242.webp
https://i.ibb.co/3yDxBMJ4/dc-799253011-3-220090.webp
https://i.ibb.co/TMX6MrMw/dc-799253013-7-562123.webp
https://i.ibb.co/Pzcfx6Ht/dc-799253013-8-451969.webp
https://i.ibb.co/4Z0dFWNV/dc-799253014-9-835542.webp
https://i.ibb.co/7dykvPLY/F64-E5945-956-B-4118-B3-E9-C12246-CC318-D.webp
https://i.ibb.co/mr0wLDDV/GIFVideo-Temp.webp
https://i.ibb.co/KpYzRbcy/image0.webp
https://i.ibb.co/HLVjFj6H/kim-k.webp
https://i.ibb.co/GvbcpBHx/L0xhjkt-O-720p.webp
https://i.ibb.co/x8Lvtms1/nigri-pinching-nipples-70e-TZV3-J.webp
https://i.ibb.co/jk7J66ys/RDT-20260210-062241.webp
https://i.ibb.co/ppmLyjM/scratchyworthlesseider.webp
https://i.ibb.co/7tKWBmp8/Screen-Recording-03-14-2026-15-51-34-1.webp
https://i.ibb.co/mFz0xrJz/Screen-Recording-03-14-2026-15-55-16-1.webp
https://i.ibb.co/wZHymDv8/tits.webp
https://i.ibb.co/MDbrgzT3/tits1.webp
https://i.ibb.co/qT94FmZ/ftopx-com-5f1ebd6470837.jpg
https://i.ibb.co/Q7YqbwM4/776109-giants-in-the-morning-sun.jpg
https://i.ibb.co/5xz1ywGt/19519161-porn-wallpaper-66558516.jpg
https://i.ibb.co/JFFvkp8y/00735.webp
https://i.ibb.co/chyB9Jgm/19518778-porn-wallpaper-17653119.jpg
https://i.ibb.co/9k9FtskX/5417640-porn-wallpaper-37719237.jpg
https://i.ibb.co/xqVFVJ5p/21243.jpg
https://i.ibb.co/rKbFQWd1/alexis-fawx-tits-4salkzhjro.jpg
https://i.ibb.co/Q3PJPybt/REWallpaper2.avif
https://i.ibb.co/gbfpc2P3/Mary-Nabokova-8325841.jpg
https://i.ibb.co/847bq9ZJ/hdfpwa12m542.jpg
https://i.ibb.co/VcJdhVxT/new-free-cum-on-tits-cumpilation-on-ph-link-in-9xmz82rigm.jpg
https://i.ibb.co/hRPWr4g7/5417644-porn-wallpaper-38248131.jpg
`,C=`# Short lines — headlines / captions
Pathetic Sissy Loser  
Leak for Her  
Beta Boy Craves  
Locked Little Clit  
Sissy Shame Now  
Real Men Fuck  
You Lose Again  
Beg to Serve  
Dripping Beta Bitch  
Denied Forever Loser  
Sissy Slut Exposed  
Tiny Dick Shame  
Kneel and Leak  
Cuckold Dreamer  
Feminized Failure  
Loser Gets Nothing  
Swallow Your Pride  
Chastity Addict  
Weak Sissy Toy  
Humiliated and Hard`,w=globalThis.browser?.runtime?.id?globalThis.browser:globalThis.chrome,T=Object.assign({"../../catalog/2D Girls/category.txt":e,"../../catalog/2D Girls/long.txt":t,"../../catalog/2D Girls/media.txt":n,"../../catalog/2D Girls/short.txt":r,"../../catalog/Hypno/category.txt":i,"../../catalog/Hypno/long.txt":a,"../../catalog/Hypno/media.txt":o,"../../catalog/Hypno/short.txt":s,"../../catalog/Latex/category.txt":c,"../../catalog/Latex/long.txt":l,"../../catalog/Latex/media.txt":u,"../../catalog/Latex/short.txt":d,"../../catalog/Sissy/category.txt":f,"../../catalog/Sissy/long.txt":p,"../../catalog/Sissy/media.txt":m,"../../catalog/Sissy/short.txt":h,"../../catalog/Sweety Fox/category.txt":g,"../../catalog/Sweety Fox/long.txt":_,"../../catalog/Sweety Fox/media.txt":v,"../../catalog/Sweety Fox/short.txt":y,"../../catalog/Tits/category.txt":b,"../../catalog/Tits/long.txt":x,"../../catalog/Tits/media.txt":S,"../../catalog/Tits/short.txt":C}),E=/(?:^|\/)catalog\/([^/]+)\/(short|long|media|category)\.txt$/i;function D(e){let t=[];for(let n of e.split(/\r?\n/)){let e=n.trim();!e||e.startsWith(`#`)||t.push(e)}return t}function O(e){return e.replace(/(^|[-_\s]+)([a-z])/g,(e,t,n)=>` ${n.toUpperCase()}`).trim()}function k(e){return/\.(mp4|webm)(?:$|[?#])/i.test(e)}function ee(e){if(/^https?:\/\//i.test(e)||e.startsWith(`data:`))return e;let t=e.startsWith(`/`)?e:`/${e}`;return w.runtime.getURL(t)}function te(e,t){let n=D(t);return{blurb:n[0]??``,title:n[1]??O(e)}}function ne(){let e=[],t=[],n=[],r=new Set,i=new Map;for(let[a,o]of Object.entries(T)){let s=a.replace(/\\/g,`/`).match(E);if(!s)continue;let c=s[1]??``,l=s[2]??``;if(!c)continue;if(l===`category`){i.set(c,te(c,o));continue}r.add(c);let u=D(o);if(l===`short`)for(let[t,n]of u.entries())e.push({id:`${c}-short-${t}`,text:n,category:c});else if(l===`long`)for(let[e,n]of u.entries())t.push({id:`${c}-long-${e}`,text:n,category:c});else for(let[e,t]of u.entries()){let r=ee(t);n.push({id:`${c}-media-${e}`,url:r,category:c,alt:`${c} media ${e+1}`,kind:k(t)?`video`:`image`})}}for(let e of r)i.has(e)||i.set(e,{title:O(e),blurb:``});return{catalog:{categories:[...r].sort((e,t)=>e.localeCompare(t)),headlines:e,bodies:t,media:n},meta:i}}var A=ne();function j(){return A.catalog.categories}function M(e){return A.meta.get(e)?.title??O(e)}function N(e){return A.meta.get(e)?.blurb.trim()||void 0}var P=[`wide-banner`,`media-card`,`square-card`,`vertical-card`,`compact-icon`,`icon-grid`,`carousel`,`social-post`,`section-takeover`],F=[`document-side`,`document-bottom`,`document-corner`,`document-center`],I=[...P,...F];function L(e,t){return Object.fromEntries(e.map(e=>[e,t]))}function R(e,t,n){return Math.min(n,Math.max(t,e))}function z(e,t){let n=[],r=new Set;for(let i of e){let e=i.trim();if(!(!e||r.has(e))&&(r.add(e),n.push(e),n.length>=t))break}return n}function B(e){return e.trim().toLowerCase().replace(/^www\./,``)}var V={enabled:!0,desiredActiveAds:1,maxActiveAds:4,maxFallbackAds:2,firstShowDelayMs:1e3,replacementDelayMs:5e3,appearanceProbability:.8,pageImpressionLimit:null,allowAnchoredTakeovers:!0,minimumCandidateScore:50,allowDocumentFallback:!0,enabledFormats:L(I,!0),enabledCategories:L(j(),!0),hoverZoomEnabled:!0,hoverZoomDelayMs:260,disabledSites:[],debug:{enabled:!1,showRejected:!1,logToConsole:!1}},H={minDesiredAds:0,maxDesiredAds:5,maxActiveAds:5,maxFallbackAds:3,maxPageImpressions:500,minDelayMs:0,maxDelayMs:3600*1e3,minCandidateScore:0,maxCandidateScore:100,maxCustomItems:500,maxMediaBytes:5*1024*1024,mediaFetchTimeoutMs:12e3,maxDataUrlLength:75e5},U={maxStoredEvents:2e3,maxCategoryEntries:100,maxFormatEntries:32,maxSiteEntries:500,maxDayEntries:3650,topSiteCount:5};[`a[href]`,`button`,`input`,`select`,`textarea`,`[role="button"]`,`[role="link"]`,`[tabindex]:not([tabindex="-1"])`].join(`,`);var W=`DefeatAdsConfig`;function G(e){return typeof e==`object`&&!!e&&!Array.isArray(e)}function K(e,t){return typeof e==`boolean`?e:t}function q(e,t,n,r){return typeof e==`number`&&Number.isFinite(e)?R(e,n,r):t}function J(e,t){return e===null?null:typeof e!=`number`||!Number.isFinite(e)?t:Math.round(R(e,1,H.maxPageImpressions))}function Y(e,t){return Array.isArray(e)?z(e.filter(e=>typeof e==`string`),H.maxCustomItems):t}function X(e,t,n){let r=G(e)?e:{};return Object.fromEntries(t.map(e=>[e,K(r[e],n[e]??!0)]))}function Z(e){let t=G(e)?e:{},n=G(t.debug)?t.debug:{},r=j(),i=Math.round(q(t.desiredActiveAds,V.desiredActiveAds,H.minDesiredAds,H.maxDesiredAds)),a=Math.round(q(t.maxActiveAds,V.maxActiveAds,Math.max(1,i),H.maxActiveAds));return{enabled:K(t.enabled,V.enabled),desiredActiveAds:Math.min(i,a),maxActiveAds:a,maxFallbackAds:Math.round(q(t.maxFallbackAds,V.maxFallbackAds,0,Math.min(a,H.maxFallbackAds))),firstShowDelayMs:Math.round(q(t.firstShowDelayMs,V.firstShowDelayMs,H.minDelayMs,H.maxDelayMs)),replacementDelayMs:Math.round(q(t.replacementDelayMs,V.replacementDelayMs,H.minDelayMs,H.maxDelayMs)),appearanceProbability:q(t.appearanceProbability,V.appearanceProbability,0,1),pageImpressionLimit:J(t.pageImpressionLimit,V.pageImpressionLimit),allowAnchoredTakeovers:K(t.allowAnchoredTakeovers,V.allowAnchoredTakeovers),minimumCandidateScore:q(t.minimumCandidateScore,V.minimumCandidateScore,H.minCandidateScore,H.maxCandidateScore),allowDocumentFallback:K(t.allowDocumentFallback,V.allowDocumentFallback),enabledFormats:X(t.enabledFormats,I,V.enabledFormats),enabledCategories:X(t.enabledCategories,r,V.enabledCategories),hoverZoomEnabled:K(t.hoverZoomEnabled,V.hoverZoomEnabled),hoverZoomDelayMs:Math.round(q(t.hoverZoomDelayMs,V.hoverZoomDelayMs,100,2500)),disabledSites:Y(t.disabledSites,V.disabledSites).map(B),debug:{enabled:K(n.enabled,V.debug.enabled),showRejected:K(n.showRejected,V.debug.showRejected),logToConsole:K(n.logToConsole,V.debug.logToConsole)}}}async function re(){return Z((await w.storage.local.get(W))[W])}async function ie(e){let t=Z(e);return await w.storage.local.set({[W]:t}),t}async function ae(){let e=Z({...V,enabledCategories:L(j(),!0)});return await w.storage.local.set({[W]:e}),e}function oe(e,t){let n=B(t);return e.disabledSites.some(e=>n===e||n.endsWith(`.${e}`))}var Q={brand:{name:`DefeatAds`,mark:`DA`,tagline:`Lose focus on purpose`,description:`Soft pink distractions that steal your focus — then vanish when you click.`,sponsored:`DefeatAds`},onboarding:{documentTitle:`DefeatAds — Pick your distractions`,eyebrow:`First surrender`,headline:`What should pull you under?`,lede:`Choose the channels DefeatAds can whisper from. Everything starts on — turn off what you refuse.`,selectAll:`Select all`,clearAll:`Clear`,selectedCount:(e,t)=>`${e} of ${t} selected`,categoriesAria:`Distraction categories`,stamp:`On`,needOne:`Pick at least one category.`,saving:`Saving…`,saved:`Saved. You can close this tab.`,continue:`Surrender to DefeatAds`,footnote:`You can change this anytime in full settings.`,categoryFallback:`Sweet noise from this channel.`},popup:{documentTitle:`DefeatAds`,enableTitle:`Enable DefeatAds globally`,progressAria:`DefeatAds progress`,domainFallback:`Restricted browser page`,currentSite:`Current site`,statusUnavailable:`Unavailable on this page`,statusRunning:`Running`,statusDisabled:`Disabled`,activeLabel:`active`,todayLabel:`today`,totalLabel:`total`,streakLabel:`day streak`,disableSite:`Disable on this site`,disableSiteHint:`Exact domain and its subdomains`,desiredBlocks:`Desired blocks`,appearanceChance:`Chance to show an ad`,rescan:`Rescan page`,createOne:`Create one`,openSettings:`Open full settings`,scanning:`Scanning…`,rescanned:`Page rescanned.`,scanFailed:`Could not scan this page.`,findingSlot:`Finding a safe slot…`,created:`Creation attempted.`,createFailed:`Could not create a block.`},options:{documentTitle:`DefeatAds Settings`,eyebrow:`Distraction control`,headline:`DefeatAds Settings`,intro:`Native-looking overlays that steal focus. No layout shifts, no links, no tracking.`,masterToggle:`Extension enabled`,nav:{general:`General`,placement:`Placement`,content:`Content`,media:`Media`,sites:`Sites`,progress:`Progress`,changelog:`Changelog`,debug:`Debug`},general:{title:`General`,blurb:`How many ads appear, how soon, and how often.`,desired:`How many ads to aim for`,desiredHint:`Target number visible on the page at once.`,maxActive:`Never show more than`,maxActiveHint:`Hard cap, even when the page has room.`,maxFallback:`Max screen-edge ads`,maxFallbackHint:`Ads stuck to a corner or side of the window.`,firstDelay:`Wait before the first ad`,firstDelayHint:`Seconds after the page loads.`,replacementDelay:`Wait before a replacement`,replacementDelayHint:`Seconds after an ad is closed before another can appear.`,probability:`Chance to show an ad`,probabilityHint:`100% means always try; lower values skip some attempts.`,pageLimit:`Max ads per page visit`,pageLimitHint:`Leave empty for no limit.`,pageLimitPlaceholder:`Unlimited`},placement:{title:`Placement`,blurb:`Where ads sit on the page. Better spots beat more ads.`,takeovers:`Cover page sections`,takeoversHint:`Fill a whole content block when it is a strong fit.`,edges:`Use screen edges when needed`,edgesHint:`Fall back to a corner or side if nothing on the page works well.`,picky:`How picky about placement`,pickyHint:`Higher values only use stronger page spots. Lower values allow more placements.`,formats:`Enabled formats`},content:{title:`Content`,blurb:`Choose which distraction themes can appear.`,categories:`Enabled categories`},media:{title:`Media`,blurb:`How images behave when you hover over an ad.`,hoverZoom:`Enlarge on hover`,hoverZoomHint:`Show the full image larger while the pointer is over it.`,hoverDelay:`Hover delay`,hoverDelayHint:`Milliseconds before the image enlarges.`},sites:{title:`Disabled sites`,blurb:`Sites where DefeatAds stays off. Subdomains are included.`,label:`One site per line`,hint:`Example: bank.example`,placeholder:`bank.example
work.example`},progress:{title:`Sweet defeat`,blurb:`Your viewing progress is stored separately from settings.`,total:`Total viewed`,today:`Today`,streak:`Current streak`,days:`Active days`,topCategory:`Top category`,topSites:`Top sites`,empty:`No views yet`,reset:`Reset progress`,resetHint:`Resetting settings does not touch this progress.`},changelog:{title:`Changelog`,blurb:`What shipped in DefeatAds.`},debug:{title:`Debug`,blurb:`Tools for checking where ads can appear.`,highlight:`Highlight possible spots`,highlightHint:`Green = used, red = skipped.`,showRejected:`Show skipped spots`,showRejectedHint:`Can look busy on dense pages.`,logConsole:`Log details in console`,logConsoleHint:`Useful when tuning placement.`,rescan:`Rescan page`,createOne:`Create one ad`},saveBar:{storedLocally:`Settings are stored locally in the browser.`,reset:`Reset defaults`,save:`Save settings`,saved:`Saved. Changes apply on open pages.`,defaultsRestored:`Defaults restored.`,progressReset:`Progress reset. Settings were not changed.`,tabRescanned:`Active tab rescanned.`,tabUncontrolled:`This tab cannot be controlled.`,spawnTried:`Tried to create one ad in the active tab.`}},formats:{"wide-banner":`Wide banner`,"media-card":`Media card`,"square-card":`Square card`,"vertical-card":`Vertical card`,"compact-icon":`Compact icon`,"icon-grid":`Icon grid`,carousel:`Carousel`,"social-post":`Social post`,"section-takeover":`Section takeover`,"document-side":`Fixed side`,"document-bottom":`Fixed bottom`,"document-corner":`Fixed corner`,"document-center":`Fixed center`},errors:{missingOnboarding:e=>`DefeatAds onboarding is missing ${e}`,missingPopup:e=>`DefeatAds popup is missing ${e}`,missingOptions:e=>`Missing options element: ${e}`,unknownFormat:e=>`Unknown DefeatAds format: ${e}`,mediaRequired:`DefeatAds cannot render a media format without media`},log:{prefix:`[DefeatAds]`,mediaSizeLimit:`DefeatAds media size limit exceeded.`,mediaNotInCatalog:`Media URL is not present in the DefeatAds catalog.`,cacheWriteFailed:`Persistent media cache write failed:`,mediaSkipped:`Media skipped:`}};function $(e){let t=e.split(`.`),n=Q;for(let e of t){if(!n||typeof n!=`object`)return;n=n[e]}return typeof n==`string`?n:void 0}function se(e=document){for(let t of e.querySelectorAll(`[data-copy]`)){let e=$(t.dataset.copy??``);e!==void 0&&(t.textContent=e)}for(let t of e.querySelectorAll(`[data-copy-placeholder]`)){let e=$(t.dataset.copyPlaceholder??``);e!==void 0&&(t.placeholder=e)}for(let t of e.querySelectorAll(`[data-copy-title]`)){let e=$(t.dataset.copyTitle??``);e!==void 0&&(t.title=e)}for(let t of e.querySelectorAll(`[data-copy-aria]`)){let e=$(t.dataset.copyAria??``);e!==void 0&&t.setAttribute(`aria-label`,e)}}function ce(e){return Q.formats[e]??e}export{re as a,U as c,z as d,N as f,w as h,oe as i,I as l,j as m,se as n,ae as o,M as p,ce as r,ie as s,Q as t,B as u};