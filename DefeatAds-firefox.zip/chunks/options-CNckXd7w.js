import{a as e,d as t,h as n,l as r,m as i,n as a,o,p as s,r as c,s as l,t as u,u as d}from"./copy-DG3lOCpB.js";import{n as f,r as p,t as m}from"./progress-DXeC7Bp8.js";var h=`# Changelog

## 1.0.0

- Rebrand to **DefeatAds** with a soft pink latex visual system across onboarding, popup and settings.
- Shift product voice from joke ads to deliberate distraction / sweet defeat (bimbo-adjacent, kinky-adjacent — no NSFW).
- Replace toolbar icons with the **DA** mark on pink latex (16–128).
- Centralize all UI copy in \`src/shared/copy.ts\` for easy editing.
- Add a Changelog panel in settings that renders this file.
- Rename storage keys, extension root id, media cache and Firefox gecko id (no migration).
- Add store-ready manifest fields, privacy policy draft, and listing copy under \`docs/\`.
- Bump version to 1.0.0.

## 0.6.0

- Add a persistent Cache API media store with bounded entry and byte limits.
- De-duplicate simultaneous downloads of the same media URL across extension tabs.
- Add runtime media validation, \`error\` handling, cache invalidation and immediate replacement of broken assets.
- Detect common deleted/placeholder media responses and small ImgBB placeholders.
- Exclude ImgBB media on supported webmail hosts where remote media is commonly rewritten or removed.
- Add a generic mutation policy and scan cooldown to reduce SPA/sticky-interface analysis thrash.
- Prioritize semantic main-content candidates before bounded generic DOM traversal, improving hard pages such as GitHub without site-specific selectors.
- Keep active anchors stable across route changes and cosmetic mutations.
- Add independent progress storage in \`storage.local\`; configuration resets and extension updates do not clear it.
- Record category, format, hostname and timestamp after every rendered impression.
- Add popup quick controls and today/total/streak statistics.
- Add the “Ты молодец” options dashboard with totals, top category, top sites, active days and a separate progress reset.
- Add automated coverage for persistent caching, media policy, progress, mutation policy, priority analysis and runtime broken-media replacement.

## 0.5.0

- Load joke content from \`catalog/<category>/{short,long,media}.txt\` (plain lines, \`#\` comments).
- Load category blurb/title from \`catalog/<category>/category.txt\`.
- Discover categories dynamically from catalog folders.
- Remove intensity weights and options paste library for custom URLs/text.
- Hover zoom is exactly 150% of the on-screen media slot; only position shifts near viewport edges.
- Media allowlist comes from the bundled catalog URLs.

## 0.2.0

- Replaced fixed viewport fallback with document-pinned scroll-away fallback.
- Moved anchored ads to document coordinates so normal page scroll is native and has no JS frame lag.
- Kept synchronous correction only for nested scroll containers.
- Changed debug boxes to document coordinates.
- Removed long descriptions and CTA copy from the render model.
- Increased media share across all standard formats.
- Reduced headlines to two lines and supporting copy to short captions.
- Removed scale from ad appearance animation to keep edges aligned with anchors.
- Limited the default fallback count to one.
- Added document-space geometry and image-first composition tests.
- Revalidate anchor geometry after media loading and refresh positions after SPA layout mutations.
- Centralized format geometry checks to keep selection and lifecycle behavior consistent.
`;function g(e){let t=document.querySelector(e);if(!t)throw Error(u.errors.missingOptions(e));return t}function _(e,t){t.replaceChildren();let n=null,r=()=>{n=null};for(let i of e.split(/\r?\n/)){let e=i.trimEnd();if(!e.trim()||e.trim()===`# Changelog`){r();continue}if(e.startsWith(`## `)){r();let n=document.createElement(`h3`);n.textContent=e.slice(3).trim(),t.append(n);continue}if(e.startsWith(`- `)){n||(n=document.createElement(`ul`),t.append(n));let r=document.createElement(`li`);r.textContent=e.slice(2).trim(),n.append(r);continue}r()}}function v(e){return g(`#${e}`)}function y(e){return g(`#${e}`)}function b(e){return t(e.split(/\r?\n/),500)}function x(e){return Math.max(0,Number(e)||0)*1e3}function S(e){return Number(v(e).value)}document.title=u.options.documentTitle,a();var C=g(`#formatGrid`),w=g(`#categoryGrid`),T=g(`#message`),E=g(`#minimumCandidateScoreValue`),D=i();_(h,g(`#changelogBody`));for(let e of r){let t=document.createElement(`label`);t.className=`choice`;let n=document.createElement(`input`);n.type=`checkbox`,n.dataset.formatId=e,t.append(n,document.createTextNode(c(e))),C.append(t)}for(let e of D){let t=document.createElement(`label`);t.className=`choice`;let n=document.createElement(`input`);n.type=`checkbox`,n.dataset.category=e,t.append(n,document.createTextNode(s(e))),w.append(t)}async function O(){let e=p(await m());g(`#progressTotal`).textContent=String(e.total),g(`#progressToday`).textContent=String(e.today),g(`#progressStreak`).textContent=String(e.streakDays),g(`#progressDays`).textContent=String(e.activeDays),g(`#progressTopCategory`).textContent=e.topCategory?s(e.topCategory):`—`;let t=g(`#progressTopSites`);if(t.replaceChildren(),e.topSites.length===0){let e=document.createElement(`li`);e.textContent=u.options.progress.empty,t.append(e);return}for(let n of e.topSites){let e=document.createElement(`li`);e.textContent=`${n.site} · ${n.count}`,t.append(e)}}function k(e){T.textContent=e}function A(e){return g(`[data-format-id="${e}"]`)}function j(e){return g(`[data-category="${e}"]`)}function M(e){v(`enabled`).checked=e.enabled,v(`desiredActiveAds`).value=String(e.desiredActiveAds),v(`maxActiveAds`).value=String(e.maxActiveAds),v(`maxFallbackAds`).value=String(e.maxFallbackAds),v(`firstShowDelay`).value=String(e.firstShowDelayMs/1e3),v(`replacementDelay`).value=String(e.replacementDelayMs/1e3),v(`appearanceProbability`).value=String(Math.round(e.appearanceProbability*100)),v(`pageImpressionLimit`).value=e.pageImpressionLimit===null?``:String(e.pageImpressionLimit),v(`allowAnchoredTakeovers`).checked=e.allowAnchoredTakeovers,v(`allowDocumentFallback`).checked=e.allowDocumentFallback,v(`minimumCandidateScore`).value=String(e.minimumCandidateScore),E.textContent=`${e.minimumCandidateScore}/100`;for(let t of r)A(t).checked=e.enabledFormats[t];for(let t of D)j(t).checked=e.enabledCategories[t]!==!1;v(`hoverZoomEnabled`).checked=e.hoverZoomEnabled,v(`hoverZoomDelayMs`).value=String(e.hoverZoomDelayMs),y(`disabledSites`).value=e.disabledSites.join(`
`),v(`debugEnabled`).checked=e.debug.enabled,v(`debugShowRejected`).checked=e.debug.showRejected,v(`debugLogToConsole`).checked=e.debug.logToConsole}function N(e){let t={...e.enabledFormats};for(let e of r)t[e]=A(e).checked;let n={...e.enabledCategories};for(let e of D)n[e]=j(e).checked;let i=v(`pageImpressionLimit`).value.trim();return{...e,enabled:v(`enabled`).checked,desiredActiveAds:S(`desiredActiveAds`),maxActiveAds:S(`maxActiveAds`),maxFallbackAds:S(`maxFallbackAds`),firstShowDelayMs:x(v(`firstShowDelay`).value),replacementDelayMs:x(v(`replacementDelay`).value),appearanceProbability:S(`appearanceProbability`)/100,pageImpressionLimit:i?Number(i):null,allowAnchoredTakeovers:v(`allowAnchoredTakeovers`).checked,minimumCandidateScore:S(`minimumCandidateScore`),allowDocumentFallback:v(`allowDocumentFallback`).checked,enabledFormats:t,enabledCategories:n,hoverZoomEnabled:v(`hoverZoomEnabled`).checked,hoverZoomDelayMs:S(`hoverZoomDelayMs`),disabledSites:b(y(`disabledSites`).value).map(d),debug:{enabled:v(`debugEnabled`).checked,showRejected:v(`debugShowRejected`).checked,logToConsole:v(`debugLogToConsole`).checked}}}async function P(e){let[t]=await n.tabs.query({active:!0,currentWindow:!0});if(t?.id===void 0)return!1;try{return await n.tabs.sendMessage(t.id,e),!0}catch{return!1}}v(`minimumCandidateScore`).addEventListener(`input`,()=>{E.textContent=`${v(`minimumCandidateScore`).value}/100`}),g(`#save`).addEventListener(`click`,async()=>{M(await l(N(await e()))),k(u.options.saveBar.saved)}),g(`#reset`).addEventListener(`click`,async()=>{M(await o()),k(u.options.saveBar.defaultsRestored)}),g(`#resetProgress`).addEventListener(`click`,async()=>{await f(),await O(),k(u.options.saveBar.progressReset)}),g(`#forceScan`).addEventListener(`click`,async()=>{k(await P({type:`engine.forceScan`})?u.options.saveBar.tabRescanned:u.options.saveBar.tabUncontrolled)}),g(`#forceSpawn`).addEventListener(`click`,async()=>{k(await P({type:`engine.forceSpawn`})?u.options.saveBar.spawnTried:u.options.saveBar.tabUncontrolled)}),Promise.all([e().then(M),O()]);