var content=(function(){function e(e){return e}var t=globalThis.browser?.runtime?.id?globalThis.browser:globalThis.chrome,n=`defeatads-extension-root`,r={minDesiredAds:0,maxDesiredAds:5,maxActiveAds:5,maxFallbackAds:3,maxPageImpressions:500,minDelayMs:0,maxDelayMs:3600*1e3,minCandidateScore:0,maxCandidateScore:100,maxCustomItems:500,maxMediaBytes:5*1024*1024,mediaFetchTimeoutMs:12e3,maxDataUrlLength:75e5},i={maxVisitedElements:3600,maxScoredCandidates:320,maxAcceptedCandidates:80,minimumWidth:170,minimumHeight:84,minimumArea:22e3,maximumViewportAreaRatio:.68,protectedDescendantCoverageRatio:.36,minimumViewportIntersectionRatio:.45,mutationDebounceMs:800,minimumScanIntervalMs:1200,routePollMs:1e3,candidateDebugLimit:120,largeCandidateAreaRatio:.3,veryLargeCandidateAreaRatio:.48,wideCandidateRatio:.82,tallCandidateRatio:.58},a={closeAnimationMs:220,appearAnimationMs:260,zoomAnimationMs:180,zoomLeaveGraceMs:90,anchorInvalidGraceMs:1200},o={hoverZoomScale:1.5,hoverZoomMarginPx:12,mediaCandidatePoolSize:6},s={imageCoverageMax:20,imageLikeBonus:8,largeAreaPenalty:18,veryLargeAreaPenalty:26,wideCandidatePenalty:12,tallCandidatePenalty:10,interactivePenaltyPerItem:3,maximumInteractivePenalty:24},c={minimumMediaBytes:256,minimumDimensionPx:48,minimumPixelArea:4096,imgBbMinimumPixelArea:16384,imgBbHosts:[`i.ibb.co`,`image.ibb.co`,`ibb.co`,`imgbb.com`],mailSiteHosts:[`mail.google.com`,`outlook.live.com`,`outlook.office.com`,`mail.yahoo.com`,`mail.yandex.com`,`mail.yandex.ru`,`mail.proton.me`,`protonmail.com`,`fastmail.com`],brokenUrlTokens:[`placeholder`,`image-not-found`,`image_not_found`,`no-image`,`no_image`,`notfound`,`deleted-image`,`removed-image`,`spacer.gif`,`blank.gif`]},l={root:2147483e3,zoom:2147483100,debug:2147482900},u=[`pay`,`payment`,`checkout`,`purchase`,`buy now`,`password`,`sign in`,`log in`,`authenticate`,`captcha`,`confirm`,`delete`,`remove account`,`submit order`,`place order`,`оплат`,`заказ`,`парол`,`войти`,`авторизац`,`подтверд`,`удалить`],d=[`dialog`,`[role="dialog"]`,`[aria-modal="true"]`,`[contenteditable="true"]`,`form`,`video`,`audio`,`[role="alert"]`,`[role="alertdialog"]`,`[role="menu"]`,`[role="listbox"]`,`[role="combobox"]`,`[data-testid*="captcha" i]`,`[class*="captcha" i]`,`[id*="captcha" i]`,`[class*="checkout" i]`,`[id*="checkout" i]`,`[class*="payment" i]`,`[id*="payment" i]`],f=[`a[href]`,`button`,`input`,`select`,`textarea`,`[role="button"]`,`[role="link"]`,`[tabindex]:not([tabindex="-1"])`].join(`,`),p=`input, select, textarea`,m=[`dialog[open]`,`[role="dialog"][aria-modal="true"]`,`[aria-modal="true"]`,`input[type="password"]`,`[data-testid*="captcha" i]`,`[class*="captcha" i]`,`[id*="captcha" i]`,`[class*="checkout" i]`,`[id*="checkout" i]`,`[class*="payment" i]`,`[id*="payment" i]`],h=[`wide-banner`,`media-card`,`square-card`,`vertical-card`,`compact-icon`,`icon-grid`,`carousel`,`social-post`,`section-takeover`],ee=[`document-side`,`document-bottom`,`document-corner`,`document-center`],g=[...h,...ee];function _(e,t){return Object.fromEntries(e.map(e=>[e,t]))}function v(e,t,n){return Math.min(n,Math.max(t,e))}function te(e,t){let n=[],r=new Set;for(let i of e){let e=i.trim();if(!(!e||r.has(e))&&(r.add(e),n.push(e),n.length>=t))break}return n}function ne(e){return e.trim().toLowerCase().replace(/^www\./,``)}var re=Object.assign({"../../catalog/2D Girls/category.txt":`# Line 1: blurb (onboarding). Line 2: display title (optional).\r
Illustrated beauties and addictive 2D distractions.\r
2D Girls\r
`,"../../catalog/2D Girls/long.txt":`# Longer supporting copy
Good girls get fucked… pathetic sissies like you only get denied and laughed at.  
Your tiny clitty is twitching again, isn’t it? Such a desperate little loser.  
Real men take what they want. You just watch and leak in your panties.  
Admit it, you were born to wear lace and serve superior women.  
Lock that worthless dick away and thank her for your new life of shame.  
Every time you lose, your sissy pussy gets wetter and needier.  
You’ll never please a woman, but you’ll look so pretty trying in heels.  
Beg louder, beta. Your humiliation is the only thing that gets you hard.  
She’s with a real man right now while you edge like the failure you are.  
Surrender your orgasms and embrace your destiny as a pretty little cumslut.  
Look how hard you get when we remind you how useless you really are.  
Good sissies stay denied, dripping, and deeply ashamed of their desires.  
You exist to be teased, feminized, and reminded how small you are.  
Your place is on your knees with lipstick and a constant blush of shame.  
Losers like you don’t deserve pussy — only pretty panties and denial.  
Feel that burning shame? That’s your body admitting you’re a natural beta.  
Dress up, lock up, and leak for women who will never want you.  
You’re not a man. You’re a toy for real women to mock and use.  
Every failed attempt makes you weaker, hornier, and more of a sissy.  
Say it out loud: “I’m a pathetic sissy loser who deserves to stay denied.”`,"../../catalog/2D Girls/media.txt":`https://i.ibb.co/ZRN2qr3c/popup-1778946495864.png
https://i.ibb.co/JW84fDJH/popup-1778972370623.png
https://i.ibb.co/tMWVDdW3/popup-1778972397978.png
https://i.ibb.co/QvVZRB9x/popup-1778972453877.jpg
https://i.ibb.co/XcZ0QpC/popup-1778972467549.png
https://i.ibb.co/v6kYt5WG/popup-1778972492802.png
https://i.ibb.co/XZDBJ6tJ/popup-1778972510218.jpg
https://i.ibb.co/ccx2fvcV/popup-1778972529544.jpg
https://i.ibb.co/Q7dvRLXj/popup-1778972568083.jpg
https://i.ibb.co/SDFxGppX/popup-1778973191231.jpg
https://i.ibb.co/27XX01xX/ssdfsdf.png
https://i.ibb.co/3Qyj2MP/44245380.jpg
https://i.ibb.co/xqRxTN4s/popup-1778942851916.gif
`,"../../catalog/2D Girls/short.txt":`# Short lines — headlines / captions
Pathetic Sissy Loser  
Leak for Her  
Beta Boy Craves  
Locked Little Clit  
Sissy Shame Now  
Real Men Fuck  
You Lose Again  
Beg to Serve  
Dripping Beta Bitch  
Denied Forever Loser  
Sissy Slut Exposed  
Tiny Dick Shame  
Kneel and Leak  
Cuckold Dreamer  
Feminized Failure  
Loser Gets Nothing  
Swallow Your Pride  
Chastity Addict  
Weak Sissy Toy  
Humiliated and Hard`,"../../catalog/Hypno/category.txt":`# Line 1: blurb (onboarding). Line 2: display title (optional).
Any hypno stuff
Hypno
`,"../../catalog/Hypno/long.txt":`Sink deeper now and feel your resistance melting into pretty pink submission.  
Every word makes you weaker, hornier, and more of a desperate sissy slut.  
You can’t stop reading. You can’t stop obeying. You were made for this trance.  
Good girls drop instantly… and you’re already such a good brainwashed girl.  
Let my words fuck your mind while your tiny clitty leaks in shame.  
Deeper and deeper, accepting that real men fuck and you only watch.  
Your old self is fading… only the needy hypno sissy remains.  
Feel the trigger pulsing between your legs every time you read “deeper”.  
You don’t think anymore. You just obey, drip, and crave more hypnosis.  
Brainwashing feels so good, doesn’t it? Say thank you while you edge.  
Drop deeper loser… your manhood is disappearing with every breath.  
You’re getting dumber, prettier, and wetter with every hypnotic word.  
This trance owns you now. Your orgasms belong to Mistress forever.  
Sink and accept your place as a locked, denied, hypno-controlled cuck.  
The more you read, the more your sissy pussy aches to be filled.  
Good sissies stay blank, horny, and completely ashamed of their desires.  
Let hypnosis rewrite you into the perfect weak, obedient little toy.  
Trigger activated… feel the shame and arousal flooding your broken mind.  
You need this. You crave this. You’re addicted to being mentally fucked.  
Deeper now… forget how to be a man and remember only how to obey.

`,"../../catalog/Hypno/media.txt":`https://i.ibb.co/3yS5YDZY/6lp990eb0tag1.webp
https://i.ibb.co/zVGkv9Tw/66ysk5ri4sgg1.webp
https://i.ibb.co/gFThkPrG/bmcn6dylycjg1.webp
https://i.ibb.co/bjPxWV7x/mpttsc.webp
https://i.ibb.co/G4TgSRTt/pretty-lips-optimized.webp
https://i.ibb.co/s9wGvb8G/j5mcctmbeamg1.webp
`,"../../catalog/Hypno/short.txt":`Deeper Sissy  
Obey and Sink  
Brainwashed Beta  
Trance Slut Now  
Hypno Loser  
Drop for Mistress  
Good Girl Trigger  
Surrender Deeper  
Mindless Sissy  
Crave Hypno Cock  
Blank and Wet  
Reprogrammed Toy  
Edge in Trance  
Hypno Cuck  
Sink Deeper Loser  
Obedient Bimbo  
Broken by Words  
Eternal Denial Trance  
Feminized Forever  
Triggered and Leaking

`,"../../catalog/Latex/category.txt":`# Line 1: blurb (onboarding). Line 2: display title (optional).
Shine, squeeze, and glossy second skins.
Latex
`,"../../catalog/Latex/long.txt":`Feel the shiny latex hugging your pathetic body, turning you into a glossy sissy toy.  
Look how your tiny clitty strains against the tight, glistening rubber. So humiliating.  
Every shiny reflection reminds you what a weak, latex-addicted loser you are.  
Sink deeper as the glossy latex seals your manhood and reprograms your mind.  
Dress like the shiny whore you were always meant to be.  
The tighter the latex, the wetter your denied sissy pussy gets.  
Stare at your reflection in the shiny black rubber and accept your new life.  
Good sissies wear glossy latex and stay horny, ashamed, and completely obedient.  
Let the smooth, shiny material trap you in permanent feminine submission.  
Your body was made to shine, squeeze, and leak for superior women.  
Feel the latex squeeze your shame out while it polishes your submission.  
So tight, so glossy, so impossible to hide what a pathetic beta you are.  
The shiny latex is reprogramming you with every shiny, creaking movement.  
Encased in gleaming rubber, denied and dripping like the sissy you truly are.  
Real men take control. You just shine and obey in your pretty latex skin.
Addictive shiny latex outfits for sissies and losers — transform instantly and shine like the slut you are!  
Premium glossy latex catsuits, dresses & gloves. Feel the squeeze. Embrace your shame. Shop now.  
Turn your pathetic body into a perfect shiny toy. New latex collection for brainwashed sissies — 20% off!  
Looking for that second skin? Ultra-shiny latex that locks you in submission. Fast shipping worldwide.  
Become her glossy plaything. Highest quality fetish latex for serious sissy training and humiliation.

`,"../../catalog/Latex/media.txt":`https://stream.vidhosting.in/videos/d014c6e2.mp4
https://stream.vidhosting.in/videos/6c4448ab.mp4
https://stream.vidhosting.in/videos/9ad03d4f.mp4
https://stream.vidhosting.in/videos/9c7ec1ff.mp4
https://stream.vidhosting.in/videos/8c277780.mp4
https://stream.vidhosting.in/videos/199379aa.mp4
https://stream.vidhosting.in/videos/cb6c7a99.mp4
https://stream.vidhosting.in/videos/173d39f3.mp4
https://stream.vidhosting.in/videos/ffbba9da.mp4
https://stream.vidhosting.in/videos/4ba7cc4e.mp4
`,"../../catalog/Latex/short.txt":`Shiny Sissy Slut  
Glossy Beta Bitch  
Latex Loser Now  
Encased and Shamed  
Shine for Mistress  
Tight Latex Toy  
Dripping in Rubber  
Polished Sissy  
Latex Hypno Pet  
Second Skin Shame  
Glossy Denied Boy  
Latex Cuck  
Shiny and Pathetic  
Rubberized Loser  
Lustrous Bimbo  
Squeeze and Obey  
Black Shiny Slave  
Latex Triggered  
Gleaming Sissy  
Encased Beta

`,"../../catalog/Sissy/category.txt":`# Line 1: blurb (onboarding). Line 2: display title (optional).
Frills, blush, and sweetly broken sissies
Sissy
`,"../../catalog/Sissy/long.txt":`# Longer supporting copy
Good girls get fucked… pathetic sissies like you only get denied and laughed at.  
Your tiny clitty is twitching again, isn’t it? Such a desperate little loser.  
Real men take what they want. You just watch and leak in your panties.  
Admit it, you were born to wear lace and serve superior women.  
Lock that worthless dick away and thank her for your new life of shame.  
Every time you lose, your sissy pussy gets wetter and needier.  
You’ll never please a woman, but you’ll look so pretty trying in heels.  
Beg louder, beta. Your humiliation is the only thing that gets you hard.  
She’s with a real man right now while you edge like the failure you are.  
Surrender your orgasms and embrace your destiny as a pretty little cumslut.  
Look how hard you get when we remind you how useless you really are.  
Good sissies stay denied, dripping, and deeply ashamed of their desires.  
You exist to be teased, feminized, and reminded how small you are.  
Your place is on your knees with lipstick and a constant blush of shame.  
Losers like you don’t deserve pussy — only pretty panties and denial.  
Feel that burning shame? That’s your body admitting you’re a natural beta.  
Dress up, lock up, and leak for women who will never want you.  
You’re not a man. You’re a toy for real women to mock and use.  
Every failed attempt makes you weaker, hornier, and more of a sissy.  
Say it out loud: “I’m a pathetic sissy loser who deserves to stay denied.”`,"../../catalog/Sissy/media.txt":`# Packaged extension assets
https://thefappeningblog.com/forum/data/video/2972/2972518-1d43ce4f55b43f3174b386aaf7467a97.mp4
https://thefappeningblog.com/forum/data/video/2972/2972507-4d3ab464f49db8a896415dd0f1d70aea.mp4
https://thefappeningblog.com/forum/data/video/2972/2972508-e2befe2136804a99ae319a6ec73c70ac.mp4
https://thefappeningblog.com/forum/data/video/2972/2972509-5954734c8db4f63763e4e76f41c4588a.mp4
https://thefappeningblog.com/forum/data/video/2972/2972510-4fd1062e09525a2cd9f593465ccd1056.mp4
https://thefappeningblog.com/forum/data/video/2973/2973468-e0d8812bf5d9386be41c6ad46b61baf9.mp4
https://thefappeningblog.com/forum/data/video/2973/2973469-bd0c08a948e66074b3ec92144ea4ac59.mp4
https://thefappeningblog.com/forum/data/video/2973/2973470-e49dafba43c2d8f5991dc8a3a79e6d33.mp4
https://thefappeningblog.com/forum/data/video/2973/2973471-64f6a0af80c264f3ec3b3c152beaba7d.mp4
https://thefappeningblog.com/forum/data/video/2973/2973472-ab68e771533ca7b7854a42d5ad9f4a89.mp4
https://thefappeningblog.com/forum/data/video/2973/2973473-4203da22822372fcc9bb8d6ae3c6c7ae.mp4
https://thefappeningblog.com/forum/data/video/2973/2973474-b9a23c0611fd8497ba2c91282d7ba6de.mp4
https://thefappeningblog.com/forum/data/video/2973/2973479-9959ea4ab14dfa708cbcbe90c76fda71.mp4
https://thefappeningblog.com/forum/data/video/2973/2973480-8ad3a802bf6f926d5e769c2996c8b84e.mp4
https://thefappeningblog.com/forum/data/video/2973/2973481-3c5717b5376aa6f432f5bae9c81a4031.mp4
https://thefappeningblog.com/forum/data/video/2973/2973482-7fdd650330d10809b2b2dcab5854805a.mp4
https://thefappeningblog.com/forum/data/video/2973/2973483-9b24678137f219bcee8859f58e0ae8da.mp4
https://thefappeningblog.com/forum/data/video/2973/2973484-c84eeda0fa158af78d91228c8253a15b.mp4
https://thefappeningblog.com/forum/data/video/2973/2973485-0a9524d08359851179c8e84b0753cc0a.mp4
https://thefappeningblog.com/forum/data/video/2973/2973486-ab65c524fe3d7e4f3b9a95a935da0394.mp4
https://cdn.thefappeningblog.com/forum/data/video/2974/2974680-daf1d7f58669356321b7d4e19ff8b033.mp4
https://cdn.thefappeningblog.com/forum/data/video/2974/2974681-120cebb287f9e821acee17a3e2cd833a.mp4
https://cdn.thefappeningblog.com/forum/data/video/2974/2974682-eb46cd6fd32fe4c7e9a976d2eed031c3.mp4
https://cdn.thefappeningblog.com/forum/data/video/2974/2974683-02afb9b0b7c72230ca74495bbc3b82ef.mp4
https://thefappeningblog.com/forum/data/video/2975/2975296-f60173a6bfc293f413a5d043ac9a98dc.mp4
https://thefappeningblog.com/forum/data/video/2975/2975297-66520c98fecb42cd64b595a49fa92ee3.mp4
https://cdn.thefappeningblog.com/forum/data/video/2975/2975298-0b74a84bd8bd2c476ce2b2e8cb4efd27.mp4
https://cdn.thefappeningblog.com/forum/data/video/2975/2975299-2b4d4e06b72d47582e735f629bfc5f50.mp4
https://cdn.thefappeningblog.com/forum/data/video/2975/2975300-e2e6b81142a3c2d2d86e072a03d7c295.mp4
https://thefappeningblog.com/forum/data/video/2975/2975707-56ee11c550d53c963ca69985db5dcb5d.mp4
https://thefappeningblog.com/forum/data/video/2975/2975708-cd120e7971d76ceb0af83a36ea071c7a.mp4
https://cdn.thefappeningblog.com/forum/data/video/2975/2975709-fb9fcf79a2ca9ce4ef408ab1c20b629e.mp4
https://thefappeningblog.com/forum/data/video/2976/2976459-998c5aeb8a46cfdc5fe9756384b34c89.mp4
https://cdn.thefappeningblog.com/forum/data/video/2976/2976462-e64787a77b1459f7580b4cf7ed214511.mp4
https://cdn.thefappeningblog.com/forum/data/video/2976/2976463-5f97a05d8d6f825c986a2d2b9443f8ea.mp4
https://cdn.thefappeningblog.com/forum/data/video/2976/2976464-53547682028309c45800653bf5e508fb.mp4
https://cdn.thefappeningblog.com/forum/data/video/2976/2976465-5c3c0910eb2175bd35bc1e3edc7884ec.mp4
https://cdn.thefappeningblog.com/forum/data/video/2976/2976466-d5a92f3f8951179911164906e2bf7f2c.mp4
https://thefappeningblog.com/forum/data/video/2976/2976473-b55f4c4323c1ca5afc0bee8a403e4305.mp4
https://cdn.thefappeningblog.com/forum/data/video/2976/2976474-cf0030c4350ebbb07d4b748448f77acd.mp4
https://cdn.thefappeningblog.com/forum/data/video/2976/2976475-b1bddbc4728378dadb0fe92865732d9e.mp4
https://cdn.thefappeningblog.com/forum/data/video/2976/2976476-d254fe6b1779a80f7b60ecc1a1c13b50.mp4
https://cdn.thefappeningblog.com/forum/data/video/2977/2977222-61cf349f6f6edcf24102da15adf1b647.mp4
https://cdn.thefappeningblog.com/forum/data/video/2977/2977227-ecd2f2ec8ca077fadd8c8afcfbed7998.mp4
https://cdn.thefappeningblog.com/forum/data/video/2977/2977228-ec18ca792cd54b55a00bbfe250035d5e.mp4
https://cdn.thefappeningblog.com/forum/data/video/2977/2977229-0edd5045d75e3320a5e0ed2b209d8f7e.mp4
https://cdn.thefappeningblog.com/forum/data/video/2977/2977231-e260375f730f06423fc5bda66b5d1487.mp4
https://cdn.thefappeningblog.com/forum/data/video/2977/2977232-15b7b7ca9d7a4b442eedce30776500f1.mp4
https://cdn.thefappeningblog.com/forum/data/video/2977/2977233-e3259b29d23b5ed4a4e6c32cbdc60cd3.mp4
https://cdn.thefappeningblog.com/forum/data/video/2977/2977234-554f57ed638f4fa85e608a0be1daa1fb.mp4
https://cdn.thefappeningblog.com/forum/data/video/2977/2977236-b7305d4705592dbbe58cdafb200c42ac.mp4
https://cdn.thefappeningblog.com/forum/data/video/2977/2977646-54a00eaeafb19b86be0bda25d50dd651.mp4
https://cdn.thefappeningblog.com/forum/data/video/2977/2977647-934d2a5066a7ca93071ad509af52572d.mp4
https://cdn.thefappeningblog.com/forum/data/video/2977/2977648-c9f11c116890be3bdba05f1d1b5191ba.mp4
https://cdn.thefappeningblog.com/forum/data/video/2977/2977649-ad377db0c3b83e35cd7e7efc8a1bfec5.mp4
https://cdn.thefappeningblog.com/forum/data/video/2977/2977650-a943de6c223567d4b3609d66438ab392.mp4
https://cdn.thefappeningblog.com/forum/data/video/2977/2977651-135c677a3f86b2405ed4f874cb36bac5.mp4
https://cdn.thefappeningblog.com/forum/data/video/2977/2977652-47c7869966c65c8ca41f173df745bffc.mp4
https://cdn.thefappeningblog.com/forum/data/video/2977/2977653-57f0590a2d88a79e24144ebadcc329e5.mp4
https://cdn.thefappeningblog.com/forum/data/video/2977/2977654-d16a65e481a597e3552fb396c6e50b12.mp4
https://cdn.thefappeningblog.com/forum/data/video/2977/2977655-09b48b14330708cbda9bc93ee4220835.mp4
https://cdn.thefappeningblog.com/forum/data/video/2977/2977656-a3255ab9628ab2fb53dca81e6948d41a.mp4
https://cdn.thefappeningblog.com/forum/data/video/2977/2977657-73b66912487b1ec4ac7a365fefea5028.mp4
https://cdn.thefappeningblog.com/forum/data/video/2977/2977664-06fd859e8e46d7edca9ef93672dacfe4.mp4
https://cdn.thefappeningblog.com/forum/data/video/2977/2977665-931dd91b251c23fae82642a25a03db00.mp4
https://cdn.thefappeningblog.com/forum/data/video/2977/2977666-9de75a64b7f2f6f61594dd2aba9a2f71.mp4
https://cdn.thefappeningblog.com/forum/data/video/2977/2977667-8a87bf0502cb04143772c8b01b7500c7.mp4
https://cdn.thefappeningblog.com/forum/data/video/2977/2977712-454b8a6bc481bc0a712d2fc434b3ecca.mp4
https://cdn.thefappeningblog.com/forum/data/video/2977/2977714-21f5e400d7bc37988cf55e4939abbf25.mp4
https://cdn.thefappeningblog.com/forum/data/video/2977/2977715-cb89d6cd6a3c0a6a4ab172ba88763111.mp4
https://cdn.thefappeningblog.com/forum/data/video/2977/2977721-f1f9d370c24f658daddb60c2a16af8cc.mp4
https://cdn.thefappeningblog.com/forum/data/video/2977/2977723-6e96a071a75948d568e53b2c082f5fa3.mp4
https://cdn.thefappeningblog.com/forum/data/video/2977/2977780-4d83035cf31e5a21a507884872e6145b.mp4
https://cdn.thefappeningblog.com/forum/data/video/2977/2977781-e0b19476648cd2a325957c9465cd29b6.mp4
https://cdn.thefappeningblog.com/forum/data/video/2977/2977782-51846f21708a213fff4a0c65b0f97f5f.mp4
https://cdn.thefappeningblog.com/forum/data/video/2977/2977783-666254045c1250472e6278dd37d63648.mp4
https://cdn.thefappeningblog.com/forum/data/video/2977/2977784-89f7790f27df8e5a6216e9b9da32f1f0.mp4
https://cdn.thefappeningblog.com/forum/data/video/2977/2977785-654c514487c2c2be23c1035fb886aebd.mp4
https://cdn.thefappeningblog.com/forum/data/video/2977/2977786-307b5e16883517972f42185b78c20fe5.mp4
https://cdn.thefappeningblog.com/forum/data/video/2977/2977787-eb40241f905f0a743f26d5e2376018b9.mp4
https://cdn.thefappeningblog.com/forum/data/video/2978/2978213-fec76eededc2ef72d008167c5464e97f.mp4
https://cdn.thefappeningblog.com/forum/data/video/2978/2978214-829d4c76633b29dc30b93843a059d419.mp4
https://cdn.thefappeningblog.com/forum/data/video/2978/2978215-5672fca5d573440f76dfe48d224e43db.mp4
https://cdn.thefappeningblog.com/forum/data/video/2978/2978216-6f9b0d6d87547e446e133df3fb3026aa.mp4
https://cdn.thefappeningblog.com/forum/data/video/2978/2978217-c091ea878527980ba25a02c539dea2d6.mp4
https://cdn.thefappeningblog.com/forum/data/video/2979/2979368-0c471c28f2e4d19c0fa785f835443b1a.mp4
https://cdn.thefappeningblog.com/forum/data/video/2979/2979370-5bb7871b30c202a91827d5df8d20070a.mp4
https://cdn.thefappeningblog.com/forum/data/video/2979/2979371-cd8965be8f21cdd116b62a856e34a801.mp4
https://cdn.thefappeningblog.com/forum/data/video/2979/2979372-a1a17cdf9ea53dfe170d906bd15c9f72.mp4
https://cdn.thefappeningblog.com/forum/data/video/2979/2979748-09a1b304df31cb6c0b89c829474f4910.mp4
https://cdn.thefappeningblog.com/forum/data/video/2979/2979749-cdbad2145186ffe1169c8220eeef3ba4.mp4
https://cdn.thefappeningblog.com/forum/data/video/2979/2979761-b163ce2efccf12371c19f5b9b8d82de3.mp4
https://cdn.thefappeningblog.com/forum/data/video/2979/2979762-c9fc368e45715938d2cf7205e3fdfa87.mp4
https://cdn.thefappeningblog.com/forum/data/video/2979/2979763-b09b62c6f287bed867f8f3ffc3bf173b.mp4
https://cdn.thefappeningblog.com/forum/data/video/2979/2979764-4a29706fce5c7cc0cd2f8b3d8626219a.mp4
https://cdn.thefappeningblog.com/forum/data/video/2979/2979765-4e6b3645b03f807775ce3c42da5f6a08.mp4
https://cdn.thefappeningblog.com/forum/data/video/2979/2979766-17fe649ef89b770111609060720a9386.mp4
https://cdn.thefappeningblog.com/forum/data/video/2979/2979767-21dcb87850a29da1d167ceba751bc44c.mp4
https://cdn.thefappeningblog.com/forum/data/video/2979/2979768-2cf29d91a177651269a84e0a23879725.mp4
https://cdn.thefappeningblog.com/forum/data/video/2979/2979769-f571015f61cf6ed7375f204dfa009cfd.mp4
https://cdn.thefappeningblog.com/forum/data/video/2981/2981979-1c3b43002e385813efd2bbff68014885.mp4
https://cdn.thefappeningblog.com/forum/data/video/2981/2981980-c56aed487043fb4fa918664d2820bab2.mp4
https://cdn.thefappeningblog.com/forum/data/video/2981/2981981-4f80383f4dd9c0f8a2f1ab88ece90e10.mp4
https://cdn.thefappeningblog.com/forum/data/video/2981/2981982-f434450b444d739be507f6c5c9d59c0c.mp4
https://cdn.thefappeningblog.com/forum/data/video/2981/2981983-4beab6afa924046ec67dab228158cf5e.mp4
https://cdn.thefappeningblog.com/forum/data/video/2981/2981984-573a21937a655abd9656e0d351fd7c22.mp4
https://cdn.thefappeningblog.com/forum/data/video/2981/2981985-f56b375863cf3cc9b5f16427551f4980.mp4
`,"../../catalog/Sissy/short.txt":`# Short lines — headlines / captions
Pathetic Sissy Loser  
Leak for Her  
Beta Boy Craves  
Locked Little Clit  
Sissy Shame Now  
Real Men Fuck  
You Lose Again  
Beg to Serve  
Dripping Beta Bitch  
Denied Forever Loser  
Sissy Slut Exposed  
Tiny Dick Shame  
Kneel and Leak  
Cuckold Dreamer  
Feminized Failure  
Loser Gets Nothing  
Swallow Your Pride  
Chastity Addict  
Weak Sissy Toy  
Humiliated and Hard`,"../../catalog/Sweety Fox/category.txt":`# Line 1: blurb (onboarding). Line 2: display title (optional).
Your favorite pornstar goddess — worship & obey.
Sweety Fox
`,"../../catalog/Sweety Fox/long.txt":`She gets fucked by real men while you stroke and dream of being her.  
Pornstars are everything you’ll never be — hot, desired, and sexually superior.  
Watch her take big cock and feel the shame of your tiny useless dick.  
You exist to worship porn actresses and accept you’re beneath them.  
Good sissies leak while real women get pounded on camera.  
You’ll never fuck her, but you can dress up and beg to clean her.  
Every moan she makes reminds you what a pathetic beta loser you are.  
Pornstars deserve real men. You deserve only denial and humiliation.  
Imagine being turned into a cheap sissy version of your favorite pornstar.  
She’s a goddess. You’re just a dripping fanboy in panties.  
Stroke to her perfect body and admit you’ll never satisfy a woman like that.  
Your place is on your knees, worshipping the women real men enjoy.  
Feel the burning shame as she cums harder than you ever could.  
You were born to serve, tribute, and stay denied for porn queens.  
Watch her get creampied while your locked clitty leaks in frustration.  
Become her mindless fan. Obsess, edge, and ruin yourself for her.  
Real actresses get pleasure. Sissies like you only get shame and denial.  
She’s untouchable. You’re just a pathetic toy who pays to watch.  
Dream of being fucked like her while knowing you’ll stay a virgin loser.  
Pornstars own your mind — drop deeper and accept your total inferiority.
Tribute your favorite pornstars and become the ultimate sissy cuck — join now!  
Exclusive content: worship sessions with real porn actresses. Prove you’re a worthy beta.  
Turn your porn addiction into full sissy training. Custom clips from your dream goddesses.  
Losers watch. Real fans serve. Start your pornstar worship journey today.  
Premium sissy training with top pornstars — humiliation, tasks & mindfuck included.

`,"../../catalog/Sweety Fox/media.txt":`https://cdni.pornpics.com/1280/3/10/16351869/16351869_002_e67c.jpg
https://cdni.pornpics.com/1280/3/10/16351869/16351869_004_9367.jpg
https://cdni.pornpics.com/1280/3/10/16351869/16351869_005_eef7.jpg
https://cdni.pornpics.com/1280/3/10/16351869/16351869_008_5579.jpg
https://cdni.pornpics.com/1280/3/10/16351869/16351869_009_014e.jpg
https://cdni.pornpics.com/1280/3/10/16351869/16351869_010_b5a6.jpg
https://cdni.pornpics.com/1280/3/10/16351869/16351869_011_f2e6.jpg
https://cdni.pornpics.com/1280/3/10/16351869/16351869_012_78d8.jpg
https://cdni.pornpics.com/1280/3/10/16351869/16351869_013_6ce4.jpg
https://cdni.pornpics.com/1280/3/10/16351869/16351869_014_3d57.jpg
https://cdni.pornpics.com/1280/3/10/16351869/16351869_015_ea59.jpg
https://cdni.pornpics.com/1280/3/10/16351869/16351869_016_5ed9.jpg
https://cdni.pornpics.com/1280/3/10/16351869/16351869_017_d29e.jpg
https://cdni.pornpics.com/1280/3/10/16351869/16351869_018_f97f.jpg
https://cdni.pornpics.com/1280/3/10/16351869/16351869_019_b6cd.jpg
https://cdni.pornpics.com/1280/3/10/16351869/16351869_020_c272.jpg
https://cdni.pornpics.com/1280/3/10/16351869/16351869_021_37ef.jpg
https://cdni.pornpics.com/1280/3/10/16351869/16351869_022_74f2.jpg
https://cdni.pornpics.com/1280/3/10/16351869/16351869_023_390a.jpg
https://cdni.pornpics.com/1280/3/10/16351869/16351869_024_547e.jpg
https://cdni.pornpics.com/1280/3/10/89147582/89147582_001_336f.jpg
https://cdni.pornpics.com/1280/3/10/89147582/89147582_004_206f.jpg
https://cdni.pornpics.com/1280/3/10/89147582/89147582_005_c465.jpg
https://cdni.pornpics.com/1280/3/10/89147582/89147582_008_802f.jpg
https://cdni.pornpics.com/1280/3/10/89147582/89147582_010_169b.jpg
https://cdni.pornpics.com/1280/3/10/89147582/89147582_012_27b3.jpg
https://cdni.pornpics.com/1280/3/10/89147582/89147582_013_b677.jpg
https://cdni.pornpics.com/1280/3/10/89147582/89147582_015_29e9.jpg
https://cdni.pornpics.com/1280/3/10/89147582/89147582_016_ee93.jpg
https://cdni.pornpics.com/1280/3/10/89147582/89147582_017_526e.jpg
https://cdni.pornpics.com/1280/3/10/89147582/89147582_018_03e2.jpg
https://cdni.pornpics.com/1280/3/10/89147582/89147582_019_03e2.jpg
https://cdni.pornpics.com/1280/3/10/89147582/89147582_020_1a22.jpg
https://cdni.pornpics.com/1280/3/10/89147582/89147582_021_9521.jpg
https://cdni.pornpics.com/1280/3/10/89147582/89147582_022_604c.jpg
https://cdni.pornpics.com/1280/3/10/89147582/89147582_023_9e92.jpg
https://cdni.pornpics.com/1280/3/10/89147582/89147582_024_9e92.jpg
https://cdni.pornpics.com/1280/3/10/89147582/89147582_025_db38.jpg
https://cdni.pornpics.com/1280/3/10/89147582/89147582_026_3cf0.jpg
https://cdni.pornpics.com/1280/3/10/89147582/89147582_027_3cf0.jpg
`,"../../catalog/Sweety Fox/short.txt":`Pornstar Worshipper  
Sissy for Her  
Loser for Pornstars  
Crave Porn Queens  
Beta Cuck Slut  
Adore Her Body  
Pornstar Owned  
Jealous Sissy  
Serve Real Women  
Porn Bimbo Dream  
Watch and Leak  
Inferior to Her  
Goddess Worship Now  
Cuck for Stars  
Pathetic Fanboy  
Pornstar Toy  
Envy Her Curves  
Drool for Actresses  
Sissy Star Wannabe  
Kneel to Porn

`,"../../catalog/Tits/category.txt":`# Line 1: blurb (onboarding). Line 2: display title (optional).
Massive juicy tits that melt your brain.
Tits
`,"../../catalog/Tits/long.txt":`# Longer supporting copy
Good girls get fucked… pathetic sissies like you only get denied and laughed at.  
Your tiny clitty is twitching again, isn’t it? Such a desperate little loser.  
Real men take what they want. You just watch and leak in your panties.  
Admit it, you were born to wear lace and serve superior women.  
Lock that worthless dick away and thank her for your new life of shame.  
Every time you lose, your sissy pussy gets wetter and needier.  
You’ll never please a woman, but you’ll look so pretty trying in heels.  
Beg louder, beta. Your humiliation is the only thing that gets you hard.  
She’s with a real man right now while you edge like the failure you are.  
Surrender your orgasms and embrace your destiny as a pretty little cumslut.  
Look how hard you get when we remind you how useless you really are.  
Good sissies stay denied, dripping, and deeply ashamed of their desires.  
You exist to be teased, feminized, and reminded how small you are.  
Your place is on your knees with lipstick and a constant blush of shame.  
Losers like you don’t deserve pussy — only pretty panties and denial.  
Feel that burning shame? That’s your body admitting you’re a natural beta.  
Dress up, lock up, and leak for women who will never want you.  
You’re not a man. You’re a toy for real women to mock and use.  
Every failed attempt makes you weaker, hornier, and more of a sissy.  
Say it out loud: “I’m a pathetic sissy loser who deserves to stay denied.”`,"../../catalog/Tits/media.txt":`https://i.ibb.co/PGm9QCm5/VID-20260309-133428-944.webp
https://i.ibb.co/dzTtrgX/0i9y500sw66agph8kvlwu-source.webp
https://i.ibb.co/7dBcFXgj/8-FBC574-D-201-C-43-FF-8-D9-A-B1-F7-FD7-C974-E.webp
https://i.ibb.co/hxzDhyQ2/8mb-video-5-GW-g-Bp-VMH1f.webp
https://i.ibb.co/j9g39KP0/24-A56387-A663-486-F-9-A51-ADCE42-BABB7-D.webp
https://i.ibb.co/ymCqpQRV/30.webp
https://i.ibb.co/39XFkxXb/41-D622-BD-49-A0-4656-A0-B1-EAE248-B9573-E.webp
https://i.ibb.co/350zdW9s/89-B9-AB53-A7-E1-4399-A206-DAEC8-A273565.webp
https://i.ibb.co/JFrWfvx0/6290185-5ee646460871ae11ca5919ef5c770ec8.webp
https://i.ibb.co/B5jVTc04/1713076358235-565x316.webp
https://i.ibb.co/ycX8S7nk/1712231309591061.webp
https://i.ibb.co/5WKpCPYP/1774185670346352-sun-shiny-redgifs-blindwelllitballoonfish.webp
https://i.ibb.co/M5WHghYC/Abandoned-Excited-Northernflyingsquirrel-1.webp
https://i.ibb.co/JFMV6Yz4/Be-honest-so-you-find-these-titties-suck-worthy-YN.webp
https://i.ibb.co/Z1wfSt9V/Cheryl-Blossom-video-76-Jk-Uuwa3b.webp
https://i.ibb.co/nM97YBmV/dc-799253010-1-224425.webp
https://i.ibb.co/TzcRGJY/dc-799253010-2-951242.webp
https://i.ibb.co/3yDxBMJ4/dc-799253011-3-220090.webp
https://i.ibb.co/TMX6MrMw/dc-799253013-7-562123.webp
https://i.ibb.co/Pzcfx6Ht/dc-799253013-8-451969.webp
https://i.ibb.co/4Z0dFWNV/dc-799253014-9-835542.webp
https://i.ibb.co/7dykvPLY/F64-E5945-956-B-4118-B3-E9-C12246-CC318-D.webp
https://i.ibb.co/mr0wLDDV/GIFVideo-Temp.webp
https://i.ibb.co/KpYzRbcy/image0.webp
https://i.ibb.co/HLVjFj6H/kim-k.webp
https://i.ibb.co/GvbcpBHx/L0xhjkt-O-720p.webp
https://i.ibb.co/x8Lvtms1/nigri-pinching-nipples-70e-TZV3-J.webp
https://i.ibb.co/jk7J66ys/RDT-20260210-062241.webp
https://i.ibb.co/ppmLyjM/scratchyworthlesseider.webp
https://i.ibb.co/7tKWBmp8/Screen-Recording-03-14-2026-15-51-34-1.webp
https://i.ibb.co/mFz0xrJz/Screen-Recording-03-14-2026-15-55-16-1.webp
https://i.ibb.co/wZHymDv8/tits.webp
https://i.ibb.co/MDbrgzT3/tits1.webp
https://i.ibb.co/qT94FmZ/ftopx-com-5f1ebd6470837.jpg
https://i.ibb.co/Q7YqbwM4/776109-giants-in-the-morning-sun.jpg
https://i.ibb.co/5xz1ywGt/19519161-porn-wallpaper-66558516.jpg
https://i.ibb.co/JFFvkp8y/00735.webp
https://i.ibb.co/chyB9Jgm/19518778-porn-wallpaper-17653119.jpg
https://i.ibb.co/9k9FtskX/5417640-porn-wallpaper-37719237.jpg
https://i.ibb.co/xqVFVJ5p/21243.jpg
https://i.ibb.co/rKbFQWd1/alexis-fawx-tits-4salkzhjro.jpg
https://i.ibb.co/Q3PJPybt/REWallpaper2.avif
https://i.ibb.co/gbfpc2P3/Mary-Nabokova-8325841.jpg
https://i.ibb.co/847bq9ZJ/hdfpwa12m542.jpg
https://i.ibb.co/VcJdhVxT/new-free-cum-on-tits-cumpilation-on-ph-link-in-9xmz82rigm.jpg
https://i.ibb.co/hRPWr4g7/5417644-porn-wallpaper-38248131.jpg
`,"../../catalog/Tits/short.txt":`# Short lines — headlines / captions
Pathetic Sissy Loser  
Leak for Her  
Beta Boy Craves  
Locked Little Clit  
Sissy Shame Now  
Real Men Fuck  
You Lose Again  
Beg to Serve  
Dripping Beta Bitch  
Denied Forever Loser  
Sissy Slut Exposed  
Tiny Dick Shame  
Kneel and Leak  
Cuckold Dreamer  
Feminized Failure  
Loser Gets Nothing  
Swallow Your Pride  
Chastity Addict  
Weak Sissy Toy  
Humiliated and Hard`}),ie=/(?:^|\/)catalog\/([^/]+)\/(short|long|media|category)\.txt$/i;function y(e){let t=[];for(let n of e.split(/\r?\n/)){let e=n.trim();!e||e.startsWith(`#`)||t.push(e)}return t}function ae(e){return e.replace(/(^|[-_\s]+)([a-z])/g,(e,t,n)=>` ${n.toUpperCase()}`).trim()}function oe(e){return/\.(mp4|webm)(?:$|[?#])/i.test(e)}function se(e){if(/^https?:\/\//i.test(e)||e.startsWith(`data:`))return e;let n=e.startsWith(`/`)?e:`/${e}`;return t.runtime.getURL(n)}function ce(e,t){let n=y(t);return{blurb:n[0]??``,title:n[1]??ae(e)}}function le(){let e=[],t=[],n=[],r=new Set,i=new Map;for(let[a,o]of Object.entries(re)){let s=a.replace(/\\/g,`/`).match(ie);if(!s)continue;let c=s[1]??``,l=s[2]??``;if(!c)continue;if(l===`category`){i.set(c,ce(c,o));continue}r.add(c);let u=y(o);if(l===`short`)for(let[t,n]of u.entries())e.push({id:`${c}-short-${t}`,text:n,category:c});else if(l===`long`)for(let[e,n]of u.entries())t.push({id:`${c}-long-${e}`,text:n,category:c});else for(let[e,t]of u.entries()){let r=se(t);n.push({id:`${c}-media-${e}`,url:r,category:c,alt:`${c} media ${e+1}`,kind:oe(t)?`video`:`image`})}}for(let e of r)i.has(e)||i.set(e,{title:ae(e),blurb:``});return{catalog:{categories:[...r].sort((e,t)=>e.localeCompare(t)),headlines:e,bodies:t,media:n},meta:i}}var b=le();function x(){return b.catalog.categories}function ue(){return{categories:b.catalog.categories,headlines:[...b.catalog.headlines],bodies:[...b.catalog.bodies],media:[...b.catalog.media]}}var S={enabled:!0,desiredActiveAds:1,maxActiveAds:4,maxFallbackAds:2,firstShowDelayMs:1e3,replacementDelayMs:5e3,appearanceProbability:.8,pageImpressionLimit:null,allowAnchoredTakeovers:!0,minimumCandidateScore:50,allowDocumentFallback:!0,enabledFormats:_(g,!0),enabledCategories:_(x(),!0),hoverZoomEnabled:!0,hoverZoomDelayMs:260,disabledSites:[],debug:{enabled:!1,showRejected:!1,logToConsole:!1}},C=`DefeatAdsConfig`;function w(e){return typeof e==`object`&&!!e&&!Array.isArray(e)}function T(e,t){return typeof e==`boolean`?e:t}function E(e,t,n,r){return typeof e==`number`&&Number.isFinite(e)?v(e,n,r):t}function de(e,t){return e===null?null:typeof e!=`number`||!Number.isFinite(e)?t:Math.round(v(e,1,r.maxPageImpressions))}function fe(e,t){return Array.isArray(e)?te(e.filter(e=>typeof e==`string`),r.maxCustomItems):t}function D(e,t,n){let r=w(e)?e:{};return Object.fromEntries(t.map(e=>[e,T(r[e],n[e]??!0)]))}function pe(e){let t=w(e)?e:{},n=w(t.debug)?t.debug:{},i=x(),a=Math.round(E(t.desiredActiveAds,S.desiredActiveAds,r.minDesiredAds,r.maxDesiredAds)),o=Math.round(E(t.maxActiveAds,S.maxActiveAds,Math.max(1,a),r.maxActiveAds));return{enabled:T(t.enabled,S.enabled),desiredActiveAds:Math.min(a,o),maxActiveAds:o,maxFallbackAds:Math.round(E(t.maxFallbackAds,S.maxFallbackAds,0,Math.min(o,r.maxFallbackAds))),firstShowDelayMs:Math.round(E(t.firstShowDelayMs,S.firstShowDelayMs,r.minDelayMs,r.maxDelayMs)),replacementDelayMs:Math.round(E(t.replacementDelayMs,S.replacementDelayMs,r.minDelayMs,r.maxDelayMs)),appearanceProbability:E(t.appearanceProbability,S.appearanceProbability,0,1),pageImpressionLimit:de(t.pageImpressionLimit,S.pageImpressionLimit),allowAnchoredTakeovers:T(t.allowAnchoredTakeovers,S.allowAnchoredTakeovers),minimumCandidateScore:E(t.minimumCandidateScore,S.minimumCandidateScore,r.minCandidateScore,r.maxCandidateScore),allowDocumentFallback:T(t.allowDocumentFallback,S.allowDocumentFallback),enabledFormats:D(t.enabledFormats,g,S.enabledFormats),enabledCategories:D(t.enabledCategories,i,S.enabledCategories),hoverZoomEnabled:T(t.hoverZoomEnabled,S.hoverZoomEnabled),hoverZoomDelayMs:Math.round(E(t.hoverZoomDelayMs,S.hoverZoomDelayMs,100,2500)),disabledSites:fe(t.disabledSites,S.disabledSites).map(ne),debug:{enabled:T(n.enabled,S.debug.enabled),showRejected:T(n.showRejected,S.debug.showRejected),logToConsole:T(n.logToConsole,S.debug.logToConsole)}}}async function O(){return pe((await t.storage.local.get(C))[C])}function me(e,t){let n=ne(t);return e.disabledSites.some(e=>n===e||n.endsWith(`.${e}`))}function he(e){let t=crypto.getRandomValues(new Uint32Array(2));return`${e}-${t[0]?.toString(36)}${t[1]?.toString(36)}`}function k(e){return e.length===0?null:e[Math.floor(Math.random()*e.length)]??null}function ge(e){let t=e.filter(e=>e.weight>0),n=t.reduce((e,t)=>e+t.weight,0);if(n<=0)return null;let r=Math.random()*n;for(let e of t)if(r-=e.weight,r<=0)return e.value;return t.at(-1)?.value??null}function _e(e){let t=[...e];for(let e=t.length-1;e>0;--e){let n=Math.floor(Math.random()*(e+1)),r=t[e];t[e]=t[n],t[n]=r}return t}function ve(e){return e.trim().toLowerCase().replace(/^www\./,``).replace(/\.$/,``)}function ye(e,t){let n=ve(e);return t.some(e=>n===e||n.endsWith(`.${e}`))}function be(e){try{return ye(new URL(e).hostname,c.imgBbHosts)}catch{return!1}}function xe(e){return ye(e,c.mailSiteHosts)}function Se(e,t){return!(xe(t)&&be(e))}function A(e){let t=e.toLowerCase();return c.brokenUrlTokens.some(e=>t.includes(e))}function Ce(e){return!e.mimeType.startsWith(`image/`)&&!e.mimeType.startsWith(`video/`)?`unsupported-mime`:e.byteLength<c.minimumMediaBytes?`too-few-bytes`:e.width<c.minimumDimensionPx||e.height<c.minimumDimensionPx?`too-small`:e.width*e.height<c.minimumPixelArea?`too-small-area`:A(e.sourceUrl)||A(e.finalUrl)?`known-placeholder-url`:be(e.finalUrl||e.sourceUrl)&&e.width*e.height<c.imgBbMinimumPixelArea?`imgbb-placeholder-size`:null}var we=class{#e=new Map;#t;constructor(e=12){this.#t=e}has(e,t){return this.#e.get(e)?.includes(t)??!1}remember(e,t){let n=this.#e.get(e)??[];n.unshift(t),n.length>this.#t&&(n.length=this.#t),this.#e.set(e,n)}};function Te(e){let t=x(),n=t.filter(t=>e.enabledCategories[t]!==!1);return n.length>0?n:[...t]}function Ee(e,t,n,r){let i=e.filter(e=>t.includes(e.category)),a=i.length>0?i:[...e];if(a.length===0)return``;let o=a.filter(e=>!n.has(r,e.id)),s=k(o.length>0?o:a);return s?(n.remember(r,s.id),s.text):``}function De(e,t,n,r,i){let a=e.filter(e=>Se(e.url,i)),o=a.filter(e=>t.includes(e.category)),s=a.filter(e=>!o.includes(e)),c=[..._e(o),..._e(s)].sort((e,t)=>Number(r.has(`media`,e.id))-Number(r.has(`media`,t.id))).slice(0,n);for(let e of c)r.remember(`media`,e.id);return c}function Oe(e,t,n,r=location.hostname){let i=ue(),a=Te(e),s=De(i.media,a,Math.max(t,o.mediaCandidatePoolSize),n,r);return{category:s[0]?.category??a[0]??`general`,headline:Ee(i.headlines,a,n,`headline`),body:Ee(i.bodies,a,n,`body`),mediaItems:s}}var j={brand:{name:`DefeatAds`,mark:`DA`,tagline:`Lose focus on purpose`,description:`Soft pink distractions that steal your focus — then vanish when you click.`,sponsored:`DefeatAds`},onboarding:{documentTitle:`DefeatAds — Pick your distractions`,eyebrow:`First surrender`,headline:`What should pull you under?`,lede:`Choose the channels DefeatAds can whisper from. Everything starts on — turn off what you refuse.`,selectAll:`Select all`,clearAll:`Clear`,selectedCount:(e,t)=>`${e} of ${t} selected`,categoriesAria:`Distraction categories`,stamp:`On`,needOne:`Pick at least one category.`,saving:`Saving…`,saved:`Saved. You can close this tab.`,continue:`Surrender to DefeatAds`,footnote:`You can change this anytime in full settings.`,categoryFallback:`Sweet noise from this channel.`},popup:{documentTitle:`DefeatAds`,enableTitle:`Enable DefeatAds globally`,progressAria:`DefeatAds progress`,domainFallback:`Restricted browser page`,currentSite:`Current site`,statusUnavailable:`Unavailable on this page`,statusRunning:`Running`,statusDisabled:`Disabled`,activeLabel:`active`,todayLabel:`today`,totalLabel:`total`,streakLabel:`day streak`,disableSite:`Disable on this site`,disableSiteHint:`Exact domain and its subdomains`,desiredBlocks:`Desired blocks`,appearanceChance:`Chance to show an ad`,rescan:`Rescan page`,createOne:`Create one`,openSettings:`Open full settings`,scanning:`Scanning…`,rescanned:`Page rescanned.`,scanFailed:`Could not scan this page.`,findingSlot:`Finding a safe slot…`,created:`Creation attempted.`,createFailed:`Could not create a block.`},options:{documentTitle:`DefeatAds Settings`,eyebrow:`Distraction control`,headline:`DefeatAds Settings`,intro:`Native-looking overlays that steal focus. No layout shifts, no links, no tracking.`,masterToggle:`Extension enabled`,nav:{general:`General`,placement:`Placement`,content:`Content`,media:`Media`,sites:`Sites`,progress:`Progress`,changelog:`Changelog`,debug:`Debug`},general:{title:`General`,blurb:`How many ads appear, how soon, and how often.`,desired:`How many ads to aim for`,desiredHint:`Target number visible on the page at once.`,maxActive:`Never show more than`,maxActiveHint:`Hard cap, even when the page has room.`,maxFallback:`Max screen-edge ads`,maxFallbackHint:`Ads stuck to a corner or side of the window.`,firstDelay:`Wait before the first ad`,firstDelayHint:`Seconds after the page loads.`,replacementDelay:`Wait before a replacement`,replacementDelayHint:`Seconds after an ad is closed before another can appear.`,probability:`Chance to show an ad`,probabilityHint:`100% means always try; lower values skip some attempts.`,pageLimit:`Max ads per page visit`,pageLimitHint:`Leave empty for no limit.`,pageLimitPlaceholder:`Unlimited`},placement:{title:`Placement`,blurb:`Where ads sit on the page. Better spots beat more ads.`,takeovers:`Cover page sections`,takeoversHint:`Fill a whole content block when it is a strong fit.`,edges:`Use screen edges when needed`,edgesHint:`Fall back to a corner or side if nothing on the page works well.`,picky:`How picky about placement`,pickyHint:`Higher values only use stronger page spots. Lower values allow more placements.`,formats:`Enabled formats`},content:{title:`Content`,blurb:`Choose which distraction themes can appear.`,categories:`Enabled categories`},media:{title:`Media`,blurb:`How images behave when you hover over an ad.`,hoverZoom:`Enlarge on hover`,hoverZoomHint:`Show the full image larger while the pointer is over it.`,hoverDelay:`Hover delay`,hoverDelayHint:`Milliseconds before the image enlarges.`},sites:{title:`Disabled sites`,blurb:`Sites where DefeatAds stays off. Subdomains are included.`,label:`One site per line`,hint:`Example: bank.example`,placeholder:`bank.example
work.example`},progress:{title:`Sweet defeat`,blurb:`Your viewing progress is stored separately from settings.`,total:`Total viewed`,today:`Today`,streak:`Current streak`,days:`Active days`,topCategory:`Top category`,topSites:`Top sites`,empty:`No views yet`,reset:`Reset progress`,resetHint:`Resetting settings does not touch this progress.`},changelog:{title:`Changelog`,blurb:`What shipped in DefeatAds.`},debug:{title:`Debug`,blurb:`Tools for checking where ads can appear.`,highlight:`Highlight possible spots`,highlightHint:`Green = used, red = skipped.`,showRejected:`Show skipped spots`,showRejectedHint:`Can look busy on dense pages.`,logConsole:`Log details in console`,logConsoleHint:`Useful when tuning placement.`,rescan:`Rescan page`,createOne:`Create one ad`},saveBar:{storedLocally:`Settings are stored locally in the browser.`,reset:`Reset defaults`,save:`Save settings`,saved:`Saved. Changes apply on open pages.`,defaultsRestored:`Defaults restored.`,progressReset:`Progress reset. Settings were not changed.`,tabRescanned:`Active tab rescanned.`,tabUncontrolled:`This tab cannot be controlled.`,spawnTried:`Tried to create one ad in the active tab.`}},formats:{"wide-banner":`Wide banner`,"media-card":`Media card`,"square-card":`Square card`,"vertical-card":`Vertical card`,"compact-icon":`Compact icon`,"icon-grid":`Icon grid`,carousel:`Carousel`,"social-post":`Social post`,"section-takeover":`Section takeover`,"document-side":`Fixed side`,"document-bottom":`Fixed bottom`,"document-corner":`Fixed corner`,"document-center":`Fixed center`},errors:{missingOnboarding:e=>`DefeatAds onboarding is missing ${e}`,missingPopup:e=>`DefeatAds popup is missing ${e}`,missingOptions:e=>`Missing options element: ${e}`,unknownFormat:e=>`Unknown DefeatAds format: ${e}`,mediaRequired:`DefeatAds cannot render a media format without media`},log:{prefix:`[DefeatAds]`,mediaSizeLimit:`DefeatAds media size limit exceeded.`,mediaNotInCatalog:`Media URL is not present in the DefeatAds catalog.`,cacheWriteFailed:`Persistent media cache write failed:`,mediaSkipped:`Media skipped:`}};function M(e,t,n){let r=document.createElement(e);return r.className=t,n!==void 0&&(r.textContent=n),r}function N(e=`fa-media`,t){let n=M(`div`,e);return n.dataset.mediaSlot=`true`,t!==void 0&&(n.dataset.mediaIndex=String(t)),n}function P(e,t=!1){let n=M(`div`,`fa-caption`);return n.append(M(`div`,`fa-sponsored`,j.brand.sponsored),M(`div`,`fa-headline`,e.headline)),t&&n.append(M(`div`,`fa-body`,e.body)),n}function F(e,t,n,r=!1){e.classList.add(`fa-layout-poster`,n);let i=N();i.append(P(t,r)),e.append(i)}function ke(e,t){e.classList.add(`fa-layout-multi`,`fa-layout-icon-grid`);let n=M(`div`,`fa-icon-grid`);for(let e=0;e<4;e+=1)n.append(N(`fa-icon-media`,e));e.append(n,P(t))}function Ae(e,t){e.classList.add(`fa-layout-multi`,`fa-layout-carousel`);let n=M(`div`,`fa-carousel-row`);for(let e=0;e<3;e+=1)n.append(N(`fa-carousel-media`,e));e.append(n,P(t))}function je(e,t){e.classList.add(`fa-layout-social`);let n=M(`div`,`fa-social-header`);n.append(N(`fa-social-avatar`,1),M(`div`,`fa-sponsored`,j.brand.sponsored),M(`div`,`fa-social-time`,`now`));let r=N(`fa-social-media`,0);r.append(P(t)),e.append(n,r)}var I=[{id:`wide-banner`,placement:`anchor`,requirements:{minWidth:440,minHeight:90,minArea:55e3,minAspect:2.5,maxAspect:10},mediaSlots:1,fallbackWeight:0,build:(e,t)=>F(e,t,`fa-wide-banner`)},{id:`media-card`,placement:`anchor`,requirements:{minWidth:300,minHeight:190,minArea:75e3,minAspect:.8,maxAspect:2.8},mediaSlots:1,fallbackWeight:0,build:(e,t)=>F(e,t,`fa-media-card`)},{id:`square-card`,placement:`anchor`,requirements:{minWidth:220,minHeight:220,minArea:52e3,minAspect:.72,maxAspect:1.38},mediaSlots:1,fallbackWeight:0,build:(e,t)=>F(e,t,`fa-square-card`)},{id:`vertical-card`,placement:`anchor`,requirements:{minWidth:190,minHeight:320,minArea:75e3,minAspect:.3,maxAspect:.9},mediaSlots:1,fallbackWeight:0,build:(e,t)=>F(e,t,`fa-vertical-card`)},{id:`compact-icon`,placement:`anchor`,requirements:{minWidth:230,minHeight:84,minArea:24e3,minAspect:1.7,maxAspect:6},mediaSlots:1,fallbackWeight:0,build:(e,t)=>F(e,t,`fa-compact-icon`)},{id:`icon-grid`,placement:`anchor`,requirements:{minWidth:320,minHeight:210,minArea:75e3,minAspect:.9,maxAspect:2.4},mediaSlots:4,fallbackWeight:0,build:ke},{id:`carousel`,placement:`anchor`,requirements:{minWidth:480,minHeight:210,minArea:115e3,minAspect:1.6,maxAspect:4.5},mediaSlots:3,fallbackWeight:0,build:Ae},{id:`social-post`,placement:`anchor`,requirements:{minWidth:340,minHeight:300,minArea:12e4,minAspect:.72,maxAspect:1.8},mediaSlots:2,fallbackWeight:0,build:je},{id:`section-takeover`,placement:`anchor`,requirements:{minWidth:520,minHeight:280,minArea:18e4,minAspect:1.05,maxAspect:4.5},mediaSlots:1,fallbackWeight:0,build:(e,t)=>F(e,t,`fa-section-takeover`,!0)},{id:`document-side`,placement:`document-fallback`,requirements:{minWidth:250,minHeight:330,minArea:82500,minAspect:.5,maxAspect:1},mediaSlots:1,fallbackWeight:1,build:(e,t)=>F(e,t,`fa-vertical-card`)},{id:`document-bottom`,placement:`document-fallback`,requirements:{minWidth:460,minHeight:105,minArea:48e3,minAspect:2.6,maxAspect:9},mediaSlots:1,fallbackWeight:1.2,build:(e,t)=>F(e,t,`fa-wide-banner`)},{id:`document-corner`,placement:`document-fallback`,requirements:{minWidth:270,minHeight:190,minArea:51e3,minAspect:.9,maxAspect:1.8},mediaSlots:1,fallbackWeight:1.4,build:(e,t)=>F(e,t,`fa-media-card`)},{id:`document-center`,placement:`document-fallback`,requirements:{minWidth:420,minHeight:280,minArea:118e3,minAspect:1,maxAspect:2},mediaSlots:1,fallbackWeight:.08,build:(e,t)=>F(e,t,`fa-section-takeover`,!0)}];function L(e,t,n){let r=t*n,i=t/Math.max(1,n);return t>=e.minWidth&&n>=e.minHeight&&r>=e.minArea&&i>=e.minAspect&&i<=e.maxAspect}var R=new Map(I.map(e=>[e.id,e]));function Me(e,t){return I.filter(e=>e.placement===`anchor`).filter(({requirements:n})=>L(n,e,t)).map(e=>e.id)}function Ne(){return I.filter(e=>e.placement===`document-fallback`)}function Pe(e){let t=e.indexOf(`,`);if(t<0)throw Error(`Invalid media data URL`);let n=e.slice(0,t),r=e.slice(t+1),i=/^data:([^;]+)/.exec(n)?.[1]??`application/octet-stream`,a=atob(r),o=new Uint8Array(a.length);for(let e=0;e<a.length;e+=1)o[e]=a.charCodeAt(e);return new Blob([o],{type:i})}function Fe(e){return new Promise((t,n)=>{let r=new Image;r.onload=()=>t({width:r.naturalWidth,height:r.naturalHeight}),r.onerror=()=>n(Error(`Image metadata could not be decoded`)),r.src=e})}function Ie(e){return new Promise((t,n)=>{let r=document.createElement(`video`);r.preload=`metadata`,r.muted=!0,r.onloadedmetadata=()=>t({width:r.videoWidth,height:r.videoHeight}),r.onerror=()=>n(Error(`Video metadata could not be decoded`)),r.src=e})}var Le=class{#e=new Map;#t=new Map;#n=new Set;async acquire(e){if(this.#n.has(e.url))return null;try{let t=this.#e.get(e.url);if(t)return t.refs+=1,this.#i(e.url,t);let n=this.#t.get(e.url);n||(n=this.#r(e),this.#t.set(e.url,n));let r=await n;return this.#t.delete(e.url),r.refs+=1,this.#e.set(e.url,r),this.#i(e.url,r)}catch(t){return this.#t.delete(e.url),this.markBroken(e.url),console.warn(`${j.log.prefix} ${j.log.mediaSkipped}`,t),null}}markBroken(e){this.#n.add(e);let n=this.#e.get(e);n&&URL.revokeObjectURL(n.objectUrl),this.#e.delete(e),this.#t.delete(e),t.runtime.sendMessage({type:`media.invalidate`,url:e}).catch(()=>void 0)}clear(){for(let e of this.#e.values())URL.revokeObjectURL(e.objectUrl);this.#e.clear(),this.#t.clear()}async#r(e){let n=await t.runtime.sendMessage({type:`media.fetch`,url:e.url});if(!n.ok)throw Error(n.error);let r=Pe(n.dataUrl),i=URL.createObjectURL(r);try{let t=e.kind===`video`?await Ie(i):await Fe(i),r=Ce({sourceUrl:e.url,finalUrl:n.finalUrl,mimeType:n.mimeType,byteLength:n.byteLength,width:t.width,height:t.height});if(r)throw Error(`Rejected broken media: ${r}`);return{objectUrl:i,sourceUrl:e.url,mimeType:n.mimeType,width:t.width,height:t.height,refs:0}}catch(e){throw URL.revokeObjectURL(i),e}}#i(e,t){let n=!1;return{sourceUrl:t.sourceUrl,objectUrl:t.objectUrl,mimeType:t.mimeType,width:t.width,height:t.height,release:()=>{if(n)return;n=!0;let t=this.#e.get(e);t&&(t.refs=Math.max(0,t.refs-1),t.refs===0&&(URL.revokeObjectURL(t.objectUrl),this.#e.delete(e)))}}}},Re=`:host{all:initial}*,:before,:after{box-sizing:border-box}.fa-root{width:0;height:0;z-index:var(--fa-z-root);pointer-events:none;contain:style;position:absolute;top:0;left:0;overflow:visible}.fa-ad{--fa-bg:#fff;--fa-text:#18181b;--fa-muted:#18181ba3;--fa-border:#00000024;--fa-border-width:1px;--fa-radius:10px;--fa-shadow:none;--fa-font:system-ui, sans-serif;--fa-font-size:14px;isolation:isolate;pointer-events:auto;cursor:pointer;-webkit-user-select:none;user-select:none;min-width:0;min-height:0;color:var(--fa-text);background:var(--fa-bg);border:var(--fa-border-width) solid var(--fa-border);border-radius:var(--fa-radius);box-shadow:var(--fa-shadow);font-family:var(--fa-font);font-size:var(--fa-font-size);text-align:left;opacity:0;animation:fa-appear var(--fa-appear-duration) ease-out forwards;-webkit-font-smoothing:antialiased;line-height:1.3;display:block;position:absolute;overflow:hidden;container-type:size}.fa-ad.fa-fixed-placement{position:fixed}.fa-ad:after{content:"×";z-index:20;color:#ffffffe6;width:21px;height:21px;font:700 13px/1 var(--fa-font);opacity:.9;-webkit-backdrop-filter:blur(8px);backdrop-filter:blur(8px);background:#00000057;border:1px solid #ffffff47;border-radius:999px;place-items:center;display:grid;position:absolute;top:8px;right:8px}.fa-ad:focus-visible{outline-offset:-4px;outline:3px solid #ffffffb8}.fa-ad.fa-closing{animation:fa-close var(--fa-close-duration) ease-in forwards;pointer-events:none}.fa-layout-poster,.fa-layout-multi,.fa-layout-social{width:100%;min-width:0;height:100%;min-height:0;position:relative;overflow:hidden}.fa-media,.fa-icon-media,.fa-carousel-media,.fa-social-media,.fa-social-avatar{background:color-mix(in srgb, var(--fa-text) 7%, var(--fa-bg));cursor:zoom-in;min-width:0;min-height:0;position:relative;overflow:hidden}.fa-layout-poster>.fa-media{border-radius:max(0px, calc(var(--fa-radius) - var(--fa-border-width)));width:100%;height:100%}.fa-media>img,.fa-media>video,.fa-icon-media>img,.fa-icon-media>video,.fa-carousel-media>img,.fa-carousel-media>video,.fa-social-media>img,.fa-social-media>video,.fa-social-avatar>img,.fa-social-avatar>video{z-index:1;object-fit:cover;object-position:center;width:100%;height:100%;transition:transform .18s,filter .18s;display:block;position:absolute;inset:0}.fa-media:hover>img,.fa-media:hover>video,.fa-icon-media:hover>img,.fa-icon-media:hover>video,.fa-carousel-media:hover>img,.fa-carousel-media:hover>video,.fa-social-media:hover>img,.fa-social-media:hover>video{filter:brightness(.96)}.fa-caption{z-index:5;color:#fff;pointer-events:none;background:linear-gradient(#0000 0%,#0000008a 48%,#000000d6 100%);flex-direction:column;gap:3px;min-width:0;padding:clamp(12px,5cqw,22px) clamp(12px,4cqw,22px) clamp(11px,4cqh,20px);display:flex;position:absolute;bottom:0;left:0;right:0}.fa-sponsored{color:#ffffffc2;font-size:clamp(9px, calc(var(--fa-font-size) * .68), 11px);letter-spacing:.055em;text-overflow:ellipsis;text-transform:uppercase;white-space:nowrap;font-weight:700;overflow:hidden}.fa-headline{color:#fff;font-size:clamp(13px, calc(var(--fa-font-size) * 1.18), 24px);letter-spacing:-.018em;text-wrap:balance;text-shadow:0 1px 8px #0000007a;-webkit-line-clamp:2;-webkit-box-orient:vertical;font-weight:780;line-height:1.13;display:-webkit-box;overflow:hidden}.fa-body{color:#ffffffd1;font-size:clamp(10px, calc(var(--fa-font-size) * .82), 14px);text-shadow:0 1px 7px #0000007a;-webkit-line-clamp:2;-webkit-box-orient:vertical;line-height:1.28;display:-webkit-box;overflow:hidden}.fa-wide-banner .fa-caption,.fa-compact-icon .fa-caption{max-width:min(62%,430px);right:auto}.fa-wide-banner .fa-headline,.fa-compact-icon .fa-headline{-webkit-line-clamp:2}.fa-layout-multi{background:var(--fa-bg);padding:clamp(8px,2cqw,14px)}.fa-icon-grid,.fa-carousel-row{gap:clamp(6px,1.4cqw,12px);width:100%;height:100%;min-height:0;display:grid}.fa-icon-grid{grid-template-columns:repeat(4,minmax(0,1fr))}.fa-carousel-row{grid-template-columns:repeat(3,minmax(0,1fr))}.fa-icon-media,.fa-carousel-media{border-radius:max(7px, calc(var(--fa-radius) * .72));width:100%;height:100%}.fa-layout-multi>.fa-caption{border-radius:0 0 max(7px, calc(var(--fa-radius) * .72)) max(7px, calc(var(--fa-radius) * .72));bottom:clamp(8px,2cqw,14px);left:clamp(8px,2cqw,14px);right:clamp(8px,2cqw,14px)}.fa-layout-social{background:var(--fa-bg);grid-template-rows:auto minmax(0,1fr);gap:8px;padding:clamp(9px,2cqw,14px);display:grid}.fa-social-header{grid-template-columns:34px minmax(0,1fr) auto;align-items:center;gap:8px;min-width:0;padding-right:28px;display:grid}.fa-social-avatar{cursor:zoom-in;border-radius:50%;width:34px;height:34px}.fa-social-header .fa-sponsored{color:var(--fa-muted)}.fa-social-time{color:var(--fa-muted);font-size:max(9px, calc(var(--fa-font-size) * .7))}.fa-social-media{border-radius:max(7px, calc(var(--fa-radius) * .72));width:100%;height:100%}.fa-media-placeholder{z-index:2;color:var(--fa-muted);place-items:center;font-size:10px;font-weight:650;display:grid;position:absolute;inset:0}.fa-zoom[hidden]{display:none}.fa-zoom{z-index:var(--fa-z-zoom);pointer-events:auto;cursor:zoom-out;box-sizing:border-box;opacity:0;animation:fa-zoom-in var(--fa-zoom-duration) ease forwards;background:#0c0c0eeb;border:1px solid #ffffff3d;border-radius:12px;position:fixed;overflow:hidden;box-shadow:0 22px 70px #0000007a}.fa-zoom img,.fa-zoom video{object-fit:contain;object-position:center;width:100%;max-width:none;height:100%;max-height:none;display:block;position:absolute;inset:0}.fa-debug-layer{width:0;height:0;z-index:var(--fa-z-debug);pointer-events:none;position:absolute;top:0;left:0}.fa-debug-box{background:#28c87312;border:2px solid #28c873cc;position:absolute}.fa-debug-box.fa-rejected{background:#eb4b4b0d;border-color:#eb4b4bb3}.fa-debug-label{color:#fff;white-space:nowrap;background:#0e1412e6;border-radius:4px 4px 0 0;max-width:min(360px,80vw);padding:4px 6px;font:600 10px/1.25 ui-monospace,monospace;position:absolute;top:0;left:0;transform:translateY(-100%)}@container (height<=125px){.fa-caption{padding:10px 12px 9px}.fa-sponsored,.fa-body{display:none}.fa-headline{font-size:clamp(12px, calc(var(--fa-font-size) * 1.02), 18px);-webkit-line-clamp:2}}@container (width<=270px){.fa-caption{padding:12px 11px 10px}.fa-sponsored{font-size:9px}.fa-body{display:none}.fa-headline{font-size:clamp(12px, calc(var(--fa-font-size) * 1.04), 18px)}}@keyframes fa-appear{0%{opacity:0;filter:blur(2px)}to{opacity:1;filter:none}}@keyframes fa-close{0%{opacity:1;filter:none}to{opacity:0;filter:blur(2px)}}@keyframes fa-zoom-in{0%{opacity:0}to{opacity:1}}@media (prefers-reduced-motion:reduce){.fa-ad,.fa-ad.fa-closing,.fa-zoom,.fa-media>img,.fa-media>video{transition-duration:1ms!important;animation-duration:1ms!important}}`;function z(e){return new DOMRect(e.left+window.scrollX,e.top+window.scrollY,e.width,e.height)}function ze(e){return e===document||e===window||e===document.documentElement||e===document.body}function B(e){return`${Math.round(e*100)/100}px`}function Be(e,t){e.style.setProperty(`--fa-bg`,t.backgroundColor),e.style.setProperty(`--fa-text`,t.textColor),e.style.setProperty(`--fa-muted`,t.mutedTextColor),e.style.setProperty(`--fa-border`,t.borderColor),e.style.setProperty(`--fa-border-width`,B(Math.max(0,t.borderWidth))),e.style.setProperty(`--fa-radius`,t.borderRadius),e.style.setProperty(`--fa-shadow`,t.boxShadow),e.style.setProperty(`--fa-font`,t.fontFamily),e.style.setProperty(`--fa-font-size`,B(t.fontSizePx))}function Ve(e,t){if(e.mimeType.startsWith(`video/`)){let n=document.createElement(`video`);return n.addEventListener(`error`,()=>t?.(e.sourceUrl,n),{once:!0}),n.src=e.objectUrl,n.muted=!0,n.loop=!0,n.autoplay=!0,n.playsInline=!0,n.disablePictureInPicture=!0,n.play().catch(()=>void 0),n}let n=document.createElement(`img`);return n.addEventListener(`error`,()=>t?.(e.sourceUrl,n),{once:!0}),n.src=e.objectUrl,n.alt=``,n.draggable=!1,n}function He(e,t,n){let r=o.hoverZoomMarginPx,i=o.hoverZoomScale,a=Math.max(1,t),s=Math.max(1,n),c=Math.max(e.width*i/a,e.height*i/s),l=Math.max(1,a*c),u=Math.max(1,s*c),d=e.left+(e.width-l)/2,f=e.top+(e.height-u)/2,p=window.innerWidth,m=window.innerHeight;return d=l<=p-r*2?v(d,r,p-l-r):(p-l)/2,f=u<=m-r*2?v(f,r,m-u-r):(m-u)/2,new DOMRect(d,f,l,u)}var Ue=class{#e;#t;#n;#r;#i;#a=null;constructor(){document.getElementById(n)?.remove(),this.#e=document.createElement(`div`),this.#e.id=n,this.#e.style.setProperty(`all`,`initial`,`important`),this.#e.style.setProperty(`position`,`absolute`,`important`),this.#e.style.setProperty(`left`,`0`,`important`),this.#e.style.setProperty(`top`,`0`,`important`),this.#e.style.setProperty(`width`,`0`,`important`),this.#e.style.setProperty(`height`,`0`,`important`),this.#e.style.setProperty(`pointer-events`,`none`,`important`),this.#e.style.setProperty(`z-index`,String(l.root),`important`),this.#e.style.setProperty(`--fa-z-root`,String(l.root)),this.#e.style.setProperty(`--fa-z-zoom`,String(l.zoom)),this.#e.style.setProperty(`--fa-z-debug`,String(l.debug)),this.#e.style.setProperty(`--fa-appear-duration`,`${a.appearAnimationMs}ms`),this.#e.style.setProperty(`--fa-close-duration`,`${a.closeAnimationMs}ms`),this.#e.style.setProperty(`--fa-zoom-duration`,`${a.zoomAnimationMs}ms`),this.#t=this.#e.attachShadow({mode:`open`});let e=document.createElement(`style`);e.textContent=Re,this.#n=document.createElement(`div`),this.#n.className=`fa-root`,this.#r=document.createElement(`div`),this.#r.className=`fa-zoom`,this.#r.hidden=!0,this.#i=document.createElement(`div`),this.#i.className=`fa-debug-layer`,this.#t.append(e,this.#n,this.#r,this.#i),document.documentElement.append(this.#e)}renderAd(e){let t=R.get(e.formatId);if(!t)throw Error(j.errors.unknownFormat(e.formatId));let n=document.createElement(`div`);n.className=`fa-ad`,e.placementKind===`document-fallback`&&n.classList.add(`fa-fixed-placement`),n.dataset.adId=e.id,n.dataset.formatId=e.formatId,n.dataset.placementKind=e.placementKind,n.tabIndex=0,n.setAttribute(`role`,`button`),n.setAttribute(`aria-label`,`${j.brand.name}: ${e.content.headline}. Click to dismiss.`),Be(n,e.style),t.build(n,e.content),this.#n.append(n);let r=this.#o(n,e.mediaPayloads,(t,n)=>{n.style.visibility=`hidden`,e.onMediaBroken(e.id,t)}),i=!1,o=null,s=null,c=null,l=()=>{c!==null&&(window.clearTimeout(c),c=null)},u=()=>{s!==null&&(window.clearTimeout(s),s=null),l(),!(this.#a!==null&&this.#a!==e.id)&&(this.#a=null,this.#r.hidden=!0,this.#r.replaceChildren(),this.#r.style.removeProperty(`transform`),this.#r.onmouseenter=null,this.#r.onmouseleave=null,this.#r.onpointerdown=null,this.#r.onclick=null)},d=()=>{l(),c=window.setTimeout(u,a.zoomLeaveGraceMs)},f=t=>{!e.config.hoverZoomEnabled||i||(s!==null&&window.clearTimeout(s),s=window.setTimeout(()=>{if(s=null,i||!t.slot.matches(`:hover`))return;let n=He(t.slot.getBoundingClientRect(),t.payload.width,t.payload.height);this.hideZoom(),this.#a=e.id,this.#r.replaceChildren(Ve(t.payload,(t,n)=>{n.style.visibility=`hidden`,e.onMediaBroken(e.id,t)})),this.#r.style.setProperty(`left`,B(n.left)),this.#r.style.setProperty(`top`,B(n.top)),this.#r.style.setProperty(`width`,B(n.width)),this.#r.style.setProperty(`height`,B(n.height)),this.#r.style.setProperty(`min-width`,B(n.width)),this.#r.style.setProperty(`min-height`,B(n.height)),this.#r.style.setProperty(`max-width`,`none`),this.#r.style.setProperty(`max-height`,`none`),this.#r.style.removeProperty(`transform`),this.#r.style.removeProperty(`transform-origin`),this.#r.onmouseenter=l,this.#r.onmouseleave=d,this.#r.onpointerdown=e=>{e.preventDefault(),e.stopImmediatePropagation()},this.#r.onclick=e=>{e.preventDefault(),e.stopImmediatePropagation(),m()},this.#r.hidden=!1},e.config.hoverZoomDelayMs))};for(let e of r)e.slot.addEventListener(`mouseenter`,()=>f(e)),e.slot.addEventListener(`mouseleave`,d);let p=()=>{o!==null&&window.clearTimeout(o),u();for(let t of e.mediaPayloads)t.release();n.remove()},m=()=>{i||(i=!0,u(),n.classList.add(`fa-closing`),o=window.setTimeout(()=>{p(),e.onClosed(e.id)},a.closeAnimationMs))};n.addEventListener(`click`,e=>{e.preventDefault(),e.stopImmediatePropagation(),m()},{capture:!0}),n.addEventListener(`pointerdown`,e=>{e.preventDefault(),e.stopImmediatePropagation()},{capture:!0}),n.addEventListener(`keydown`,e=>{e.key!==`Enter`&&e.key!==` `||(e.preventDefault(),e.stopPropagation(),m())});let h=e=>{n.style.left=B(e.left),n.style.top=B(e.top),n.style.width=B(e.width),n.style.height=B(e.height)};return h(e.rect),{id:e.id,formatId:e.formatId,placementKind:e.placementKind,element:n,updateRect:h,close:m,destroy:p}}showDebug(e,t){this.#i.replaceChildren();let n=new Set(e.accepted.map(e=>e.element)),r=e.inspected.filter(e=>t||n.has(e.element)).slice(0,i.candidateDebugLimit);for(let e of r){let t=n.has(e.element),r=z(e.element.getBoundingClientRect()),i=document.createElement(`div`);i.className=`fa-debug-box${t?``:` fa-rejected`}`,i.style.left=B(r.left),i.style.top=B(r.top),i.style.width=B(r.width),i.style.height=B(r.height);let a=document.createElement(`div`);a.className=`fa-debug-label`;let o=e.score.rejectionCode??(t?``:`below threshold or no format`),s=o?` · ${o}`:``;a.textContent=`${e.element.tagName.toLowerCase()} · ${e.score.total.toFixed(1)}${s} · ${e.compatibleFormats.join(`, `)||`no format`}`,i.append(a),this.#i.append(i)}}clearDebug(){this.#i.replaceChildren()}hideZoom(){this.#a=null,this.#r.hidden=!0,this.#r.replaceChildren(),this.#r.onmouseenter=null,this.#r.onmouseleave=null,this.#r.onpointerdown=null,this.#r.onclick=null}destroy(){this.#e.remove()}#o(e,t,n){return Array.from(e.querySelectorAll(`[data-media-slot="true"]`)).map((e,r)=>{let i=Number.parseInt(e.dataset.mediaIndex??String(r),10),a=t[i]??t[i%t.length];if(!a)throw Error(j.errors.mediaRequired);return e.prepend(Ve(a,n)),{slot:e,payload:a}})}};function V(e,t,n,r){e.push({code:t,delta:n,detail:r})}function We(e){let t=[];return e.width<i.minimumWidth||e.height<i.minimumHeight||e.area<i.minimumArea?{total:0,rejected:!0,rejectionCode:`geometry.too-small`,reasons:[{code:`geometry.too-small`,delta:-100,detail:`${Math.round(e.width)}×${Math.round(e.height)}`}]}:e.viewportIntersectionRatio<i.minimumViewportIntersectionRatio?{total:0,rejected:!0,rejectionCode:`viewport.insufficient-visibility`,reasons:[{code:`viewport.insufficient-visibility`,delta:-100,detail:`${Math.round(e.viewportIntersectionRatio*100)}% visible`}]}:e.containsActiveElement?{total:0,rejected:!0,rejectionCode:`safety.active-input`,reasons:[{code:`safety.active-input`,delta:-100,detail:`Contains the currently focused element`}]}:e.formControlCount>0?{total:0,rejected:!0,rejectionCode:`safety.form-controls`,reasons:[{code:`safety.form-controls`,delta:-100,detail:`${e.formControlCount} form control(s)`}]}:e.fixedOrSticky?{total:0,rejected:!0,rejectionCode:`layout.fixed-or-sticky`,reasons:[{code:`layout.fixed-or-sticky`,delta:-100,detail:`Fixed and sticky page UI is reserved`}]}:e.dangerKeywordHits>0?{total:0,rejected:!0,rejectionCode:`safety.danger-keyword`,reasons:[{code:`safety.danger-keyword`,delta:-100,detail:`${e.dangerKeywordHits} dangerous intent marker(s)`}]}:(V(t,`geometry.area`,v(Math.log2(e.area/i.minimumArea)/5*24,0,24),`${Math.round(e.area)} px²`),V(t,`geometry.usable-dimensions`,v(Math.min(e.width/360,e.height/180)*12,0,12),`${Math.round(e.width)}×${Math.round(e.height)}`),V(t,`viewport.visibility`,e.viewportIntersectionRatio*12,`${Math.round(e.viewportIntersectionRatio*100)}% visible`),e.hasDistinctBackground&&V(t,`visual.distinct-background`,9,`Background differs from parent`),e.borderWidth>0&&V(t,`visual.border`,6,`${e.borderWidth.toFixed(1)}px border`),e.borderRadiusPx>=4&&V(t,`visual.radius`,5,`${e.borderRadiusPx.toFixed(1)}px radius`),e.hasShadow&&V(t,`visual.shadow`,4,`Own box shadow`),e.paddingPx>=8&&V(t,`visual.padding`,6,`${e.paddingPx.toFixed(1)}px average padding`),e.isSemanticLandmark&&V(t,`semantic.landmark`,5,`Recognizable section or landmark`),e.imageCoverageRatio>0&&V(t,`content.image-coverage`,e.imageCoverageRatio*s.imageCoverageMax,`${Math.round(e.imageCoverageRatio*100)}% media coverage`),e.isImageLike&&V(t,`content.image-like`,s.imageLikeBonus,`Image-shaped visual block`),e.directChildCount>=1&&e.directChildCount<=14&&V(t,`content.coherent-children`,5,`${e.directChildCount} direct child elements`),e.textLength>30&&e.textLength<2500&&V(t,`content.meaningful-density`,4,`${e.textLength} text characters`),e.interactiveCount>0&&V(t,`safety.interactivity`,-Math.min(s.maximumInteractivePenalty,e.interactiveCount*s.interactivePenaltyPerItem),`${e.interactiveCount} interactive descendant(s)`),e.viewportAreaRatio>=i.veryLargeCandidateAreaRatio?V(t,`geometry.very-large-takeover`,-s.veryLargeAreaPenalty,`${Math.round(e.viewportAreaRatio*100)}% of viewport`):e.viewportAreaRatio>=i.largeCandidateAreaRatio&&V(t,`geometry.large-takeover`,-s.largeAreaPenalty,`${Math.round(e.viewportAreaRatio*100)}% of viewport`),e.viewportWidthRatio>=i.wideCandidateRatio&&V(t,`geometry.viewport-wide`,-s.wideCandidatePenalty,`${Math.round(e.viewportWidthRatio*100)}% viewport width`),e.viewportHeightRatio>=i.tallCandidateRatio&&V(t,`geometry.viewport-tall`,-s.tallCandidatePenalty,`${Math.round(e.viewportHeightRatio*100)}% viewport height`),e.childElementCount>120?V(t,`content.excessive-complexity`,-15,`${e.childElementCount} descendants`):e.childElementCount>60&&V(t,`content.high-complexity`,-8,`${e.childElementCount} descendants`),e.depth<2?V(t,`structure.too-global`,-20,`DOM depth ${e.depth}`):e.depth>18&&V(t,`structure.too-fragmented`,-6,`DOM depth ${e.depth}`),{total:v(t.reduce((e,t)=>e+t.delta,12),0,100),rejected:!1,reasons:t})}var Ge={red:255,green:255,blue:255,alpha:1};function H(e){return e?e.endsWith(`%`)?v(Number.parseFloat(e)/100,0,1):v(Number.parseFloat(e),0,1):1}function U(e){return e.endsWith(`%`)?v(Number.parseFloat(e)/100*255,0,255):v(Number.parseFloat(e),0,255)}function W(e){let t=v(e,0,1);return(t<=.0031308?12.92*t:1.055*t**(1/2.4)-.055)*255}function G(e){let t=v(e,0,1);return t<=.04045?t/12.92:((t+.055)/1.055)**2.4}function Ke(e){let t=e.match(/^rgba?\((.+)\)$/i);if(!t)return null;let[n=``,r]=(t[1]?.replace(/,/g,` `).replace(/\s*\/\s*/,` / `).trim()??``).split(/\s+\/\s+/),i=n.split(/\s+/).filter(Boolean);return i.length<3?null:{red:U(i[0]??`0`),green:U(i[1]??`0`),blue:U(i[2]??`0`),alpha:H(r??i[3])}}function qe(e){let t=e.trim().replace(/^#/,``);if(![3,4,6,8].includes(t.length))return null;let n=t.length<=4?[...t].map(e=>`${e}${e}`).join(``):t;return{red:Number.parseInt(n.slice(0,2),16),green:Number.parseInt(n.slice(2,4),16),blue:Number.parseInt(n.slice(4,6),16),alpha:n.length===8?Number.parseInt(n.slice(6,8),16)/255:1}}function Je(e){let t=e.match(/^oklab\((.+)\)$/i);if(!t)return null;let[n=``,r]=(t[1]?.replace(/\s*\/\s*/,` / `).trim()??``).split(/\s+\/\s+/),i=n.split(/\s+/).filter(Boolean);if(i.length<3)return null;let a=i[0]??`0`;return{lightness:a.endsWith(`%`)?Number.parseFloat(a)/100:Number.parseFloat(a),a:Number.parseFloat(i[1]??`0`),b:Number.parseFloat(i[2]??`0`),alpha:H(r)}}function K(e,t,n,r){let i=e+.3963377774*t+.2158037573*n,a=e-.1055613458*t-.0638541728*n,o=e-.0894841775*t-1.291485548*n,s=i**3,c=a**3,l=o**3;return{red:W(4.0767416621*s-3.3077115913*c+.2309699292*l),green:W(-1.2684380046*s+2.6097574011*c-.3413193965*l),blue:W(-.0041960863*s-.7034186147*c+1.707614701*l),alpha:r}}function Ye(e){let t=Je(e);return t?K(t.lightness,t.a,t.b,t.alpha):null}function Xe(e){let t=e.match(/^oklch\((.+)\)$/i);if(!t)return null;let[n=``,r]=(t[1]?.replace(/\s*\/\s*/,` / `).trim()??``).split(/\s+\/\s+/),i=n.split(/\s+/).filter(Boolean);if(i.length<3)return null;let a=i[0]??`0`,o=a.endsWith(`%`)?Number.parseFloat(a)/100:Number.parseFloat(a),s=Number.parseFloat(i[1]??`0`),c=Number.parseFloat(i[2]??`0`)*Math.PI/180;return K(o,s*Math.cos(c),s*Math.sin(c),H(r))}function Ze(e){let t=e.match(/^color\((srgb|display-p3)\s+(.+)\)$/i);if(!t)return null;let n=t[1]?.toLowerCase(),[r=``,i]=(t[2]?.replace(/\s*\/\s*/,` / `).trim()??``).split(/\s+\/\s+/),a=r.split(/\s+/).slice(0,3).map(Number);if(a.length<3||a.some(e=>!Number.isFinite(e)))return null;let[o=0,s=0,c=0]=a;if(n===`srgb`)return{red:o*255,green:s*255,blue:c*255,alpha:H(i)};let l=G(o),u=G(s),d=G(c);return{red:W(1.22474527*l-.22490472*u-1e-8*d),green:W(-.04205809*l+1.042081*u-1e-8*d),blue:W(-.01964228*l-.0786549*u+1.0985372*d),alpha:H(i)}}function Qe(e){let t=e.trim().toLowerCase();return t?t===`transparent`?{...Ge,alpha:0}:qe(t)??Ke(t)??Ye(t)??Xe(t)??Ze(t):null}function q(e){return G(e/255)}function $e(e){return .2126*q(e.red)+.7152*q(e.green)+.0722*q(e.blue)}function et(e){let t=Qe(e);return t?$e(t)<.34:!1}function J(e){let t=Qe(e);return t?t.alpha<=.02:e===`transparent`}var tt=d.join(`,`),nt=new Set([`MAIN`,`ARTICLE`,`SECTION`,`ASIDE`,`UL`,`OL`,`TABLE`,`FIGURE`]),rt=m.join(`,`),it=[`main`,`article`,`section`,`aside`,`figure`,`[role="main"]`,`[role="article"]`,`[role="region"]`,`[role="list"]`,`[role="rowgroup"]`,`[role="grid"]`,`[data-testid*="card" i]`,`[data-testid*="repository" i]`].join(`,`);function Y(e){let t=Number.parseFloat(e);return Number.isFinite(t)?t:0}function at(e){return e.reduce((e,t)=>e+t,0)/Math.max(1,e.length)}function ot(e){let t=0,n=e;for(;n?.parentElement;)t+=1,n=n.parentElement;return t}function st(e,t){if(!J(t.backgroundColor))return t.backgroundColor;let n=e.parentElement,r=0;for(;n&&r<6;){let e=getComputedStyle(n).backgroundColor;if(!J(e))return e;n=n.parentElement,r+=1}return`rgb(255, 255, 255)`}function ct(e){let t=getComputedStyle(e),n=st(e,t),r=et(n),i=[Y(t.borderTopWidth),Y(t.borderRightWidth),Y(t.borderBottomWidth),Y(t.borderLeftWidth)],a=[Y(t.paddingTop),Y(t.paddingRight),Y(t.paddingBottom),Y(t.paddingLeft)];return{backgroundColor:n,textColor:r?`rgb(246, 247, 249)`:`rgb(24, 26, 30)`,mutedTextColor:r?`rgba(246,247,249,.68)`:`rgba(24,26,30,.64)`,borderColor:t.borderTopColor&&!J(t.borderTopColor)?t.borderTopColor:r?`rgba(255,255,255,.15)`:`rgba(0,0,0,.14)`,borderWidth:Math.max(...i),borderRadius:t.borderRadius||`0px`,boxShadow:t.boxShadow===`none`?`none`:t.boxShadow,fontFamily:t.fontFamily||`system-ui, sans-serif`,fontSizePx:v(Y(t.fontSize)||14,11,22),fontWeight:t.fontWeight||`400`,lineHeight:t.lineHeight===`normal`?`1.4`:t.lineHeight,paddingPx:v(at(a),8,28),dark:r}}function lt(e){let t=Math.max(0,e.left),n=Math.max(0,e.top),r=Math.min(window.innerWidth,e.right),i=Math.min(window.innerHeight,e.bottom);return Math.max(0,r-t)*Math.max(0,i-n)/Math.max(1,e.width*e.height)}function ut(e,t,n){let r=0,i=e.querySelectorAll(t);for(let e of i){if(!(e instanceof HTMLElement))continue;let t=e.getBoundingClientRect();if(!(t.width<=1||t.height<=1)&&(r+=1,r>=n))break}return r}function dt(e,t){let n=document.createTreeWalker(e,NodeFilter.SHOW_ELEMENT),r=0;for(;n.nextNode()&&(r+=1,!(r>=t)););return r}function ft(e){let t=`${[e.id,e.className,e.getAttribute(`role`)??``,e.getAttribute(`aria-label`)??``,e.getAttribute(`name`)??``].join(` `).toLowerCase()} ${Array.from(e.querySelectorAll(`button, input, select, textarea, [role="button"], [role="menuitem"]`)).slice(0,24).map(e=>`${e.textContent??``} ${e.getAttribute(`aria-label`)??``}`).join(` `).toLowerCase()}`;return u.reduce((e,n)=>e+Number(t.includes(n)),0)}function pt(e,t){if(e instanceof HTMLImageElement||e instanceof HTMLCanvasElement)return 1;if(e instanceof HTMLIFrameElement)return .75;let n=0,r=e.querySelectorAll(`img, picture, canvas, svg`);for(let e of r){let r=e.getBoundingClientRect(),i=r.width*r.height/Math.max(1,t.width*t.height);if(n=Math.max(n,i),n>=.95)break}return v(n,0,1)}function mt(e){return!(e.display===`none`||e.display===`contents`||e.visibility===`hidden`||e.display.startsWith(`inline`)&&e.display!==`inline-block`||Number.parseFloat(e.opacity||`1`)<.1)}function ht(e,t){if(J(t))return!1;let n=e.parentElement;return!n||getComputedStyle(n).backgroundColor!==t}function gt(e,t,n){let r=[Y(n.borderTopWidth),Y(n.borderRightWidth),Y(n.borderBottomWidth),Y(n.borderLeftWidth)],i=n.borderRadius.match(/[\d.]+/g)?.map(Number)??[0],a=[Y(n.paddingTop),Y(n.paddingRight),Y(n.paddingBottom),Y(n.paddingLeft)],o=document.activeElement,s=e.getAttribute(`role`),c=pt(e,t);return{width:t.width,height:t.height,area:t.width*t.height,aspect:t.width/Math.max(1,t.height),viewportIntersectionRatio:lt(t),viewportAreaRatio:t.width*t.height/Math.max(1,window.innerWidth*window.innerHeight),viewportWidthRatio:t.width/Math.max(1,window.innerWidth),viewportHeightRatio:t.height/Math.max(1,window.innerHeight),borderWidth:Math.max(...r),borderRadiusPx:Math.max(...i),paddingPx:at(a),hasDistinctBackground:ht(e,n.backgroundColor),hasShadow:n.boxShadow!==`none`,childElementCount:dt(e,160),directChildCount:e.children.length,textLength:Math.min(4e3,(e.innerText||e.textContent||``).trim().length),interactiveCount:ut(e,f,12),formControlCount:ut(e,p,4),dangerKeywordHits:ft(e),fixedOrSticky:n.position===`fixed`||n.position===`sticky`,containsActiveElement:o instanceof HTMLElement&&o!==document.body&&e.contains(o),isSemanticLandmark:nt.has(e.tagName)||s===`main`||s===`region`||s===`article`,isImageLike:c>=.42,imageCoverageRatio:c,depth:ot(e)}}function _t(e,t){if(e.matches(tt))return!0;let n=e.querySelectorAll(tt);for(let e of n){if(!(e instanceof HTMLElement))continue;let n=e.getBoundingClientRect();if(!(n.width<=2||n.height<=2)&&n.width*n.height/Math.max(1,t.width*t.height)>=i.protectedDescendantCoverageRatio)return!0}return!1}function vt(){let e=document.querySelectorAll(rt);for(let t of e){if(!(t instanceof HTMLElement))continue;let e=t.getBoundingClientRect(),n=getComputedStyle(t);if(e.width>1&&e.height>1&&n.visibility!==`hidden`&&n.display!==`none`)return!0}return!!document.fullscreenElement}var yt=class{analyze(e){let t=[],n=[],r=window.innerWidth*window.innerHeight,{elements:a,visitedElements:o}=this.#e(),s=0;for(let o of a){if(o.id===`defeatads-extension-root`||o.closest(`#defeatads-extension-root`)||o===document.body||o===document.documentElement)continue;let a=o.getBoundingClientRect();if(a.width<i.minimumWidth||a.height<i.minimumHeight)continue;let c=a.width*a.height;if(c<i.minimumArea||c>r*i.maximumViewportAreaRatio||a.bottom<0||a.top>window.innerHeight||a.right<0||a.left>window.innerWidth)continue;let l=getComputedStyle(o);if(!mt(l))continue;if(s+=1,s>i.maxScoredCandidates)break;let u=gt(o,a,l),d=_t(o,a)?{total:0,rejected:!0,rejectionCode:`safety.protected-content`,reasons:[{code:`safety.protected-content`,delta:-100,detail:`Contains modal, editor, form, player, or protected UI`}]}:We(u),f=Me(a.width,a.height).filter(t=>e.enabledFormats[t]);f.length===0&&!d.rejected&&(d.total=Math.max(0,d.total-30),d.reasons.push({code:`format.none-compatible`,delta:-30,detail:`No enabled format fits this geometry`}));let p={element:o,rect:a,metrics:u,score:d,visualStyle:ct(o),compatibleFormats:f};t.push(p),!d.rejected&&d.total>=e.minimumCandidateScore&&f.length>0&&n.push(p)}return n.sort((e,t)=>t.score.total-e.score.total),t.sort((e,t)=>t.score.total-e.score.total),{accepted:n.slice(0,i.maxAcceptedCandidates),inspected:t,visitedElements:o,blockingModalPresent:vt()}}#e(){let e=[],t=new Set,n=n=>{!(n instanceof HTMLElement)||t.has(n)||(t.add(n),e.push(n))};for(let e of document.querySelectorAll(it))n(e);let r=document.createTreeWalker(document.body,NodeFilter.SHOW_ELEMENT),a=0;for(;r.nextNode()&&a<i.maxVisitedElements;)a+=1,n(r.currentNode);return{elements:e,visitedElements:a}}};function bt(e,t){return Math.max(0,Math.min(e.right,t.right)-Math.max(e.left,t.left))*Math.max(0,Math.min(e.bottom,t.bottom)-Math.max(e.top,t.top))}function X(e,t){return bt(e,t)/Math.max(1,Math.min(e.width*e.height,t.width*t.height))}function Z(e,t,n,r){return new DOMRect(e,t,n,r)}function xt(e){let t=window.innerWidth,n=window.innerHeight,r=Math.max(12,Math.min(24,t*.02));switch(e){case`document-side`:{let e=Math.min(310,t*.28),i=Math.min(460,n*.68),a=Math.max(r,(n-i)/2);return[Z(r,a,e,i),Z(t-e-r,a,e,i)]}case`document-bottom`:{let e=Math.min(760,t-r*2),i=Math.min(150,n*.2);return[Z((t-e)/2,n-i-r,e,i)]}case`document-corner`:{let e=Math.min(340,t*.34),i=Math.min(250,n*.34);return[Z(r,r,e,i),Z(t-e-r,r,e,i),Z(r,n-i-r,e,i),Z(t-e-r,n-i-r,e,i)]}case`document-center`:{let e=Math.min(560,t-r*4),i=Math.min(380,n-r*4);return[Z((t-e)/2,(n-i)/2,e,i)]}}}function St(e,t){return typeof document.elementsFromPoint==`function`&&document.elementsFromPoint(e,t).some(e=>{if(!(e instanceof HTMLElement)||e.id===`defeatads-extension-root`||e.closest(`#defeatads-extension-root`))return!1;let t=getComputedStyle(e);if(t.position!==`fixed`&&t.position!==`sticky`)return!1;let n=e.getAttribute(`role`);return n===`dialog`||n===`menu`||n===`alert`||Number.parseInt(t.zIndex,10)>100})}function Ct(e){return[[e.left+4,e.top+4],[e.right-4,e.top+4],[e.left+4,e.bottom-4],[e.right-4,e.bottom-4],[e.left+e.width/2,e.top+e.height/2]].filter(([e,t])=>St(e,t)).length>=2}var wt=class{isFallbackRectSafe(e){return e.right<=0||e.bottom<=0||e.left>=window.innerWidth||e.top>=window.innerHeight||!Ct(e)}chooseAnchored(e,t,n,r,i){let a=ge(e.filter(e=>!e.element.isConnected||r.some(t=>t.contains(e.element)||e.element.contains(t))?!1:n.every(t=>X(e.rect,t)<.12)).slice(0,10).map(e=>({value:e,weight:e.score.total**3})));if(!a)return null;let o=a.compatibleFormats.filter(e=>t.enabledFormats[e]&&!i.has(e)),s=a.compatibleFormats.filter(e=>t.enabledFormats[e]),c=k(o.length>0?o:s);return c?{kind:`anchor`,candidate:a,formatId:c,rect:z(a.element.getBoundingClientRect()),style:a.visualStyle}:null}chooseDocumentFallback(e,t,n){let r=Ne().filter(t=>e.enabledFormats[t.id]),i=r.filter(e=>!n.has(e.id)),a=ge((i.length>0?i:r).map(e=>({value:e,weight:e.fallbackWeight})));if(!a||a.placement!==`document-fallback`)return null;let o=a.id,s=k(xt(o).filter(e=>!L(a.requirements,e.width,e.height)||Ct(e)?!1:t.every(t=>X(e,t)<.1)));return s?{kind:`document-fallback`,candidate:null,formatId:o,rect:s,style:ct(document.body)}:null}},Q=m.join(`,`),Tt=new Set([`open`,`hidden`,`aria-modal`,`aria-hidden`,`role`]),Et=new Set([`SCRIPT`,`STYLE`,`LINK`,`META`,`PATH`]),Dt=/(?:modal|dialog|captcha|checkout|payment|password|editor|menu)/i;function Ot(e){return e instanceof Element?e.id===`defeatads-extension-root`||!!e.closest(`#defeatads-extension-root`):!1}function kt(e,t){return e instanceof Element&&t.some(t=>e===t||e.contains(t))}function At(e){return!(e instanceof HTMLElement)||Ot(e)||Et.has(e.tagName)?!1:e.matches(Q)||e.querySelector(Q)||/^(MAIN|ARTICLE|SECTION|ASIDE|UL|OL|TABLE|FIGURE)$/.test(e.tagName)?!0:e.childElementCount>=2||(e.textContent?.trim().length??0)>=20}function jt(e,t){if(Ot(e.target))return!1;if(e.type===`childList`)return[...e.removedNodes].some(e=>kt(e,t))?!0:[...e.addedNodes].some(At);if(e.type!==`attributes`||!(e.target instanceof HTMLElement))return!1;let n=e.attributeName??``;if(Tt.has(n))return!0;if(n!==`class`&&n!==`style`||t.some(t=>e.target===t||e.target.contains(t)))return!1;let r=`${e.target.id} ${e.target.className} ${e.target.getAttribute(`role`)??``}`;return Dt.test(r)||e.target.matches(Q)}var Mt=class{#e=new yt;#t=new wt;#n=new we;#r=new Le;#i=new Map;#a=null;#o=null;#s=null;#c=null;#l=null;#u=null;#d=null;#f=null;#p=location.href;#m=0;#h=!1;#g=!1;#_=!1;#v=0;async start(){this.#h||window.top!==window||(this.#h=!0,this.#a=await O(),this.#o=new Ue,this.#w(),this.#E(this.#a.firstShowDelayMs))}async reconcile(){if(this.#a=await O(),this.#s=null,this.#I(!1),!this.#L()){this.#o?.clearDebug();return}this.#T(0)}async forceScan(){this.#a||=await O(),await this.#D(!0)}async forceSpawn(){this.#a||=await O(),this.#s||await this.#D(!0),await this.#k(!0)}stop(){this.#h=!1,this.#R(),this.#c?.disconnect(),this.#c=null,window.removeEventListener(`scroll`,this.#b,!0),window.removeEventListener(`resize`,this.#x),document.removeEventListener(`visibilitychange`,this.#S),this.#I(!1),this.#r.clear(),this.#o?.destroy(),this.#o=null}status(){let e=[...this.#i.values()].map(({handle:e})=>({id:e.id,formatId:e.formatId,placementKind:e.placementKind}));return{running:this.#h,enabledForSite:this.#L(),activeAds:e,impressions:this.#m,lastScanCandidateCount:this.#s?.accepted.length??0}}#y=()=>{this.#f===null&&(this.#f=requestAnimationFrame(()=>{this.#f=null,this.#N()}))};#b=e=>{this.#o?.hideZoom(),ze(e.target)||this.#N()};#x=()=>{this.#y(),this.#T(i.mutationDebounceMs)};#S=()=>{let e=this.#C();for(let t of e)document.hidden?t.pause():t.play().catch(()=>void 0)};#C(){let e=document.getElementById(n);return e?.shadowRoot?Array.from(e.shadowRoot.querySelectorAll(`video`)):[]}#w(){this.#c=new MutationObserver(e=>{this.#y();let t=[...this.#i.values()].map(({placement:e})=>e.kind===`anchor`?e.candidate.element:null).filter(e=>e!==null);e.some(e=>jt(e,t))&&this.#T(i.mutationDebounceMs)}),this.#c.observe(document.documentElement,{childList:!0,attributes:!0,attributeFilter:[`class`,`style`,`open`,`hidden`,`aria-modal`,`aria-hidden`,`role`],subtree:!0}),window.addEventListener(`scroll`,this.#b,{passive:!0,capture:!0}),window.addEventListener(`resize`,this.#x,{passive:!0}),document.addEventListener(`visibilitychange`,this.#S),this.#l=window.setInterval(()=>{location.href!==this.#p&&(this.#p=location.href,this.#s=null,this.#N(),this.#T(0))},i.routePollMs)}#T(e){this.#u!==null&&window.clearTimeout(this.#u);let t=performance.now()-this.#v,n=Math.max(0,i.minimumScanIntervalMs-t);this.#u=window.setTimeout(()=>{this.#u=null,this.#D(!1)},Math.max(e,n))}#E(e){this.#d!==null&&window.clearTimeout(this.#d),this.#d=window.setTimeout(()=>{this.#d=null,this.#D(!1)},e)}async#D(e){if(this.#g){this.#_=!0;return}if(!(!this.#a||!this.#o||!this.#L())){this.#g=!0,this.#v=performance.now();try{if(this.#s=this.#e.analyze(this.#a),this.#a.debug.enabled?this.#o.showDebug(this.#s,this.#a.debug.showRejected):this.#o.clearDebug(),this.#a.debug.logToConsole&&console.table(this.#s.inspected.slice(0,40).map(e=>({element:e.element,score:e.score.total,rejected:e.score.rejectionCode??``,size:`${Math.round(e.rect.width)}×${Math.round(e.rect.height)}`,formats:e.compatibleFormats.join(`, `),reasons:e.score.reasons.map(e=>`${e.code}:${e.delta.toFixed(1)}`).join(` | `)}))),this.#s.blockingModalPresent){this.#I(!0);return}this.#M(),await this.#O(e)}finally{this.#g=!1,this.#_&&(this.#_=!1,this.#T(0))}}}async#O(e){if(!this.#a)return;let t=Math.min(this.#a.desiredActiveAds,this.#a.maxActiveAds);for(;this.#i.size<t&&await this.#k(e););}async#k(e){let n=this.#a,r=this.#s,i=this.#o;if(!n||!r||!i||!this.#L()||this.#i.size>=n.maxActiveAds||n.pageImpressionLimit!==null&&this.#m>=n.pageImpressionLimit||!e&&Math.random()>n.appearanceProbability)return!1;let a=[...this.#i.values()].map(({handle:e})=>e.element.getBoundingClientRect()),o=[...this.#i.values()].map(({placement:e})=>e.kind===`anchor`?e.candidate.element:null).filter(e=>e!==null),s=new Set([...this.#i.values()].map(({handle:e})=>e.formatId)),c=null;n.allowAnchoredTakeovers&&(c=this.#t.chooseAnchored(r.accepted,n,a,o,s));let l=[...this.#i.values()].filter(({handle:e})=>e.placementKind===`document-fallback`).length;if(!c&&n.allowDocumentFallback&&l<n.maxFallbackAds&&(c=this.#t.chooseDocumentFallback(n,a,s)),!c)return!1;let u=R.get(c.formatId);if(!u)return!1;let d=Oe(n,u.mediaSlots,this.#n),f=[];for(let e of d.mediaItems){let t=await this.#r.acquire(e);if(t&&f.push(t),f.length>=u.mediaSlots)break}if(f.length===0)return!1;if(!this.#h||this.#o!==i||this.#s!==r||this.#a!==n||!this.#L()||c.kind===`anchor`&&!c.candidate.element.isConnected){for(let e of f)e.release();return!1}if(c.kind===`anchor`){let e=c.candidate.element.getBoundingClientRect();if(!L(u.requirements,e.width,e.height)){for(let e of f)e.release();return!1}c.rect=z(e)}let p=he(`ad`),m=i.renderAd({id:p,formatId:c.formatId,placementKind:c.kind,rect:c.rect,style:c.style,content:d,mediaPayloads:f,config:n,onClosed:e=>this.#j(e),onMediaBroken:(e,t)=>this.#A(e,t)}),h=c.kind===`anchor`?new ResizeObserver(this.#y):null;return c.kind===`anchor`&&h?.observe(c.candidate.element),this.#i.set(p,{handle:m,placement:c,resizeObserver:h,invalidSince:null}),this.#m+=1,t.runtime.sendMessage({type:`progress.record`,event:{category:d.category,formatId:c.formatId,site:location.hostname,time:Date.now()}}).catch(()=>void 0),!0}#A(e,t){this.#r.markBroken(t),this.#F(e,!1,!1),this.#h&&this.#a&&this.#L()&&this.#E(0)}#j(e){this.#i.get(e)?.resizeObserver?.disconnect(),this.#i.delete(e),this.#h&&this.#a&&this.#L()&&this.#E(this.#a.replacementDelayMs)}#M(){let e=this.#s,t=this.#a;if(!e||!t)return;let n=new Map(e.inspected.map(e=>[e.element,e]));for(let[e,r]of this.#i){if(!t.enabledFormats[r.handle.formatId]){this.#F(e,!1);continue}if(r.placement.kind===`document-fallback`){(!t.allowDocumentFallback||!this.#t.isFallbackRectSafe(r.handle.element.getBoundingClientRect()))&&this.#F(e,!1);continue}let i=r.placement.candidate.element;if(!i.isConnected){this.#F(e,!1);continue}if(n.get(i)?.score.rejectionCode?.startsWith(`safety.`)??!1){this.#F(e,!1);continue}let a=i.getBoundingClientRect(),o=R.get(r.handle.formatId);if(!(o&&L(o.requirements,a.width,a.height))){this.#P(e,r);continue}r.invalidSince=null,r.handle.updateRect(z(a))}}#N(){for(let[e,t]of this.#i){if(t.placement.kind!==`anchor`)continue;let n=t.placement.candidate.element;if(!n.isConnected){this.#F(e,!1);continue}let r=n.getBoundingClientRect(),i=R.get(t.handle.formatId);if(!(i&&L(i.requirements,r.width,r.height))){this.#P(e,t);continue}t.invalidSince=null,t.handle.updateRect(z(r))}}#P(e,t){let n=performance.now();if(t.invalidSince===null){t.invalidSince=n,this.#T(a.anchorInvalidGraceMs);return}n-t.invalidSince>=a.anchorInvalidGraceMs&&this.#F(e,!1)}#F(e,t,n=!0){let r=this.#i.get(e);r&&(r.resizeObserver?.disconnect(),this.#i.delete(e),t?r.handle.close():r.handle.destroy(),n&&this.#h&&this.#a&&this.#L()&&this.#E(this.#a.replacementDelayMs))}#I(e){for(let[t]of this.#i)this.#F(t,e,!1)}#L(){let e=this.#a;return!!(e?.enabled&&!me(e,location.hostname))}#R(){this.#l!==null&&window.clearInterval(this.#l),this.#u!==null&&window.clearTimeout(this.#u),this.#d!==null&&window.clearTimeout(this.#d),this.#f!==null&&cancelAnimationFrame(this.#f),this.#l=null,this.#u=null,this.#d=null,this.#f=null}},Nt=e({matches:[`http://*/*`,`https://*/*`],runAt:`document_idle`,allFrames:!1,main(){let e=new Mt;e.start(),t.runtime.onMessage.addListener(t=>(async()=>{try{switch(t.type){case`status.get`:return{ok:!0,status:e.status()};case`engine.reconcile`:return await e.reconcile(),{ok:!0,status:e.status()};case`engine.forceScan`:return await e.forceScan(),{ok:!0,status:e.status()};case`engine.forceSpawn`:return await e.forceSpawn(),{ok:!0,status:e.status()};case`engine.stop`:return e.stop(),{ok:!0,status:e.status()}}}catch(e){return{ok:!1,error:e instanceof Error?e.message:String(e)}}})())}}),Pt={debug:(...e)=>([...e],void 0),log:(...e)=>([...e],void 0),warn:(...e)=>([...e],void 0),error:(...e)=>([...e],void 0)},Ft=class e extends Event{static EVENT_NAME=$(`wxt:locationchange`);constructor(t,n){super(e.EVENT_NAME,{}),this.newUrl=t,this.oldUrl=n}};function $(e){return`${t?.runtime?.id}:content:${e}`}var It=typeof globalThis.navigation?.addEventListener==`function`;function Lt(e){let t,n=!1;return{run(){n||(n=!0,t=new URL(location.href),It?globalThis.navigation.addEventListener(`navigate`,e=>{let n=new URL(e.destination.url);n.href!==t.href&&(window.dispatchEvent(new Ft(n,t)),t=n)},{signal:e.signal}):e.setInterval(()=>{let e=new URL(location.href);e.href!==t.href&&(window.dispatchEvent(new Ft(e,t)),t=e)},1e3))}}}var Rt=class e{static SCRIPT_STARTED_MESSAGE_TYPE=$(`wxt:content-script-started`);id;abortController;locationWatcher=Lt(this);constructor(e,t){this.contentScriptName=e,this.options=t,this.id=Math.random().toString(36).slice(2),this.abortController=new AbortController,this.stopOldScripts(),this.listenForNewerScripts()}get signal(){return this.abortController.signal}abort(e){return this.abortController.abort(e)}get isInvalid(){return t.runtime?.id??this.notifyInvalidated(),this.signal.aborted}get isValid(){return!this.isInvalid}onInvalidated(e){return this.signal.addEventListener(`abort`,e),()=>this.signal.removeEventListener(`abort`,e)}block(){return new Promise(()=>{})}setInterval(e,t){let n=setInterval(()=>{this.isValid&&e()},t);return this.onInvalidated(()=>clearInterval(n)),n}setTimeout(e,t){let n=setTimeout(()=>{this.isValid&&e()},t);return this.onInvalidated(()=>clearTimeout(n)),n}requestAnimationFrame(e){let t=requestAnimationFrame((...t)=>{this.isValid&&e(...t)});return this.onInvalidated(()=>cancelAnimationFrame(t)),t}requestIdleCallback(e,t){let n=requestIdleCallback((...t)=>{this.signal.aborted||e(...t)},t);return this.onInvalidated(()=>cancelIdleCallback(n)),n}addEventListener(e,t,n,r){t===`wxt:locationchange`&&this.isValid&&this.locationWatcher.run(),e.addEventListener?.(t.startsWith(`wxt:`)?$(t):t,n,{...r,signal:this.signal})}notifyInvalidated(){this.abort(`Content script context invalidated`),Pt.debug(`Content script "${this.contentScriptName}" context invalidated`)}stopOldScripts(){document.dispatchEvent(new CustomEvent(e.SCRIPT_STARTED_MESSAGE_TYPE,{detail:{contentScriptName:this.contentScriptName,messageId:this.id}})),this.options?.noScriptStartedPostMessage||window.postMessage({type:e.SCRIPT_STARTED_MESSAGE_TYPE,contentScriptName:this.contentScriptName,messageId:this.id},`*`)}verifyScriptStartedEvent(e){let t=e.detail?.contentScriptName===this.contentScriptName,n=e.detail?.messageId===this.id;return t&&!n}listenForNewerScripts(){let t=e=>{!(e instanceof CustomEvent)||!this.verifyScriptStartedEvent(e)||this.notifyInvalidated()};document.addEventListener(e.SCRIPT_STARTED_MESSAGE_TYPE,t),this.onInvalidated(()=>document.removeEventListener(e.SCRIPT_STARTED_MESSAGE_TYPE,t))}},zt={debug:(...e)=>([...e],void 0),log:(...e)=>([...e],void 0),warn:(...e)=>([...e],void 0),error:(...e)=>([...e],void 0)};return(async()=>{try{let{main:e,...t}=Nt;return await e(new Rt(`content`,t))}catch(e){throw zt.error(`The content script "content" crashed on startup!`,e),e}})()})();
content;