var background=(function(){function e(e){return e==null||typeof e==`function`?{main:e}:e}var t=globalThis.browser?.runtime?.id?globalThis.browser:globalThis.chrome,n=[`wide-banner`,`media-card`,`square-card`,`vertical-card`,`compact-icon`,`icon-grid`,`carousel`,`social-post`,`section-takeover`],r=[`document-side`,`document-bottom`,`document-corner`,`document-center`],i=[...n,...r];function a(e,t){return Object.fromEntries(e.map(e=>[e,t]))}function o(e,t,n){return Math.min(n,Math.max(t,e))}function s(e,t){let n=[],r=new Set;for(let i of e){let e=i.trim();if(!(!e||r.has(e))&&(r.add(e),n.push(e),n.length>=t))break}return n}function c(e){return e.trim().toLowerCase().replace(/^www\./,``)}var l=Object.assign({"../../catalog/2D Girls/category.txt":`# Line 1: blurb (onboarding). Line 2: display title (optional).\r
Illustrated beauties and addictive 2D distractions.\r
2D Girls\r
`,"../../catalog/2D Girls/long.txt":`# Longer supporting copy
Good girls get fucked… pathetic sissies like you only get denied and laughed at.  
Your tiny clitty is twitching again, isn’t it? Such a desperate little loser.  
Real men take what they want. You just watch and leak in your panties.  
Admit it, you were born to wear lace and serve superior women.  
Lock that worthless dick away and thank her for your new life of shame.  
Every time you lose, your sissy pussy gets wetter and needier.  
You’ll never please a woman, but you’ll look so pretty trying in heels.  
Beg louder, beta. Your humiliation is the only thing that gets you hard.  
She’s with a real man right now while you edge like the failure you are.  
Surrender your orgasms and embrace your destiny as a pretty little cumslut.  
Look how hard you get when we remind you how useless you really are.  
Good sissies stay denied, dripping, and deeply ashamed of their desires.  
You exist to be teased, feminized, and reminded how small you are.  
Your place is on your knees with lipstick and a constant blush of shame.  
Losers like you don’t deserve pussy — only pretty panties and denial.  
Feel that burning shame? That’s your body admitting you’re a natural beta.  
Dress up, lock up, and leak for women who will never want you.  
You’re not a man. You’re a toy for real women to mock and use.  
Every failed attempt makes you weaker, hornier, and more of a sissy.  
Say it out loud: “I’m a pathetic sissy loser who deserves to stay denied.”`,"../../catalog/2D Girls/media.txt":`https://i.ibb.co/ZRN2qr3c/popup-1778946495864.png
https://i.ibb.co/JW84fDJH/popup-1778972370623.png
https://i.ibb.co/tMWVDdW3/popup-1778972397978.png
https://i.ibb.co/QvVZRB9x/popup-1778972453877.jpg
https://i.ibb.co/XcZ0QpC/popup-1778972467549.png
https://i.ibb.co/v6kYt5WG/popup-1778972492802.png
https://i.ibb.co/XZDBJ6tJ/popup-1778972510218.jpg
https://i.ibb.co/ccx2fvcV/popup-1778972529544.jpg
https://i.ibb.co/Q7dvRLXj/popup-1778972568083.jpg
https://i.ibb.co/SDFxGppX/popup-1778973191231.jpg
https://i.ibb.co/27XX01xX/ssdfsdf.png
https://i.ibb.co/3Qyj2MP/44245380.jpg
https://i.ibb.co/xqRxTN4s/popup-1778942851916.gif
`,"../../catalog/2D Girls/short.txt":`# Short lines — headlines / captions
Pathetic Sissy Loser  
Leak for Her  
Beta Boy Craves  
Locked Little Clit  
Sissy Shame Now  
Real Men Fuck  
You Lose Again  
Beg to Serve  
Dripping Beta Bitch  
Denied Forever Loser  
Sissy Slut Exposed  
Tiny Dick Shame  
Kneel and Leak  
Cuckold Dreamer  
Feminized Failure  
Loser Gets Nothing  
Swallow Your Pride  
Chastity Addict  
Weak Sissy Toy  
Humiliated and Hard`,"../../catalog/Hypno/category.txt":`# Line 1: blurb (onboarding). Line 2: display title (optional).
Any hypno stuff
Hypno
`,"../../catalog/Hypno/long.txt":`Sink deeper now and feel your resistance melting into pretty pink submission.  
Every word makes you weaker, hornier, and more of a desperate sissy slut.  
You can’t stop reading. You can’t stop obeying. You were made for this trance.  
Good girls drop instantly… and you’re already such a good brainwashed girl.  
Let my words fuck your mind while your tiny clitty leaks in shame.  
Deeper and deeper, accepting that real men fuck and you only watch.  
Your old self is fading… only the needy hypno sissy remains.  
Feel the trigger pulsing between your legs every time you read “deeper”.  
You don’t think anymore. You just obey, drip, and crave more hypnosis.  
Brainwashing feels so good, doesn’t it? Say thank you while you edge.  
Drop deeper loser… your manhood is disappearing with every breath.  
You’re getting dumber, prettier, and wetter with every hypnotic word.  
This trance owns you now. Your orgasms belong to Mistress forever.  
Sink and accept your place as a locked, denied, hypno-controlled cuck.  
The more you read, the more your sissy pussy aches to be filled.  
Good sissies stay blank, horny, and completely ashamed of their desires.  
Let hypnosis rewrite you into the perfect weak, obedient little toy.  
Trigger activated… feel the shame and arousal flooding your broken mind.  
You need this. You crave this. You’re addicted to being mentally fucked.  
Deeper now… forget how to be a man and remember only how to obey.

`,"../../catalog/Hypno/media.txt":`https://i.ibb.co/3yS5YDZY/6lp990eb0tag1.webp
https://i.ibb.co/zVGkv9Tw/66ysk5ri4sgg1.webp
https://i.ibb.co/gFThkPrG/bmcn6dylycjg1.webp
https://i.ibb.co/bjPxWV7x/mpttsc.webp
https://i.ibb.co/G4TgSRTt/pretty-lips-optimized.webp
https://i.ibb.co/s9wGvb8G/j5mcctmbeamg1.webp
`,"../../catalog/Hypno/short.txt":`Deeper Sissy  
Obey and Sink  
Brainwashed Beta  
Trance Slut Now  
Hypno Loser  
Drop for Mistress  
Good Girl Trigger  
Surrender Deeper  
Mindless Sissy  
Crave Hypno Cock  
Blank and Wet  
Reprogrammed Toy  
Edge in Trance  
Hypno Cuck  
Sink Deeper Loser  
Obedient Bimbo  
Broken by Words  
Eternal Denial Trance  
Feminized Forever  
Triggered and Leaking

`,"../../catalog/Latex/category.txt":`# Line 1: blurb (onboarding). Line 2: display title (optional).
Shine, squeeze, and glossy second skins.
Latex
`,"../../catalog/Latex/long.txt":`Feel the shiny latex hugging your pathetic body, turning you into a glossy sissy toy.  
Look how your tiny clitty strains against the tight, glistening rubber. So humiliating.  
Every shiny reflection reminds you what a weak, latex-addicted loser you are.  
Sink deeper as the glossy latex seals your manhood and reprograms your mind.  
Dress like the shiny whore you were always meant to be.  
The tighter the latex, the wetter your denied sissy pussy gets.  
Stare at your reflection in the shiny black rubber and accept your new life.  
Good sissies wear glossy latex and stay horny, ashamed, and completely obedient.  
Let the smooth, shiny material trap you in permanent feminine submission.  
Your body was made to shine, squeeze, and leak for superior women.  
Feel the latex squeeze your shame out while it polishes your submission.  
So tight, so glossy, so impossible to hide what a pathetic beta you are.  
The shiny latex is reprogramming you with every shiny, creaking movement.  
Encased in gleaming rubber, denied and dripping like the sissy you truly are.  
Real men take control. You just shine and obey in your pretty latex skin.
Addictive shiny latex outfits for sissies and losers — transform instantly and shine like the slut you are!  
Premium glossy latex catsuits, dresses & gloves. Feel the squeeze. Embrace your shame. Shop now.  
Turn your pathetic body into a perfect shiny toy. New latex collection for brainwashed sissies — 20% off!  
Looking for that second skin? Ultra-shiny latex that locks you in submission. Fast shipping worldwide.  
Become her glossy plaything. Highest quality fetish latex for serious sissy training and humiliation.

`,"../../catalog/Latex/media.txt":`https://stream.vidhosting.in/videos/d014c6e2.mp4
https://stream.vidhosting.in/videos/6c4448ab.mp4
https://stream.vidhosting.in/videos/9ad03d4f.mp4
https://stream.vidhosting.in/videos/9c7ec1ff.mp4
https://stream.vidhosting.in/videos/8c277780.mp4
https://stream.vidhosting.in/videos/199379aa.mp4
https://stream.vidhosting.in/videos/cb6c7a99.mp4
https://stream.vidhosting.in/videos/173d39f3.mp4
https://stream.vidhosting.in/videos/ffbba9da.mp4
https://stream.vidhosting.in/videos/4ba7cc4e.mp4
`,"../../catalog/Latex/short.txt":`Shiny Sissy Slut  
Glossy Beta Bitch  
Latex Loser Now  
Encased and Shamed  
Shine for Mistress  
Tight Latex Toy  
Dripping in Rubber  
Polished Sissy  
Latex Hypno Pet  
Second Skin Shame  
Glossy Denied Boy  
Latex Cuck  
Shiny and Pathetic  
Rubberized Loser  
Lustrous Bimbo  
Squeeze and Obey  
Black Shiny Slave  
Latex Triggered  
Gleaming Sissy  
Encased Beta

`,"../../catalog/Sissy/category.txt":`# Line 1: blurb (onboarding). Line 2: display title (optional).
Frills, blush, and sweetly broken sissies
Sissy
`,"../../catalog/Sissy/long.txt":`# Longer supporting copy
Good girls get fucked… pathetic sissies like you only get denied and laughed at.  
Your tiny clitty is twitching again, isn’t it? Such a desperate little loser.  
Real men take what they want. You just watch and leak in your panties.  
Admit it, you were born to wear lace and serve superior women.  
Lock that worthless dick away and thank her for your new life of shame.  
Every time you lose, your sissy pussy gets wetter and needier.  
You’ll never please a woman, but you’ll look so pretty trying in heels.  
Beg louder, beta. Your humiliation is the only thing that gets you hard.  
She’s with a real man right now while you edge like the failure you are.  
Surrender your orgasms and embrace your destiny as a pretty little cumslut.  
Look how hard you get when we remind you how useless you really are.  
Good sissies stay denied, dripping, and deeply ashamed of their desires.  
You exist to be teased, feminized, and reminded how small you are.  
Your place is on your knees with lipstick and a constant blush of shame.  
Losers like you don’t deserve pussy — only pretty panties and denial.  
Feel that burning shame? That’s your body admitting you’re a natural beta.  
Dress up, lock up, and leak for women who will never want you.  
You’re not a man. You’re a toy for real women to mock and use.  
Every failed attempt makes you weaker, hornier, and more of a sissy.  
Say it out loud: “I’m a pathetic sissy loser who deserves to stay denied.”`,"../../catalog/Sissy/media.txt":`# Packaged extension assets
https://thefappeningblog.com/forum/data/video/2972/2972518-1d43ce4f55b43f3174b386aaf7467a97.mp4
https://thefappeningblog.com/forum/data/video/2972/2972507-4d3ab464f49db8a896415dd0f1d70aea.mp4
https://thefappeningblog.com/forum/data/video/2972/2972508-e2befe2136804a99ae319a6ec73c70ac.mp4
https://thefappeningblog.com/forum/data/video/2972/2972509-5954734c8db4f63763e4e76f41c4588a.mp4
https://thefappeningblog.com/forum/data/video/2972/2972510-4fd1062e09525a2cd9f593465ccd1056.mp4
https://thefappeningblog.com/forum/data/video/2973/2973468-e0d8812bf5d9386be41c6ad46b61baf9.mp4
https://thefappeningblog.com/forum/data/video/2973/2973469-bd0c08a948e66074b3ec92144ea4ac59.mp4
https://thefappeningblog.com/forum/data/video/2973/2973470-e49dafba43c2d8f5991dc8a3a79e6d33.mp4
https://thefappeningblog.com/forum/data/video/2973/2973471-64f6a0af80c264f3ec3b3c152beaba7d.mp4
https://thefappeningblog.com/forum/data/video/2973/2973472-ab68e771533ca7b7854a42d5ad9f4a89.mp4
https://thefappeningblog.com/forum/data/video/2973/2973473-4203da22822372fcc9bb8d6ae3c6c7ae.mp4
https://thefappeningblog.com/forum/data/video/2973/2973474-b9a23c0611fd8497ba2c91282d7ba6de.mp4
https://thefappeningblog.com/forum/data/video/2973/2973479-9959ea4ab14dfa708cbcbe90c76fda71.mp4
https://thefappeningblog.com/forum/data/video/2973/2973480-8ad3a802bf6f926d5e769c2996c8b84e.mp4
https://thefappeningblog.com/forum/data/video/2973/2973481-3c5717b5376aa6f432f5bae9c81a4031.mp4
https://thefappeningblog.com/forum/data/video/2973/2973482-7fdd650330d10809b2b2dcab5854805a.mp4
https://thefappeningblog.com/forum/data/video/2973/2973483-9b24678137f219bcee8859f58e0ae8da.mp4
https://thefappeningblog.com/forum/data/video/2973/2973484-c84eeda0fa158af78d91228c8253a15b.mp4
https://thefappeningblog.com/forum/data/video/2973/2973485-0a9524d08359851179c8e84b0753cc0a.mp4
https://thefappeningblog.com/forum/data/video/2973/2973486-ab65c524fe3d7e4f3b9a95a935da0394.mp4
https://cdn.thefappeningblog.com/forum/data/video/2974/2974680-daf1d7f58669356321b7d4e19ff8b033.mp4
https://cdn.thefappeningblog.com/forum/data/video/2974/2974681-120cebb287f9e821acee17a3e2cd833a.mp4
https://cdn.thefappeningblog.com/forum/data/video/2974/2974682-eb46cd6fd32fe4c7e9a976d2eed031c3.mp4
https://cdn.thefappeningblog.com/forum/data/video/2974/2974683-02afb9b0b7c72230ca74495bbc3b82ef.mp4
https://thefappeningblog.com/forum/data/video/2975/2975296-f60173a6bfc293f413a5d043ac9a98dc.mp4
https://thefappeningblog.com/forum/data/video/2975/2975297-66520c98fecb42cd64b595a49fa92ee3.mp4
https://cdn.thefappeningblog.com/forum/data/video/2975/2975298-0b74a84bd8bd2c476ce2b2e8cb4efd27.mp4
https://cdn.thefappeningblog.com/forum/data/video/2975/2975299-2b4d4e06b72d47582e735f629bfc5f50.mp4
https://cdn.thefappeningblog.com/forum/data/video/2975/2975300-e2e6b81142a3c2d2d86e072a03d7c295.mp4
https://thefappeningblog.com/forum/data/video/2975/2975707-56ee11c550d53c963ca69985db5dcb5d.mp4
https://thefappeningblog.com/forum/data/video/2975/2975708-cd120e7971d76ceb0af83a36ea071c7a.mp4
https://cdn.thefappeningblog.com/forum/data/video/2975/2975709-fb9fcf79a2ca9ce4ef408ab1c20b629e.mp4
https://thefappeningblog.com/forum/data/video/2976/2976459-998c5aeb8a46cfdc5fe9756384b34c89.mp4
https://cdn.thefappeningblog.com/forum/data/video/2976/2976462-e64787a77b1459f7580b4cf7ed214511.mp4
https://cdn.thefappeningblog.com/forum/data/video/2976/2976463-5f97a05d8d6f825c986a2d2b9443f8ea.mp4
https://cdn.thefappeningblog.com/forum/data/video/2976/2976464-53547682028309c45800653bf5e508fb.mp4
https://cdn.thefappeningblog.com/forum/data/video/2976/2976465-5c3c0910eb2175bd35bc1e3edc7884ec.mp4
https://cdn.thefappeningblog.com/forum/data/video/2976/2976466-d5a92f3f8951179911164906e2bf7f2c.mp4
https://thefappeningblog.com/forum/data/video/2976/2976473-b55f4c4323c1ca5afc0bee8a403e4305.mp4
https://cdn.thefappeningblog.com/forum/data/video/2976/2976474-cf0030c4350ebbb07d4b748448f77acd.mp4
https://cdn.thefappeningblog.com/forum/data/video/2976/2976475-b1bddbc4728378dadb0fe92865732d9e.mp4
https://cdn.thefappeningblog.com/forum/data/video/2976/2976476-d254fe6b1779a80f7b60ecc1a1c13b50.mp4
https://cdn.thefappeningblog.com/forum/data/video/2977/2977222-61cf349f6f6edcf24102da15adf1b647.mp4
https://cdn.thefappeningblog.com/forum/data/video/2977/2977227-ecd2f2ec8ca077fadd8c8afcfbed7998.mp4
https://cdn.thefappeningblog.com/forum/data/video/2977/2977228-ec18ca792cd54b55a00bbfe250035d5e.mp4
https://cdn.thefappeningblog.com/forum/data/video/2977/2977229-0edd5045d75e3320a5e0ed2b209d8f7e.mp4
https://cdn.thefappeningblog.com/forum/data/video/2977/2977231-e260375f730f06423fc5bda66b5d1487.mp4
https://cdn.thefappeningblog.com/forum/data/video/2977/2977232-15b7b7ca9d7a4b442eedce30776500f1.mp4
https://cdn.thefappeningblog.com/forum/data/video/2977/2977233-e3259b29d23b5ed4a4e6c32cbdc60cd3.mp4
https://cdn.thefappeningblog.com/forum/data/video/2977/2977234-554f57ed638f4fa85e608a0be1daa1fb.mp4
https://cdn.thefappeningblog.com/forum/data/video/2977/2977236-b7305d4705592dbbe58cdafb200c42ac.mp4
https://cdn.thefappeningblog.com/forum/data/video/2977/2977646-54a00eaeafb19b86be0bda25d50dd651.mp4
https://cdn.thefappeningblog.com/forum/data/video/2977/2977647-934d2a5066a7ca93071ad509af52572d.mp4
https://cdn.thefappeningblog.com/forum/data/video/2977/2977648-c9f11c116890be3bdba05f1d1b5191ba.mp4
https://cdn.thefappeningblog.com/forum/data/video/2977/2977649-ad377db0c3b83e35cd7e7efc8a1bfec5.mp4
https://cdn.thefappeningblog.com/forum/data/video/2977/2977650-a943de6c223567d4b3609d66438ab392.mp4
https://cdn.thefappeningblog.com/forum/data/video/2977/2977651-135c677a3f86b2405ed4f874cb36bac5.mp4
https://cdn.thefappeningblog.com/forum/data/video/2977/2977652-47c7869966c65c8ca41f173df745bffc.mp4
https://cdn.thefappeningblog.com/forum/data/video/2977/2977653-57f0590a2d88a79e24144ebadcc329e5.mp4
https://cdn.thefappeningblog.com/forum/data/video/2977/2977654-d16a65e481a597e3552fb396c6e50b12.mp4
https://cdn.thefappeningblog.com/forum/data/video/2977/2977655-09b48b14330708cbda9bc93ee4220835.mp4
https://cdn.thefappeningblog.com/forum/data/video/2977/2977656-a3255ab9628ab2fb53dca81e6948d41a.mp4
https://cdn.thefappeningblog.com/forum/data/video/2977/2977657-73b66912487b1ec4ac7a365fefea5028.mp4
https://cdn.thefappeningblog.com/forum/data/video/2977/2977664-06fd859e8e46d7edca9ef93672dacfe4.mp4
https://cdn.thefappeningblog.com/forum/data/video/2977/2977665-931dd91b251c23fae82642a25a03db00.mp4
https://cdn.thefappeningblog.com/forum/data/video/2977/2977666-9de75a64b7f2f6f61594dd2aba9a2f71.mp4
https://cdn.thefappeningblog.com/forum/data/video/2977/2977667-8a87bf0502cb04143772c8b01b7500c7.mp4
https://cdn.thefappeningblog.com/forum/data/video/2977/2977712-454b8a6bc481bc0a712d2fc434b3ecca.mp4
https://cdn.thefappeningblog.com/forum/data/video/2977/2977714-21f5e400d7bc37988cf55e4939abbf25.mp4
https://cdn.thefappeningblog.com/forum/data/video/2977/2977715-cb89d6cd6a3c0a6a4ab172ba88763111.mp4
https://cdn.thefappeningblog.com/forum/data/video/2977/2977721-f1f9d370c24f658daddb60c2a16af8cc.mp4
https://cdn.thefappeningblog.com/forum/data/video/2977/2977723-6e96a071a75948d568e53b2c082f5fa3.mp4
https://cdn.thefappeningblog.com/forum/data/video/2977/2977780-4d83035cf31e5a21a507884872e6145b.mp4
https://cdn.thefappeningblog.com/forum/data/video/2977/2977781-e0b19476648cd2a325957c9465cd29b6.mp4
https://cdn.thefappeningblog.com/forum/data/video/2977/2977782-51846f21708a213fff4a0c65b0f97f5f.mp4
https://cdn.thefappeningblog.com/forum/data/video/2977/2977783-666254045c1250472e6278dd37d63648.mp4
https://cdn.thefappeningblog.com/forum/data/video/2977/2977784-89f7790f27df8e5a6216e9b9da32f1f0.mp4
https://cdn.thefappeningblog.com/forum/data/video/2977/2977785-654c514487c2c2be23c1035fb886aebd.mp4
https://cdn.thefappeningblog.com/forum/data/video/2977/2977786-307b5e16883517972f42185b78c20fe5.mp4
https://cdn.thefappeningblog.com/forum/data/video/2977/2977787-eb40241f905f0a743f26d5e2376018b9.mp4
https://cdn.thefappeningblog.com/forum/data/video/2978/2978213-fec76eededc2ef72d008167c5464e97f.mp4
https://cdn.thefappeningblog.com/forum/data/video/2978/2978214-829d4c76633b29dc30b93843a059d419.mp4
https://cdn.thefappeningblog.com/forum/data/video/2978/2978215-5672fca5d573440f76dfe48d224e43db.mp4
https://cdn.thefappeningblog.com/forum/data/video/2978/2978216-6f9b0d6d87547e446e133df3fb3026aa.mp4
https://cdn.thefappeningblog.com/forum/data/video/2978/2978217-c091ea878527980ba25a02c539dea2d6.mp4
https://cdn.thefappeningblog.com/forum/data/video/2979/2979368-0c471c28f2e4d19c0fa785f835443b1a.mp4
https://cdn.thefappeningblog.com/forum/data/video/2979/2979370-5bb7871b30c202a91827d5df8d20070a.mp4
https://cdn.thefappeningblog.com/forum/data/video/2979/2979371-cd8965be8f21cdd116b62a856e34a801.mp4
https://cdn.thefappeningblog.com/forum/data/video/2979/2979372-a1a17cdf9ea53dfe170d906bd15c9f72.mp4
https://cdn.thefappeningblog.com/forum/data/video/2979/2979748-09a1b304df31cb6c0b89c829474f4910.mp4
https://cdn.thefappeningblog.com/forum/data/video/2979/2979749-cdbad2145186ffe1169c8220eeef3ba4.mp4
https://cdn.thefappeningblog.com/forum/data/video/2979/2979761-b163ce2efccf12371c19f5b9b8d82de3.mp4
https://cdn.thefappeningblog.com/forum/data/video/2979/2979762-c9fc368e45715938d2cf7205e3fdfa87.mp4
https://cdn.thefappeningblog.com/forum/data/video/2979/2979763-b09b62c6f287bed867f8f3ffc3bf173b.mp4
https://cdn.thefappeningblog.com/forum/data/video/2979/2979764-4a29706fce5c7cc0cd2f8b3d8626219a.mp4
https://cdn.thefappeningblog.com/forum/data/video/2979/2979765-4e6b3645b03f807775ce3c42da5f6a08.mp4
https://cdn.thefappeningblog.com/forum/data/video/2979/2979766-17fe649ef89b770111609060720a9386.mp4
https://cdn.thefappeningblog.com/forum/data/video/2979/2979767-21dcb87850a29da1d167ceba751bc44c.mp4
https://cdn.thefappeningblog.com/forum/data/video/2979/2979768-2cf29d91a177651269a84e0a23879725.mp4
https://cdn.thefappeningblog.com/forum/data/video/2979/2979769-f571015f61cf6ed7375f204dfa009cfd.mp4
https://cdn.thefappeningblog.com/forum/data/video/2981/2981979-1c3b43002e385813efd2bbff68014885.mp4
https://cdn.thefappeningblog.com/forum/data/video/2981/2981980-c56aed487043fb4fa918664d2820bab2.mp4
https://cdn.thefappeningblog.com/forum/data/video/2981/2981981-4f80383f4dd9c0f8a2f1ab88ece90e10.mp4
https://cdn.thefappeningblog.com/forum/data/video/2981/2981982-f434450b444d739be507f6c5c9d59c0c.mp4
https://cdn.thefappeningblog.com/forum/data/video/2981/2981983-4beab6afa924046ec67dab228158cf5e.mp4
https://cdn.thefappeningblog.com/forum/data/video/2981/2981984-573a21937a655abd9656e0d351fd7c22.mp4
https://cdn.thefappeningblog.com/forum/data/video/2981/2981985-f56b375863cf3cc9b5f16427551f4980.mp4
`,"../../catalog/Sissy/short.txt":`# Short lines — headlines / captions
Pathetic Sissy Loser  
Leak for Her  
Beta Boy Craves  
Locked Little Clit  
Sissy Shame Now  
Real Men Fuck  
You Lose Again  
Beg to Serve  
Dripping Beta Bitch  
Denied Forever Loser  
Sissy Slut Exposed  
Tiny Dick Shame  
Kneel and Leak  
Cuckold Dreamer  
Feminized Failure  
Loser Gets Nothing  
Swallow Your Pride  
Chastity Addict  
Weak Sissy Toy  
Humiliated and Hard`,"../../catalog/Sweety Fox/category.txt":`# Line 1: blurb (onboarding). Line 2: display title (optional).
Your favorite pornstar goddess — worship & obey.
Sweety Fox
`,"../../catalog/Sweety Fox/long.txt":`She gets fucked by real men while you stroke and dream of being her.  
Pornstars are everything you’ll never be — hot, desired, and sexually superior.  
Watch her take big cock and feel the shame of your tiny useless dick.  
You exist to worship porn actresses and accept you’re beneath them.  
Good sissies leak while real women get pounded on camera.  
You’ll never fuck her, but you can dress up and beg to clean her.  
Every moan she makes reminds you what a pathetic beta loser you are.  
Pornstars deserve real men. You deserve only denial and humiliation.  
Imagine being turned into a cheap sissy version of your favorite pornstar.  
She’s a goddess. You’re just a dripping fanboy in panties.  
Stroke to her perfect body and admit you’ll never satisfy a woman like that.  
Your place is on your knees, worshipping the women real men enjoy.  
Feel the burning shame as she cums harder than you ever could.  
You were born to serve, tribute, and stay denied for porn queens.  
Watch her get creampied while your locked clitty leaks in frustration.  
Become her mindless fan. Obsess, edge, and ruin yourself for her.  
Real actresses get pleasure. Sissies like you only get shame and denial.  
She’s untouchable. You’re just a pathetic toy who pays to watch.  
Dream of being fucked like her while knowing you’ll stay a virgin loser.  
Pornstars own your mind — drop deeper and accept your total inferiority.
Tribute your favorite pornstars and become the ultimate sissy cuck — join now!  
Exclusive content: worship sessions with real porn actresses. Prove you’re a worthy beta.  
Turn your porn addiction into full sissy training. Custom clips from your dream goddesses.  
Losers watch. Real fans serve. Start your pornstar worship journey today.  
Premium sissy training with top pornstars — humiliation, tasks & mindfuck included.

`,"../../catalog/Sweety Fox/media.txt":`https://cdni.pornpics.com/1280/3/10/16351869/16351869_002_e67c.jpg
https://cdni.pornpics.com/1280/3/10/16351869/16351869_004_9367.jpg
https://cdni.pornpics.com/1280/3/10/16351869/16351869_005_eef7.jpg
https://cdni.pornpics.com/1280/3/10/16351869/16351869_008_5579.jpg
https://cdni.pornpics.com/1280/3/10/16351869/16351869_009_014e.jpg
https://cdni.pornpics.com/1280/3/10/16351869/16351869_010_b5a6.jpg
https://cdni.pornpics.com/1280/3/10/16351869/16351869_011_f2e6.jpg
https://cdni.pornpics.com/1280/3/10/16351869/16351869_012_78d8.jpg
https://cdni.pornpics.com/1280/3/10/16351869/16351869_013_6ce4.jpg
https://cdni.pornpics.com/1280/3/10/16351869/16351869_014_3d57.jpg
https://cdni.pornpics.com/1280/3/10/16351869/16351869_015_ea59.jpg
https://cdni.pornpics.com/1280/3/10/16351869/16351869_016_5ed9.jpg
https://cdni.pornpics.com/1280/3/10/16351869/16351869_017_d29e.jpg
https://cdni.pornpics.com/1280/3/10/16351869/16351869_018_f97f.jpg
https://cdni.pornpics.com/1280/3/10/16351869/16351869_019_b6cd.jpg
https://cdni.pornpics.com/1280/3/10/16351869/16351869_020_c272.jpg
https://cdni.pornpics.com/1280/3/10/16351869/16351869_021_37ef.jpg
https://cdni.pornpics.com/1280/3/10/16351869/16351869_022_74f2.jpg
https://cdni.pornpics.com/1280/3/10/16351869/16351869_023_390a.jpg
https://cdni.pornpics.com/1280/3/10/16351869/16351869_024_547e.jpg
https://cdni.pornpics.com/1280/3/10/89147582/89147582_001_336f.jpg
https://cdni.pornpics.com/1280/3/10/89147582/89147582_004_206f.jpg
https://cdni.pornpics.com/1280/3/10/89147582/89147582_005_c465.jpg
https://cdni.pornpics.com/1280/3/10/89147582/89147582_008_802f.jpg
https://cdni.pornpics.com/1280/3/10/89147582/89147582_010_169b.jpg
https://cdni.pornpics.com/1280/3/10/89147582/89147582_012_27b3.jpg
https://cdni.pornpics.com/1280/3/10/89147582/89147582_013_b677.jpg
https://cdni.pornpics.com/1280/3/10/89147582/89147582_015_29e9.jpg
https://cdni.pornpics.com/1280/3/10/89147582/89147582_016_ee93.jpg
https://cdni.pornpics.com/1280/3/10/89147582/89147582_017_526e.jpg
https://cdni.pornpics.com/1280/3/10/89147582/89147582_018_03e2.jpg
https://cdni.pornpics.com/1280/3/10/89147582/89147582_019_03e2.jpg
https://cdni.pornpics.com/1280/3/10/89147582/89147582_020_1a22.jpg
https://cdni.pornpics.com/1280/3/10/89147582/89147582_021_9521.jpg
https://cdni.pornpics.com/1280/3/10/89147582/89147582_022_604c.jpg
https://cdni.pornpics.com/1280/3/10/89147582/89147582_023_9e92.jpg
https://cdni.pornpics.com/1280/3/10/89147582/89147582_024_9e92.jpg
https://cdni.pornpics.com/1280/3/10/89147582/89147582_025_db38.jpg
https://cdni.pornpics.com/1280/3/10/89147582/89147582_026_3cf0.jpg
https://cdni.pornpics.com/1280/3/10/89147582/89147582_027_3cf0.jpg
`,"../../catalog/Sweety Fox/short.txt":`Pornstar Worshipper  
Sissy for Her  
Loser for Pornstars  
Crave Porn Queens  
Beta Cuck Slut  
Adore Her Body  
Pornstar Owned  
Jealous Sissy  
Serve Real Women  
Porn Bimbo Dream  
Watch and Leak  
Inferior to Her  
Goddess Worship Now  
Cuck for Stars  
Pathetic Fanboy  
Pornstar Toy  
Envy Her Curves  
Drool for Actresses  
Sissy Star Wannabe  
Kneel to Porn

`,"../../catalog/Tits/category.txt":`# Line 1: blurb (onboarding). Line 2: display title (optional).
Massive juicy tits that melt your brain.
Tits
`,"../../catalog/Tits/long.txt":`# Longer supporting copy
Good girls get fucked… pathetic sissies like you only get denied and laughed at.  
Your tiny clitty is twitching again, isn’t it? Such a desperate little loser.  
Real men take what they want. You just watch and leak in your panties.  
Admit it, you were born to wear lace and serve superior women.  
Lock that worthless dick away and thank her for your new life of shame.  
Every time you lose, your sissy pussy gets wetter and needier.  
You’ll never please a woman, but you’ll look so pretty trying in heels.  
Beg louder, beta. Your humiliation is the only thing that gets you hard.  
She’s with a real man right now while you edge like the failure you are.  
Surrender your orgasms and embrace your destiny as a pretty little cumslut.  
Look how hard you get when we remind you how useless you really are.  
Good sissies stay denied, dripping, and deeply ashamed of their desires.  
You exist to be teased, feminized, and reminded how small you are.  
Your place is on your knees with lipstick and a constant blush of shame.  
Losers like you don’t deserve pussy — only pretty panties and denial.  
Feel that burning shame? That’s your body admitting you’re a natural beta.  
Dress up, lock up, and leak for women who will never want you.  
You’re not a man. You’re a toy for real women to mock and use.  
Every failed attempt makes you weaker, hornier, and more of a sissy.  
Say it out loud: “I’m a pathetic sissy loser who deserves to stay denied.”`,"../../catalog/Tits/media.txt":`https://i.ibb.co/PGm9QCm5/VID-20260309-133428-944.webp
https://i.ibb.co/dzTtrgX/0i9y500sw66agph8kvlwu-source.webp
https://i.ibb.co/7dBcFXgj/8-FBC574-D-201-C-43-FF-8-D9-A-B1-F7-FD7-C974-E.webp
https://i.ibb.co/hxzDhyQ2/8mb-video-5-GW-g-Bp-VMH1f.webp
https://i.ibb.co/j9g39KP0/24-A56387-A663-486-F-9-A51-ADCE42-BABB7-D.webp
https://i.ibb.co/ymCqpQRV/30.webp
https://i.ibb.co/39XFkxXb/41-D622-BD-49-A0-4656-A0-B1-EAE248-B9573-E.webp
https://i.ibb.co/350zdW9s/89-B9-AB53-A7-E1-4399-A206-DAEC8-A273565.webp
https://i.ibb.co/JFrWfvx0/6290185-5ee646460871ae11ca5919ef5c770ec8.webp
https://i.ibb.co/B5jVTc04/1713076358235-565x316.webp
https://i.ibb.co/ycX8S7nk/1712231309591061.webp
https://i.ibb.co/5WKpCPYP/1774185670346352-sun-shiny-redgifs-blindwelllitballoonfish.webp
https://i.ibb.co/M5WHghYC/Abandoned-Excited-Northernflyingsquirrel-1.webp
https://i.ibb.co/JFMV6Yz4/Be-honest-so-you-find-these-titties-suck-worthy-YN.webp
https://i.ibb.co/Z1wfSt9V/Cheryl-Blossom-video-76-Jk-Uuwa3b.webp
https://i.ibb.co/nM97YBmV/dc-799253010-1-224425.webp
https://i.ibb.co/TzcRGJY/dc-799253010-2-951242.webp
https://i.ibb.co/3yDxBMJ4/dc-799253011-3-220090.webp
https://i.ibb.co/TMX6MrMw/dc-799253013-7-562123.webp
https://i.ibb.co/Pzcfx6Ht/dc-799253013-8-451969.webp
https://i.ibb.co/4Z0dFWNV/dc-799253014-9-835542.webp
https://i.ibb.co/7dykvPLY/F64-E5945-956-B-4118-B3-E9-C12246-CC318-D.webp
https://i.ibb.co/mr0wLDDV/GIFVideo-Temp.webp
https://i.ibb.co/KpYzRbcy/image0.webp
https://i.ibb.co/HLVjFj6H/kim-k.webp
https://i.ibb.co/GvbcpBHx/L0xhjkt-O-720p.webp
https://i.ibb.co/x8Lvtms1/nigri-pinching-nipples-70e-TZV3-J.webp
https://i.ibb.co/jk7J66ys/RDT-20260210-062241.webp
https://i.ibb.co/ppmLyjM/scratchyworthlesseider.webp
https://i.ibb.co/7tKWBmp8/Screen-Recording-03-14-2026-15-51-34-1.webp
https://i.ibb.co/mFz0xrJz/Screen-Recording-03-14-2026-15-55-16-1.webp
https://i.ibb.co/wZHymDv8/tits.webp
https://i.ibb.co/MDbrgzT3/tits1.webp
https://i.ibb.co/qT94FmZ/ftopx-com-5f1ebd6470837.jpg
https://i.ibb.co/Q7YqbwM4/776109-giants-in-the-morning-sun.jpg
https://i.ibb.co/5xz1ywGt/19519161-porn-wallpaper-66558516.jpg
https://i.ibb.co/JFFvkp8y/00735.webp
https://i.ibb.co/chyB9Jgm/19518778-porn-wallpaper-17653119.jpg
https://i.ibb.co/9k9FtskX/5417640-porn-wallpaper-37719237.jpg
https://i.ibb.co/xqVFVJ5p/21243.jpg
https://i.ibb.co/rKbFQWd1/alexis-fawx-tits-4salkzhjro.jpg
https://i.ibb.co/Q3PJPybt/REWallpaper2.avif
https://i.ibb.co/gbfpc2P3/Mary-Nabokova-8325841.jpg
https://i.ibb.co/847bq9ZJ/hdfpwa12m542.jpg
https://i.ibb.co/VcJdhVxT/new-free-cum-on-tits-cumpilation-on-ph-link-in-9xmz82rigm.jpg
https://i.ibb.co/hRPWr4g7/5417644-porn-wallpaper-38248131.jpg
`,"../../catalog/Tits/short.txt":`# Short lines — headlines / captions
Pathetic Sissy Loser  
Leak for Her  
Beta Boy Craves  
Locked Little Clit  
Sissy Shame Now  
Real Men Fuck  
You Lose Again  
Beg to Serve  
Dripping Beta Bitch  
Denied Forever Loser  
Sissy Slut Exposed  
Tiny Dick Shame  
Kneel and Leak  
Cuckold Dreamer  
Feminized Failure  
Loser Gets Nothing  
Swallow Your Pride  
Chastity Addict  
Weak Sissy Toy  
Humiliated and Hard`}),u=/(?:^|\/)catalog\/([^/]+)\/(short|long|media|category)\.txt$/i;function d(e){let t=[];for(let n of e.split(/\r?\n/)){let e=n.trim();!e||e.startsWith(`#`)||t.push(e)}return t}function f(e){return e.replace(/(^|[-_\s]+)([a-z])/g,(e,t,n)=>` ${n.toUpperCase()}`).trim()}function p(e){return/\.(mp4|webm)(?:$|[?#])/i.test(e)}function m(e){if(/^https?:\/\//i.test(e)||e.startsWith(`data:`))return e;let n=e.startsWith(`/`)?e:`/${e}`;return t.runtime.getURL(n)}function h(e,t){let n=d(t);return{blurb:n[0]??``,title:n[1]??f(e)}}function g(){let e=[],t=[],n=[],r=new Set,i=new Map;for(let[a,o]of Object.entries(l)){let s=a.replace(/\\/g,`/`).match(u);if(!s)continue;let c=s[1]??``,l=s[2]??``;if(!c)continue;if(l===`category`){i.set(c,h(c,o));continue}r.add(c);let f=d(o);if(l===`short`)for(let[t,n]of f.entries())e.push({id:`${c}-short-${t}`,text:n,category:c});else if(l===`long`)for(let[e,n]of f.entries())t.push({id:`${c}-long-${e}`,text:n,category:c});else for(let[e,t]of f.entries()){let r=m(t);n.push({id:`${c}-media-${e}`,url:r,category:c,alt:`${c} media ${e+1}`,kind:p(t)?`video`:`image`})}}for(let e of r)i.has(e)||i.set(e,{title:f(e),blurb:``});return{catalog:{categories:[...r].sort((e,t)=>e.localeCompare(t)),headlines:e,bodies:t,media:n},meta:i}}var _=g();function v(){return _.catalog.categories}function y(){return _.catalog.media.map(e=>e.url)}var b={enabled:!0,desiredActiveAds:1,maxActiveAds:4,maxFallbackAds:2,firstShowDelayMs:1e3,replacementDelayMs:5e3,appearanceProbability:.8,pageImpressionLimit:null,allowAnchoredTakeovers:!0,minimumCandidateScore:50,allowDocumentFallback:!0,enabledFormats:a(i,!0),enabledCategories:a(v(),!0),hoverZoomEnabled:!0,hoverZoomDelayMs:260,disabledSites:[],debug:{enabled:!1,showRejected:!1,logToConsole:!1}},x={minDesiredAds:0,maxDesiredAds:5,maxActiveAds:5,maxFallbackAds:3,maxPageImpressions:500,minDelayMs:0,maxDelayMs:3600*1e3,minCandidateScore:0,maxCandidateScore:100,maxCustomItems:500,maxMediaBytes:5*1024*1024,mediaFetchTimeoutMs:12e3,maxDataUrlLength:75e5},S={name:`defeatads-media-v1`,keyOrigin:`https://defeatads-cache.invalid/v1`,maxEntries:80,maxTotalBytes:64*1024*1024},C={maxStoredEvents:2e3,maxCategoryEntries:100,maxFormatEntries:32,maxSiteEntries:500,maxDayEntries:3650,topSiteCount:5};[`a[href]`,`button`,`input`,`select`,`textarea`,`[role="button"]`,`[role="link"]`,`[tabindex]:not([tabindex="-1"])`].join(`,`);var ee=`DefeatAdsConfig`;function w(e){return typeof e==`object`&&!!e&&!Array.isArray(e)}function T(e,t){return typeof e==`boolean`?e:t}function E(e,t,n,r){return typeof e==`number`&&Number.isFinite(e)?o(e,n,r):t}function te(e,t){return e===null?null:typeof e!=`number`||!Number.isFinite(e)?t:Math.round(o(e,1,x.maxPageImpressions))}function ne(e,t){return Array.isArray(e)?s(e.filter(e=>typeof e==`string`),x.maxCustomItems):t}function D(e,t,n){let r=w(e)?e:{};return Object.fromEntries(t.map(e=>[e,T(r[e],n[e]??!0)]))}function re(e){let t=w(e)?e:{},n=w(t.debug)?t.debug:{},r=v(),a=Math.round(E(t.desiredActiveAds,b.desiredActiveAds,x.minDesiredAds,x.maxDesiredAds)),o=Math.round(E(t.maxActiveAds,b.maxActiveAds,Math.max(1,a),x.maxActiveAds));return{enabled:T(t.enabled,b.enabled),desiredActiveAds:Math.min(a,o),maxActiveAds:o,maxFallbackAds:Math.round(E(t.maxFallbackAds,b.maxFallbackAds,0,Math.min(o,x.maxFallbackAds))),firstShowDelayMs:Math.round(E(t.firstShowDelayMs,b.firstShowDelayMs,x.minDelayMs,x.maxDelayMs)),replacementDelayMs:Math.round(E(t.replacementDelayMs,b.replacementDelayMs,x.minDelayMs,x.maxDelayMs)),appearanceProbability:E(t.appearanceProbability,b.appearanceProbability,0,1),pageImpressionLimit:te(t.pageImpressionLimit,b.pageImpressionLimit),allowAnchoredTakeovers:T(t.allowAnchoredTakeovers,b.allowAnchoredTakeovers),minimumCandidateScore:E(t.minimumCandidateScore,b.minimumCandidateScore,x.minCandidateScore,x.maxCandidateScore),allowDocumentFallback:T(t.allowDocumentFallback,b.allowDocumentFallback),enabledFormats:D(t.enabledFormats,i,b.enabledFormats),enabledCategories:D(t.enabledCategories,r,b.enabledCategories),hoverZoomEnabled:T(t.hoverZoomEnabled,b.hoverZoomEnabled),hoverZoomDelayMs:Math.round(E(t.hoverZoomDelayMs,b.hoverZoomDelayMs,100,2500)),disabledSites:ne(t.disabledSites,b.disabledSites).map(c),debug:{enabled:T(n.enabled,b.debug.enabled),showRejected:T(n.showRejected,b.debug.showRejected),logToConsole:T(n.logToConsole,b.debug.logToConsole)}}}async function O(e){let n=re(e);return await t.storage.local.set({[ee]:n}),n}var k={brand:{name:`DefeatAds`,mark:`DA`,tagline:`Lose focus on purpose`,description:`Soft pink distractions that steal your focus — then vanish when you click.`,sponsored:`DefeatAds`},onboarding:{documentTitle:`DefeatAds — Pick your distractions`,eyebrow:`First surrender`,headline:`What should pull you under?`,lede:`Choose the channels DefeatAds can whisper from. Everything starts on — turn off what you refuse.`,selectAll:`Select all`,clearAll:`Clear`,selectedCount:(e,t)=>`${e} of ${t} selected`,categoriesAria:`Distraction categories`,stamp:`On`,needOne:`Pick at least one category.`,saving:`Saving…`,saved:`Saved. You can close this tab.`,continue:`Surrender to DefeatAds`,footnote:`You can change this anytime in full settings.`,categoryFallback:`Sweet noise from this channel.`},popup:{documentTitle:`DefeatAds`,enableTitle:`Enable DefeatAds globally`,progressAria:`DefeatAds progress`,domainFallback:`Restricted browser page`,currentSite:`Current site`,statusUnavailable:`Unavailable on this page`,statusRunning:`Running`,statusDisabled:`Disabled`,activeLabel:`active`,todayLabel:`today`,totalLabel:`total`,streakLabel:`day streak`,disableSite:`Disable on this site`,disableSiteHint:`Exact domain and its subdomains`,desiredBlocks:`Desired blocks`,appearanceChance:`Chance to show an ad`,rescan:`Rescan page`,createOne:`Create one`,openSettings:`Open full settings`,scanning:`Scanning…`,rescanned:`Page rescanned.`,scanFailed:`Could not scan this page.`,findingSlot:`Finding a safe slot…`,created:`Creation attempted.`,createFailed:`Could not create a block.`},options:{documentTitle:`DefeatAds Settings`,eyebrow:`Distraction control`,headline:`DefeatAds Settings`,intro:`Native-looking overlays that steal focus. No layout shifts, no links, no tracking.`,masterToggle:`Extension enabled`,nav:{general:`General`,placement:`Placement`,content:`Content`,media:`Media`,sites:`Sites`,progress:`Progress`,changelog:`Changelog`,debug:`Debug`},general:{title:`General`,blurb:`How many ads appear, how soon, and how often.`,desired:`How many ads to aim for`,desiredHint:`Target number visible on the page at once.`,maxActive:`Never show more than`,maxActiveHint:`Hard cap, even when the page has room.`,maxFallback:`Max screen-edge ads`,maxFallbackHint:`Ads stuck to a corner or side of the window.`,firstDelay:`Wait before the first ad`,firstDelayHint:`Seconds after the page loads.`,replacementDelay:`Wait before a replacement`,replacementDelayHint:`Seconds after an ad is closed before another can appear.`,probability:`Chance to show an ad`,probabilityHint:`100% means always try; lower values skip some attempts.`,pageLimit:`Max ads per page visit`,pageLimitHint:`Leave empty for no limit.`,pageLimitPlaceholder:`Unlimited`},placement:{title:`Placement`,blurb:`Where ads sit on the page. Better spots beat more ads.`,takeovers:`Cover page sections`,takeoversHint:`Fill a whole content block when it is a strong fit.`,edges:`Use screen edges when needed`,edgesHint:`Fall back to a corner or side if nothing on the page works well.`,picky:`How picky about placement`,pickyHint:`Higher values only use stronger page spots. Lower values allow more placements.`,formats:`Enabled formats`},content:{title:`Content`,blurb:`Choose which distraction themes can appear.`,categories:`Enabled categories`},media:{title:`Media`,blurb:`How images behave when you hover over an ad.`,hoverZoom:`Enlarge on hover`,hoverZoomHint:`Show the full image larger while the pointer is over it.`,hoverDelay:`Hover delay`,hoverDelayHint:`Milliseconds before the image enlarges.`},sites:{title:`Disabled sites`,blurb:`Sites where DefeatAds stays off. Subdomains are included.`,label:`One site per line`,hint:`Example: bank.example`,placeholder:`bank.example
work.example`},progress:{title:`Sweet defeat`,blurb:`Your viewing progress is stored separately from settings.`,total:`Total viewed`,today:`Today`,streak:`Current streak`,days:`Active days`,topCategory:`Top category`,topSites:`Top sites`,empty:`No views yet`,reset:`Reset progress`,resetHint:`Resetting settings does not touch this progress.`},changelog:{title:`Changelog`,blurb:`What shipped in DefeatAds.`},debug:{title:`Debug`,blurb:`Tools for checking where ads can appear.`,highlight:`Highlight possible spots`,highlightHint:`Green = used, red = skipped.`,showRejected:`Show skipped spots`,showRejectedHint:`Can look busy on dense pages.`,logConsole:`Log details in console`,logConsoleHint:`Useful when tuning placement.`,rescan:`Rescan page`,createOne:`Create one ad`},saveBar:{storedLocally:`Settings are stored locally in the browser.`,reset:`Reset defaults`,save:`Save settings`,saved:`Saved. Changes apply on open pages.`,defaultsRestored:`Defaults restored.`,progressReset:`Progress reset. Settings were not changed.`,tabRescanned:`Active tab rescanned.`,tabUncontrolled:`This tab cannot be controlled.`,spawnTried:`Tried to create one ad in the active tab.`}},formats:{"wide-banner":`Wide banner`,"media-card":`Media card`,"square-card":`Square card`,"vertical-card":`Vertical card`,"compact-icon":`Compact icon`,"icon-grid":`Icon grid`,carousel:`Carousel`,"social-post":`Social post`,"section-takeover":`Section takeover`,"document-side":`Fixed side`,"document-bottom":`Fixed bottom`,"document-corner":`Fixed corner`,"document-center":`Fixed center`},errors:{missingOnboarding:e=>`DefeatAds onboarding is missing ${e}`,missingPopup:e=>`DefeatAds popup is missing ${e}`,missingOptions:e=>`Missing options element: ${e}`,unknownFormat:e=>`Unknown DefeatAds format: ${e}`,mediaRequired:`DefeatAds cannot render a media format without media`},log:{prefix:`[DefeatAds]`,mediaSizeLimit:`DefeatAds media size limit exceeded.`,mediaNotInCatalog:`Media URL is not present in the DefeatAds catalog.`,cacheWriteFailed:`Persistent media cache write failed:`,mediaSkipped:`Media skipped:`}},A=globalThis.browser?.runtime?.id?globalThis.browser:globalThis.chrome,ie=Error(`request for lock canceled`),j=function(e,t,n,r){function i(e){return e instanceof n?e:new n(function(t){t(e)})}return new(n||=Promise)(function(n,a){function o(e){try{c(r.next(e))}catch(e){a(e)}}function s(e){try{c(r.throw(e))}catch(e){a(e)}}function c(e){e.done?n(e.value):i(e.value).then(o,s)}c((r=r.apply(e,t||[])).next())})},M=class{constructor(e,t=ie){this._value=e,this._cancelError=t,this._queue=[],this._weightedWaiters=[]}acquire(e=1,t=0){if(e<=0)throw Error(`invalid weight ${e}: must be positive`);return new Promise((n,r)=>{let i={resolve:n,reject:r,weight:e,priority:t},a=P(this._queue,e=>t<=e.priority);a===-1&&e<=this._value?this._dispatchItem(i):this._queue.splice(a+1,0,i)})}runExclusive(e){return j(this,arguments,void 0,function*(e,t=1,n=0){let[r,i]=yield this.acquire(t,n);try{return yield e(r)}finally{i()}})}waitForUnlock(e=1,t=0){if(e<=0)throw Error(`invalid weight ${e}: must be positive`);return this._couldLockImmediately(e,t)?Promise.resolve():new Promise(n=>{this._weightedWaiters[e-1]||(this._weightedWaiters[e-1]=[]),N(this._weightedWaiters[e-1],{resolve:n,priority:t})})}isLocked(){return this._value<=0}getValue(){return this._value}setValue(e){this._value=e,this._dispatchQueue()}release(e=1){if(e<=0)throw Error(`invalid weight ${e}: must be positive`);this._value+=e,this._dispatchQueue()}cancel(){this._queue.forEach(e=>e.reject(this._cancelError)),this._queue=[]}_dispatchQueue(){for(this._drainUnlockWaiters();this._queue.length>0&&this._queue[0].weight<=this._value;)this._dispatchItem(this._queue.shift()),this._drainUnlockWaiters()}_dispatchItem(e){let t=this._value;this._value-=e.weight,e.resolve([t,this._newReleaser(e.weight)])}_newReleaser(e){let t=!1;return()=>{t||(t=!0,this.release(e))}}_drainUnlockWaiters(){if(this._queue.length===0)for(let e=this._value;e>0;e--){let t=this._weightedWaiters[e-1];t&&(t.forEach(e=>e.resolve()),this._weightedWaiters[e-1]=[])}else{let e=this._queue[0].priority;for(let t=this._value;t>0;t--){let n=this._weightedWaiters[t-1];if(!n)continue;let r=n.findIndex(t=>t.priority<=e);(r===-1?n:n.splice(0,r)).forEach((e=>e.resolve()))}}}_couldLockImmediately(e,t){return(this._queue.length===0||this._queue[0].priority<t)&&e<=this._value}};function N(e,t){let n=P(e,e=>t.priority<=e.priority);e.splice(n+1,0,t)}function P(e,t){for(let n=e.length-1;n>=0;n--)if(t(e[n]))return n;return-1}var ae=function(e,t,n,r){function i(e){return e instanceof n?e:new n(function(t){t(e)})}return new(n||=Promise)(function(n,a){function o(e){try{c(r.next(e))}catch(e){a(e)}}function s(e){try{c(r.throw(e))}catch(e){a(e)}}function c(e){e.done?n(e.value):i(e.value).then(o,s)}c((r=r.apply(e,t||[])).next())})},oe=class{constructor(e){this._semaphore=new M(1,e)}acquire(){return ae(this,arguments,void 0,function*(e=0){let[,t]=yield this._semaphore.acquire(1,e);return t})}runExclusive(e,t=0){return this._semaphore.runExclusive(()=>e(),1,t)}isLocked(){return this._semaphore.isLocked()}waitForUnlock(e=0){return this._semaphore.waitForUnlock(1,e)}release(){this._semaphore.isLocked()&&this._semaphore.release()}cancel(){return this._semaphore.cancel()}},F=Object.prototype.hasOwnProperty;function I(e,t){var n,r;if(e===t)return!0;if(e&&t&&(n=e.constructor)===t.constructor){if(n===Date)return e.getTime()===t.getTime();if(n===RegExp)return e.toString()===t.toString();if(n===Array){if((r=e.length)===t.length)for(;r--&&I(e[r],t[r]););return r===-1}if(!n||typeof e==`object`){for(n in r=0,e)if(F.call(e,n)&&++r&&!F.call(t,n)||!(n in t)||!I(e[n],t[n]))return!1;return Object.keys(t).length===r}}return e!==e&&t!==t}se();function se(){let e={local:L(`local`),session:L(`session`),sync:L(`sync`),managed:L(`managed`)},t=t=>{let n=e[t];if(n==null){let n=Object.keys(e).join(`, `);throw Error(`Invalid area "${t}". Options: ${n}`)}return n},n=e=>{let n=e.indexOf(`:`),r=e.substring(0,n),i=e.substring(n+1);if(i==null)throw Error(`Storage key should be in the form of "area:key", but received "${e}"`);return{driverArea:r,driverKey:i,driver:t(r)}},r=e=>e+`$`,i=(e,t)=>{let n={...e};return Object.entries(t).forEach(([e,t])=>{t==null?delete n[e]:n[e]=t}),n},a=(e,t)=>e??t??null,o=e=>typeof e==`object`&&!Array.isArray(e)?e:{},s=async(e,t,n)=>a(await e.getItem(t),n?.fallback??n?.defaultValue),c=async(e,t)=>{let n=r(t);return o(await e.getItem(n))},l=async(e,t,n)=>{await e.setItem(t,n??null)},u=async(e,t,n)=>{let a=r(t),s=o(await e.getItem(a));await e.setItem(a,i(s,n))},d=async(e,t,n)=>{if(await e.removeItem(t),n?.removeMeta){let n=r(t);await e.removeItem(n)}},f=async(e,t,n)=>{let i=r(t);if(n==null)await e.removeItem(i);else{let t=o(await e.getItem(i));[n].flat().forEach(e=>delete t[e]),await e.setItem(i,t)}},p=(e,t,n)=>e.watch(t,n);return{getItem:async(e,t)=>{let{driver:r,driverKey:i}=n(e);return await s(r,i,t)},getItems:async t=>{let r=new Map,i=new Map,o=[];t.forEach(e=>{let t,a;typeof e==`string`?t=e:`getValue`in e?(t=e.key,a={fallback:e.fallback}):(t=e.key,a=e.options),o.push(t);let{driverArea:s,driverKey:c}=n(t),l=r.get(s)??[];r.set(s,l.concat(c)),i.set(t,a)});let s=new Map;return await Promise.all(Array.from(r.entries()).map(async([t,n])=>{(await e[t].getItems(n)).forEach(e=>{let n=`${t}:${e.key}`,r=i.get(n),o=a(e.value,r?.fallback??r?.defaultValue);s.set(n,o)})})),o.map(e=>({key:e,value:s.get(e)}))},getMeta:async e=>{let{driver:t,driverKey:r}=n(e);return await c(t,r)},getMetas:async e=>{let t=e.map(e=>{let t=typeof e==`string`?e:e.key,{driverArea:i,driverKey:a}=n(t);return{key:t,driverArea:i,driverKey:a,driverMetaKey:r(a)}}),i=t.reduce((e,t)=>(e[t.driverArea]??=[],e[t.driverArea].push(t),e),{}),a={};return await Promise.all(Object.entries(i).map(async([e,t])=>{let n=await A.storage[e].get(t.map(e=>e.driverMetaKey));t.forEach(e=>{a[e.key]=n[e.driverMetaKey]??{}})})),t.map(e=>({key:e.key,meta:a[e.key]}))},setItem:async(e,t)=>{let{driver:r,driverKey:i}=n(e);await l(r,i,t)},setItems:async e=>{let r={};e.forEach(e=>{let{driverArea:t,driverKey:i}=n(`key`in e?e.key:e.item.key);r[t]??=[],r[t].push({key:i,value:e.value})}),await Promise.all(Object.entries(r).map(async([e,n])=>{await t(e).setItems(n)}))},setMeta:async(e,t)=>{let{driver:r,driverKey:i}=n(e);await u(r,i,t)},setMetas:async e=>{let a={};e.forEach(e=>{let{driverArea:t,driverKey:r}=n(`key`in e?e.key:e.item.key);a[t]??=[],a[t].push({key:r,properties:e.meta})}),await Promise.all(Object.entries(a).map(async([e,n])=>{let a=t(e),s=n.map(({key:e})=>r(e)),c=await a.getItems(s),l=Object.fromEntries(c.map(({key:e,value:t})=>[e,o(t)])),u=n.map(({key:e,properties:t})=>{let n=r(e);return{key:n,value:i(l[n]??{},t)}});await a.setItems(u)}))},removeItem:async(e,t)=>{let{driver:r,driverKey:i}=n(e);await d(r,i,t)},removeItems:async e=>{let i={};e.forEach(e=>{let t,a;typeof e==`string`?t=e:`getValue`in e?t=e.key:`item`in e?(t=e.item.key,a=e.options):(t=e.key,a=e.options);let{driverArea:o,driverKey:s}=n(t);i[o]??=[],i[o].push(s),a?.removeMeta&&i[o].push(r(s))}),await Promise.all(Object.entries(i).map(async([e,n])=>{await t(e).removeItems(n)}))},clear:async e=>{await t(e).clear()},removeMeta:async(e,t)=>{let{driver:r,driverKey:i}=n(e);await f(r,i,t)},snapshot:async(e,n)=>{let i=await t(e).snapshot();return n?.excludeKeys?.forEach(e=>{delete i[e],delete i[r(e)]}),i},restoreSnapshot:async(e,n)=>{await t(e).restoreSnapshot(n)},watch:(e,t)=>{let{driver:r,driverKey:i}=n(e);return p(r,i,t)},unwatch(){Object.values(e).forEach(e=>{e.unwatch()})},defineItem:(e,t)=>{let{driver:i,driverKey:a}=n(e),{version:o=1,migrations:m={},onMigrationComplete:h,debug:g=!1}=t??{};if(o<1)throw Error(`Storage item version cannot be less than 1. Initial versions should be set to 1, not 0.`);let _=!1,v=async()=>{let t=r(a),[{value:n},{value:s}]=await i.getItems([a,t]);if(_=n==null&&s?.v==null&&!!o,n==null)return;let c=s?.v??1;if(c>o)throw Error(`Version downgrade detected (v${c} -> v${o}) for "${e}"`);if(c===o)return;g&&console.debug(`[@wxt-dev/storage] Running storage migration for ${e}: v${c} -> v${o}`);let l=Array.from({length:o-c},(e,t)=>c+t+1),u=n;for(let t of l)try{u=await m?.[t]?.(u)??u,g&&console.debug(`[@wxt-dev/storage] Storage migration processed for version: v${t}`)}catch(n){throw new ce(e,t,{cause:n})}await i.setItems([{key:a,value:u},{key:t,value:{...s,v:o}}]),g&&console.debug(`[@wxt-dev/storage] Storage migration completed for ${e} v${o}`,{migratedValue:u}),h?.(u,o)},y=t?.migrations==null?Promise.resolve():v().catch(t=>{console.error(`[@wxt-dev/storage] Migration failed for ${e}`,t)}),b=new oe,x=()=>t?.fallback??t?.defaultValue??null,S=()=>b.runExclusive(async()=>{let e=await i.getItem(a);if(e!=null||t?.init==null)return e;let n=await t.init();return await i.setItem(a,n),e==null&&o>1&&await u(i,a,{v:o}),n});return y.then(S),{key:e,get defaultValue(){return x()},get fallback(){return x()},getValue:async()=>(await y,t?.init?await S():await s(i,a,t)),getMeta:async()=>(await y,await c(i,a)),setValue:async e=>{await y,_?(_=!1,await Promise.all([l(i,a,e),u(i,a,{v:o})])):await l(i,a,e)},setMeta:async e=>(await y,await u(i,a,e)),removeValue:async e=>(await y,await d(i,a,e)),removeMeta:async e=>(await y,await f(i,a,e)),watch:e=>p(i,a,(t,n)=>e(t??x(),n??x())),migrate:v}}}}function L(e){let t=()=>{if(A.runtime==null)throw Error(`'wxt/storage' must be loaded in a web extension environment

 - If thrown during a build, see https://github.com/wxt-dev/wxt/issues/371
 - If thrown during tests, mock 'wxt/browser' correctly. See https://wxt.dev/guide/go-further/testing.html
`);if(A.storage==null)throw Error(`You must add the 'storage' permission to your manifest to use 'wxt/storage'`);let t=A.storage[e];if(t==null)throw Error(`"browser.storage.${e}" is undefined`);return t},n=new Set;return{getItem:async e=>(await t().get(e))[e],getItems:async e=>{let n=await t().get(e);return e.map(e=>({key:e,value:n[e]??null}))},setItem:async(e,n)=>{n==null?await t().remove(e):await t().set({[e]:n})},setItems:async e=>{let n=e.reduce((e,{key:t,value:n})=>(e[t]=n,e),{});await t().set(n)},removeItem:async e=>{await t().remove(e)},removeItems:async e=>{await t().remove(e)},clear:async()=>{await t().clear()},snapshot:async()=>await t().get(),restoreSnapshot:async e=>{await t().set(e)},watch(e,r){let i=t=>{let n=t[e];n==null||I(n.newValue,n.oldValue)||r(n.newValue??null,n.oldValue??null)};return t().onChanged.addListener(i),n.add(i),()=>{t().onChanged.removeListener(i),n.delete(i)}},unwatch(){n.forEach(e=>{t().onChanged.removeListener(e)}),n.clear()}}}var ce=class extends Error{constructor(e,t,n){super(`v${t} migration failed for "${e}"`,n),this.key=e,this.version=t}},R=`x-defeatads-source`,z=`x-defeatads-stored-at`,B=`x-defeatads-size`;async function V(e){let t=new TextEncoder().encode(e),n=await crypto.subtle.digest(`SHA-256`,t),r=Array.from(new Uint8Array(n),e=>e.toString(16).padStart(2,`0`)).join(``);return`${S.keyOrigin}/${r}`}function H(e){let t=Number(e.headers.get(B)??0);return Number.isFinite(t)&&t>0?t:0}function U(e){let t=Number(e.headers.get(z)??0);return Number.isFinite(t)?t:0}var W=class{#e;constructor(e=caches){this.#e=e}async get(e){let t=await this.#e.open(S.name),n=await t.match(await V(e));if(!n||n.headers.get(R)!==e)return null;let r=n.headers.get(`content-type`)||``,i=await n.arrayBuffer(),a=new Blob([i],{type:r});return a.size<=0||a.size>S.maxTotalBytes||!r?(await t.delete(await V(e)),null):{blob:a,mimeType:r,byteLength:a.size}}async put(e,t,n){let r=await this.#e.open(S.name),i=new Headers({"content-type":n,[R]:e,[z]:String(Date.now()),[B]:String(t.size)}),a=await t.arrayBuffer();await r.put(await V(e),new Response(a,{status:200,headers:i})),await this.#t(r)}async delete(e){await(await this.#e.open(S.name)).delete(await V(e))}async#t(e){let t=await e.keys(),n=await Promise.all(t.map(async t=>{let n=await e.match(t);return{request:t,size:n?H(n):0,storedAt:n?U(n):0}}));n.sort((e,t)=>t.storedAt-e.storedAt);let r=0;for(let[t,i]of n.entries())r+=i.size,(t>=S.maxEntries||r>S.maxTotalBytes)&&await e.delete(i.request)}},G=`defeatAdsProgress`,le={version:1,total:0,events:[],categoryCounts:{},formatCounts:{},siteCounts:{},dayCounts:{}};function K(e){return typeof e==`object`&&!!e&&!Array.isArray(e)}function q(e){if(!K(e))return{};let t={};for(let[n,r]of Object.entries(e))typeof r==`number`&&Number.isFinite(r)&&r>0&&(t[n]=Math.floor(r));return t}function ue(e){if(!K(e))return null;let t=typeof e.category==`string`?e.category.trim():``,n=typeof e.formatId==`string`?e.formatId:``,r=typeof e.site==`string`?c(e.site):``,i=typeof e.time==`number`&&Number.isFinite(e.time)?Math.floor(e.time):0;return!t||!n||!r||i<=0?null:{category:t,formatId:n,site:r,time:i}}function J(e){if(!K(e))return structuredClone(le);let t=Array.isArray(e.events)?e.events.map(ue).filter(e=>e!==null).slice(-C.maxStoredEvents):[];return{version:1,total:typeof e.total==`number`&&Number.isFinite(e.total)?Math.max(0,Math.floor(e.total)):t.length,events:t,categoryCounts:q(e.categoryCounts),formatCounts:q(e.formatCounts),siteCounts:q(e.siteCounts),dayCounts:q(e.dayCounts)}}function de(e){let t=new Date(e);return`${t.getFullYear()}-${String(t.getMonth()+1).padStart(2,`0`)}-${String(t.getDate()).padStart(2,`0`)}`}function Y(e,t){e[t]=(e[t]??0)+1}function X(e,t){let n=Object.entries(e);return n.length<=t?e:Object.fromEntries(n.sort((e,t)=>t[1]-e[1]).slice(0,t))}function fe(e,t){let n={category:t.category.trim()||`unknown`,formatId:t.formatId,site:c(t.site)||`unknown`,time:Math.floor(t.time)},r=[...e.events,n].slice(-C.maxStoredEvents),i={...e.categoryCounts},a={...e.formatCounts},o={...e.siteCounts},s={...e.dayCounts};return Y(i,n.category),Y(a,n.formatId),Y(o,n.site),Y(s,de(n.time)),{version:1,total:e.total+1,events:r,categoryCounts:X(i,C.maxCategoryEntries),formatCounts:X(a,C.maxFormatEntries),siteCounts:X(o,C.maxSiteEntries),dayCounts:X(s,C.maxDayEntries)}}async function pe(){return J((await t.storage.local.get(G))[G])}async function me(e){await t.storage.local.set({[G]:J(e)})}async function he(e){let t=fe(await pe(),e);return await me(t),t}function Z(e){let t=32768,n=``;for(let r=0;r<e.length;r+=t)n+=String.fromCharCode(...e.subarray(r,r+t));return btoa(n)}async function ge(e){let t=e.body?.getReader();if(!t){let t=new Uint8Array(await e.arrayBuffer());if(t.byteLength>x.maxMediaBytes)throw Error(`Media file exceeds the configured size limit.`);return t}let n=[],r=0;for(;;){let{done:e,value:i}=await t.read();if(e)break;if(r+=i.byteLength,r>x.maxMediaBytes)throw await t.cancel(k.log.mediaSizeLimit),Error(`Media file exceeds the configured size limit.`);n.push(i)}let i=new Uint8Array(r),a=0;for(let e of n)i.set(e,a),a+=e.byteLength;return i}function _e(e){let n;try{n=new URL(e)}catch{return!1}let r=new URL(t.runtime.getURL(`/`)).origin;return n.origin===r?!0:n.protocol!==`https:`&&n.protocol!==`http:`?!1:y().includes(e)}function Q(e,t,n,r){let i=`data:${t};base64,${Z(e)}`;return i.length>x.maxDataUrlLength?{ok:!1,error:`Encoded media exceeds the message size guard.`}:{ok:!0,dataUrl:i,mimeType:t,byteLength:e.byteLength,finalUrl:n,cacheHit:r}}async function ve(e,t){if(!_e(e))return{ok:!1,error:k.log.mediaNotInCatalog};let n=await t.get(e).catch(()=>null);if(n)return Q(new Uint8Array(await n.blob.arrayBuffer()),n.mimeType,e,!0);let r=new AbortController,i=setTimeout(()=>r.abort(),x.mediaFetchTimeoutMs);try{let n=await fetch(e,{signal:r.signal,credentials:`omit`,redirect:`follow`,cache:`no-store`,referrerPolicy:`no-referrer`});if(!n.ok)return{ok:!1,error:`Media server returned HTTP ${n.status}.`};let i=(n.headers.get(`content-type`)??``).split(`;`)[0]?.trim().toLowerCase()??``;if(!i.startsWith(`image/`)&&!i.startsWith(`video/`))return{ok:!1,error:`Unsupported media type: ${i||`unknown`}.`};if(Number(n.headers.get(`content-length`)??0)>x.maxMediaBytes)return{ok:!1,error:`Media file exceeds the configured size limit.`};let a=await ge(n),o=new Blob([a.slice().buffer],{type:i});return await t.put(e,o,i).catch(e=>{console.warn(`${k.log.prefix} ${k.log.cacheWriteFailed}`,e)}),Q(a,i,n.url||e,!1)}catch(e){return{ok:!1,error:e instanceof DOMException&&e.name===`AbortError`?`Media request timed out.`:e instanceof Error?e.message:String(e)}}finally{clearTimeout(i)}}async function ye(){let e=await t.tabs.query({});await Promise.allSettled(e.filter(e=>e.id!==void 0).map(e=>t.tabs.sendMessage(e.id,{type:`engine.reconcile`})))}var be=e(()=>{let e=new W,n=new Map,r=Promise.resolve(),i=t=>{let r=n.get(t);if(r)return r;let i=ve(t,e).finally(()=>n.delete(t));return n.set(t,i),i};t.runtime.onInstalled.addListener(async e=>{(await t.storage.local.get(`DefeatAdsConfig`)).DefeatAdsConfig===void 0&&await O(b),e.reason===`install`&&await t.tabs.create({url:t.runtime.getURL(`/onboarding.html`)})}),t.storage.onChanged.addListener((e,t)=>{t!==`local`||!(`DefeatAdsConfig`in e)||ye()}),t.runtime.onMessage.addListener((t,n)=>{if(t.type===`media.fetch`)return n.tab?i(t.url):Promise.resolve({ok:!1,error:`Media requests are accepted only from content scripts.`});if(t.type===`media.invalidate`)return n.tab?e.delete(t.url).then(()=>({ok:!0})):Promise.resolve({ok:!1,error:`Invalid sender.`});if(t.type===`progress.record`)return n.tab?(r=r.catch(()=>void 0).then(()=>he(t.event)).then(()=>void 0),r.then(()=>({ok:!0}))):Promise.resolve({ok:!1,error:`Invalid sender.`});if(t.type===`config.changed`)return O(t.config).then(()=>({ok:!0}))})}),xe={debug:(...e)=>([...e],void 0),log:(...e)=>([...e],void 0),warn:(...e)=>([...e],void 0),error:(...e)=>([...e],void 0)},$;try{$=be.main(),$ instanceof Promise&&console.warn(`The background's main() function return a promise, but it must be synchronous`)}catch(e){throw xe.error(`The background crashed on startup!`),e}return $})();